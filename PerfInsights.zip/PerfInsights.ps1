﻿#------------------------------------------------------------------------------  
#  
# Copyright © 2017 Microsoft Corporation.  All rights reserved.  
#  
# THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED “AS IS” WITHOUT  
# WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT 
# LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  
# FOR A PARTICULAR PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR   
# RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.  
#  
#------------------------------------------------------------------------------  
#  
# PowerShell Source Code  
#  
# NAME:  
#    PerfInsights.ps1  
#  
# VERSION:  
#    check $script:ver
#  
#------------------------------------------------------------------------------  

param(
	[switch]$Cleanup=$false,
	[switch]$AcceptDisclaimerAndShareDiagnostics=$false,
	[String]$TempDrive,
	[switch]$Debug=$false,
	[switch]$NoSRNumber=$false,
	[String]$SRNumber,
	[switch]$RunAsChildProcess=$false,
	[ValidateSet('basic','benchmark','vmslow','vmslowBenchmark','azurefiles','custom')]
	[String]$Scenario,
	# $CustomScenarioModules, i.e. "xnspb" where
	# "x" := xperf
	# "n" := network
	# "s" := storport
	# "p" := perfmon
	# "b" := benchmark
	[String]$CustomScenarioModules,
	[String]$IntegrationTestMode,
	[switch]$NoGUI=$false,
	[Int]$TracingDuration=0
)
# =======================================
$script:ver = "3.2.6"
# =======================================

if($debug){$debugpreference = "Continue"}else{$debugpreference = "SilentlyContinue"}
Write-debug "Script version : $script:ver"
Write-debug "Script was run with switch -NoGUI = $NoGUI."
# in case of NoGUI a scenario should be selected. If empty auto choose 'basic'
if($nogui){
	if($Scenario -eq ""){
		$Scenario = 'basic'
		Write-debug "nogui: overridden argument Scenario=basic"
	}
	$NoSRNumber = $true
	Write-debug "nogui: overridden argument NoSRNumber=true"
}
Write-debug "Script was run with switch -IntegrationTestMode = $Integrationtestmode."
Write-debug "Script was run with arg -Cleanup = $cleanup."
Write-debug "Script was run with arg -AcceptDisclaimerAndShareDiagnostics = $AcceptDisclaimerAndShareDiagnostics."
Write-debug "Script was run with arg -Debug = $Debug."
Write-debug "Script was run with arg -NoSRNumber = $NoSRNumber."
Write-debug "Script was run with arg -SRNumber = $SRNumber."
Write-debug "Script was run with arg -TempDrive = $TempDrive."
Write-debug "Script was run with arg -Scenario = $Scenario."
Write-debug "Script was run with arg -CustomScenarioModules = $CustomScenarioModules."
Write-debug "Script was run with arg -TracingDuration = $TracingDuration."
if($TracingDuration -eq ""){$script:TracingDuration = 0}
$i=0
if((![int]::TryParse($TracingDuration, [ref]$i) -or $i -lt 0)){
	Write-debug "TracingDuration is not a valid integer or it's negative. It will be reset to 0."
	$script:TracingDuration = 0
}else{
	$script:TracingDuration = $i
}
# if user selected to do not track SRNumber, then override it to "no"
if($NoSRNumber){
	$SRNumber = "no"
}

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 

function Init()
{
	Write-Host "PerfInsights $script:Ver" -ForegroundColor Gray

	# ---------- Load Script path constants ---------------

	# script path variable
	$invocation = (Get-Variable MyInvocation -Scope script).Value 
	$script:commandline = $invocation.line
	if($Script:commandline -eq ""){$Script:commandline = "no"}
	$script:scriptpath = $invocation.MyCommand.Definition
	$script:scriptfolder = Split-Path $invocation.MyCommand.Path 
	#remove last "\" if present
	if($script:scriptfolder.EndsWith("\")){$script:scriptfolder = $script:scriptfolder.Substring(0,$script:scriptfolder.Length -1)}
	$script:scriptFileName = $invocation.MyCommand.Name
	$script:scriptName = $script:scriptFileName.Substring(0,$script:scriptFileName.LastIndexOf(".ps1"))
	
	# ----------- Required script Files ---------
	$Script:LogmanGeneralCountersFilePath = "{0}\generalcounters.txt" -F $script:scriptfolder
	$Script:LogmanSQLCountersFilePath = "{0}\sqlcounters.txt" -F $script:scriptfolder
	$Script:RuntimeSettingsFilePath = "{0}\{1}_settings.xml" -F $script:scriptfolder, $script:scriptName
	$script:vmlookupFilePath = "{0}\vmlookup.csv" -f $script:scriptfolder
	$script:PerfInsightsHelperFilePath = "$script:scriptfolder\PerfInsightsHelper.psm1"
	$script:PerfInsightsIntegrationModuleFilePath = "$script:scriptfolder\PerfInsightsIntegrationModule.psm1"
	$script:SCSIInsightsFilePath = "$scriptfolder\Tools\SCSIInsights.exe"
	$Script:ReportFilePath = "{0}\PerfInsights_Report.zip" -F $script:scriptfolder
	$Script:IconFilePath = "{0}\PerfInsights.ico" -F $script:scriptfolder

	$Script:DisclaimerText = "`nThis script runs several stressing I/O operations on this VM and it will collect useful diagnostic information for troubleshooting IaaS performance scenarios in Microsoft Azure. We recommend that you run this script in a maintenance window to avoid load on the system unless your CSS contact has advised you otherwise.
 
Based on the performance scenario, you might end up running one or more components mentioned below:
 
• PerfMon for performance counters
• DiskSpd for storage benchmarking
• XPerf for advanced storage performance analysis
• Netmon traces for advanced network analysis:  Network Monitor traces help detect problems on the network. Trace data contains network traffic information at the frame level and hence all non-encrypted data is visible in a trace.
 
This script will create a zip file that includes the collected log files and findings that will be uploaded to Microsoft support automatically or by you directly.  This data will be stored by Microsoft for a maximum of 90 days after your issue is resolved and will be used and retained consistent with the standards set forth at the "
	$Script:TrustCenterText = "Microsoft Trust Center"
	$Script:TrustCenterLink = "https://www.microsoft.com/en-us/trustcenter/cloudservices/azure"
	$Script:ShareDiagInfoLink = "https://azure.microsoft.com/en-gb/support/trust-center/privacy/support-diagnostic-information-collection/"
	$Script:EULAFilePath = $Script:scriptfolder + "\PerfInsights EULA.docx"

	Write-debug "Script command path = $script:scriptpath" 
	Write-debug "Script command line = $Script:commandline" 	
	Write-debug "Script root folder = $script:scriptfolder" 
	Write-debug "Script name = $script:scriptFileName" 
	Write-debug "Script settings file path = $Script:RuntimeSettingsFilePath"
	
	# ---------- Load Config Settings ---------------
	
	# verify that settings file are present in the proper directory
	CheckForSettingsFiles
	$script:settings = Import-Clixml $Script:RuntimeSettingsFilePath
	
	# Check if TracingDefaultDuration was provided by arg (!0), otherwise it loads default value from settings file
	$script:TracingDuration = if($script:TracingDuration -eq 0){$script:settings.TracingDefaultDuration}else{$script:TracingDuration}
	write-debug ("TracingDuration = {0}, TracingDefaultDuration = {1}" -f $script:TracingDuration, $script:settings.TracingDefaultDuration)

	# ---------- Load PS Modules ---------------
	
	# Script helper
	if((Get-Module "PerfInsightsHelper" -ea 0) -ne $null){Remove-Module "PerfInsightsHelper"}
	Import-Module "$script:PerfInsightsHelperFilePath"
	
	# Load Integration Test Module, if present
	if($Integrationtestmode -ne ""){
		write-debug	"Importing module IntegrationTestModule..."
		Import-Module "$script:PerfInsightsIntegrationModuleFilePath"
		if ((get-module "PerfInsightsIntegrationModule" -ea 0) -eq $null){
			write-debug	"Unable to load the IntegrationTestModule"
		}
	}

	# try to import Storage module (might be unloaded on some environments)
	if((Get-Module Storage) -eq $null){
		write-debug "PS Module <Storage> not loaded. Trying to load"
		Import-Module Storage -ea 0
		if((Get-Module Storage) -eq $null){
			write-debug "PS Module <Storage> does not exist"
		}
	}	

	# ---------- Init Process ---------------
	# check if script was run with admin mode
	Check-AdminModeAndCLR
	$Script:CancelExecution = $True
	Disclaimer
	if ($Script:CancelExecution -eq $True -and !$Nogui)
	{
		write-debug "INIT: CancelExecution = true. Exiting as user did not accepted disclaimer"
		return
	}

	Unblock-Files -folder "$scriptfolder\Tools"

	# Get temp drive
	write-Host "Analyzing disk configuration and detecting temporary drive..." -ForegroundColor Gray
	$Script:tempDrive = Get-Tempdrive

	# ---------- Init Global Constants ---------------
	
	$script:GeneralPerformance = 1
	$script:SQLPerformance = 2
	$script:ExecutionTime = (Get-Date).ToUniversalTime()
	$script:StampedDirName = ($script:ExecutionTime).ToString("yyyy-MM-dd_HH-mm-ss")

	# ---------- Init Global Variables ---------------

	$script:Perfselect = $script:GeneralPerformance # options: "GeneralPerformance", "SQLPerformance"
	$script:outputFolder = "log_collection"
	$script:workingFolder = "WindowsAzureSupport"
	$script:HostAnalizerLogMisc = "GuestFindings"

	$Script:xperfWorkingFolder = "$script:scriptfolder\tools"
	$Script:diskspdWorkingFolder = "$script:scriptfolder\tools\diskspd"
	$Script:NetstatLog = ""
	$Script:traceEventAssemblyPath = "$script:scriptfolder\tools\Microsoft.Diagnostics.Tracing.TraceEvent.dll"
	$Script:diagnosticsAssemblyPath = "$script:scriptfolder\tools\Microsoft.Azure.Performance.Diagnostics.dll"
	$Script:sqlDmfAssemblyPath = "$script:scriptfolder\tools\Microsoft.SqlServer.Dmf.dll"
	$Script:ruleEngineConfigFilePath = "$script:scriptfolder\tools\RuleEngineConfig.json"

	$Script:OS = ""
	$Script:param_perfcounter =""		
	$Script:param_sptrace =""
	$Script:runselection =""
	$Script:array = @()
	$script:findings_Obj = @()
	
	$script:HasEvt129 = $false
	
	$script:tracestart = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
	$script:tracestop = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
	$script:timezone =""

	# set flag if SQL Instance is present
	$script:HasSQLInstance = ((Get-ItemProperty "HKLM:\software\microsoft\Microsoft SQL Server\" -ErrorAction SilentlyContinue).InstalledInstances.Count -gt 0)

	# by default, TempDrive is marked as non auto-detected
	$script:AutoDetectedTempDrive = $false

	InitializeAppInsights
}


function Main()
{
	# create output output folders and log files
	CreateOutput

	# Uncomment next lines to change debug preference to Continue (enables debug output and continue execution)
	# $debugpreference_backup = $debugpreference
	# $debugpreference = "Continue"
	# Write-Debug "Existing Debug Preference: $debugpreference_backup, updated to $debugpreference"
	
	# start collection of transcript
	try{Stop-Transcript -ea 0 | out-null}catch{Write-Debug "transcript already stopped"}
	Start-Transcript -Path $Script:TranscriptLog -ea 0| Out-File $Script:GuestStorageLog
	
	# track case ref
	Track-MSSolveCase $script:ver
		
	# first log is created here
	logInfo "PerfInsights $script:Ver" -NoConsole
	loginfo "VM name: $env:computername" 
	loginfo "Scenario: $Scenario" 
	logInfo "Detected temp drive is: $Script:tempDrive"
	logInfo "Commandline: $Script:commandline"

	#timezone of VM
	$timezone = [TimeZone]::CurrentTimeZone
	logInfo ("Timezone : [{0}]" -f $timezone.StandardName)

	# check OS version
	CheckOSVersion

	LoadDialog

	# entry point for all script logic data collections and tests
	startTests

	# entry point for all auto-analysis 
	Start-AutoAnalysis

	# stop collection of transcript
	Stop-Transcript -ea 0 | out-null

	# Uncomment next lines to revert to original debug preferences
	# restore previous debug preference
	# $debugpreference = $debugpreference_backup
	# Write-Debug "Reverted Debug Preference to : $debugpreference_backup"
}

function LoadDialog()
{
	Write-debug "LoadDialog"
	# skip scenario selection form, if defined by argument
	if($Scenario -ne $null){
		$Script:runselection = switch($Scenario){
			"basic"{"Collect basic configuration"}
			"benchmark"{"Benchmarking"}
			"vmslow"{"Slow VM analysis"}
			"vmslowBenchmark"{"Slow VM analysis and benchmarking"}
			"azurefiles"{"Azure Files analysis"}
			"custom"{"Custom slow VM analysis"}
			default {$null}
		}
	}
	if($Script:runselection -eq $null){
		$objForm = New-Object System.Windows.Forms.Form 
		$objForm.Text = "Select a Troubleshooting Scenario"
		$objForm.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($Script:IconFilePath)
		$objForm.Size = New-Object System.Drawing.Size(260,200) 
		$objForm.StartPosition = "CenterScreen"
		$objForm.AutoScroll = $True
		$objForm.AutoSize = $True
		$objForm.AutoSizeMode = "GrowAndShrink"
		$objForm.MinimizeBox = $False
		$objForm.MaximizeBox = $False
		$objForm.WindowState = "Normal"
		$objForm.SizeGripStyle = "Auto"
		$objForm.ShowInTaskbar = $False
        $objForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Fixed3D
	    
        $Script:okButtonClicked=$false;

		$objForm.KeyPreview = $True
		$objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
			{$Script:runselection=$objListBox.SelectedItem;$Script:okButtonClicked=$true;$objForm.Close()}})
		$objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
			{$objForm.Close()}})
	
		$OKButton = New-Object System.Windows.Forms.Button
		$OKButton.Location = New-Object System.Drawing.Size(238,155)
		$OKButton.Size = New-Object System.Drawing.Size(75,30)
		$OKButton.Text = "OK"
		$OKButton.Add_Click({$Script:okButtonClicked=$true;$Script:runselection=$objListBox.SelectedItem;$objForm.Close()})
		$objForm.Controls.Add($OKButton)
	
		$objLabel = New-Object System.Windows.Forms.Label
		$objLabel.Location = New-Object System.Drawing.Size(12,9) 
		$objLabel.Size = New-Object System.Drawing.Size(270,30) 
		$objLabel.Text = "Please select a Troubleshooting Scenario:"
        $objLabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
		$objForm.Controls.Add($objLabel) 
	
		$objListBox = New-Object System.Windows.Forms.ListBox 
		$objListBox.Location = New-Object System.Drawing.Size(12,40) 
		$objListBox.Size = New-Object System.Drawing.Size(240,180) 
		$objListBox.Height = 120
		$objListBox.Width = 300
	
		#check OS version
		if ($Script:OS -eq "Win8orWin10")
		{
		[void] $objListBox.Items.Add("Collect basic configuration")
		[void] $objListBox.Items.Add("Benchmarking")
		[void] $objListBox.Items.Add("Slow VM analysis")
		[void] $objListBox.Items.Add("Slow VM analysis and benchmarking")
		[void] $objListBox.Items.Add("Azure Files analysis")
		[void] $objListBox.Items.Add("Custom slow VM analysis")
		}
		else
		{
		[void] $objListBox.Items.Add("Collect basic configuration")
		[void] $objListBox.Items.Add("Benchmarking")
		[void] $objListBox.Items.Add("Slow VM analysis")
		[void] $objListBox.Items.Add("Slow VM analysis and benchmarking")
		[void] $objListBox.Items.Add("Custom slow VM analysis")
		}
		$objListBox.SetSelected(0,$True)
		$objForm.Controls.Add($objListBox) 
	
		$objForm.Topmost = $True
	
		$objForm.Add_Shown({$objForm.Activate()})
		[void] $objForm.ShowDialog()
        if($Script:okButtonClicked -eq $false)
		{
			Write-Host "User abort."
			exit
		}
		$Script:runselection=$objListBox.SelectedItem
	}

	if ($Script:runselection -eq "Custom slow VM analysis")
	{
		if($NoGUI){
			if($CustomScenarioModules -eq ""){
				Write-debug "customscenario is not defined"
			}else{
				$pattern = $CustomScenarioModules.ToLower()
				Write-debug "pattern : $pattern"

			    if($pattern.Contains("x")) { $Script:array += "XPerf Trace"}
			    if($pattern.Contains("n")) { $Script:array += "Network Trace"}
			    if($pattern.Contains("s")) { $Script:array += "Storport Trace"}
			    if($pattern.Contains("p")) { $Script:array += "Performance Counter Trace"}
			    if($pattern.Contains("b")) { $Script:array += "Diskspd benchmark"}

				Write-debug ("Script:array contains {0} elements" -f $Script:array.Count)
			}
		
		}else{
			$customselection = @()
			$objForm2 = New-Object System.Windows.Forms.Form 
			$objForm2.Text = "Modules to execute"
			$objForm2.Size = New-Object System.Drawing.Size(290,200) 
			$objForm2.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($Script:IconFilePath)
			$objForm2.StartPosition = "CenterScreen"
			$objForm2.AutoScroll = $True
			$objForm2.AutoSize = $True
			$objForm2.AutoSizeMode = "GrowAndShrink"
			$objForm2.MinimizeBox = $False
			$objForm2.MaximizeBox = $False
			$objForm2.WindowState = "Normal"
			$objForm2.SizeGripStyle = "Auto"
			$objForm2.ShowInTaskbar = $False
            $objForm2.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Fixed3D
	
			$objForm2.KeyPreview = $True
	
			$objForm2.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
				{
					foreach ($objItem in $objListbox2.SelectedItems)
						{$xcustom += $objItem}
					$objForm2.Close()
				}
				})
	
			$objForm2.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
				{$objForm2.Close()}})
	
			$OKButton2 = New-Object System.Windows.Forms.Button
			$OKButton2.Location = New-Object System.Drawing.Size(199,116)
			$OKButton2.Size = New-Object System.Drawing.Size(75,30)
			$OKButton2.Text = "OK"
	
			$OKButton2.Add_Click(
			   {
					foreach ($objItem in $objListbox2.SelectedItems)
						{$xcustom += $objItem}
					$objForm2.Close()
			   })
	
			$objForm2.Controls.Add($OKButton2)
	
			$objLabel2 = New-Object System.Windows.Forms.Label
			$objLabel2.Location = New-Object System.Drawing.Size(12,9) 
			$objLabel2.Size = New-Object System.Drawing.Size(272,20) 
            $objLabel2.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
			$objLabel2.Text = "Please make a selection from the list below:"
			$objForm2.Controls.Add($objLabel2) 
	
			$objListbox2 = New-Object System.Windows.Forms.Listbox 
			$objListbox2.Location = New-Object System.Drawing.Size(12,40) 
			$objListbox2.Size = New-Object System.Drawing.Size(260,20) 
	
			$objListbox2.SelectionMode = "MultiExtended"
			[void] $objListbox2.Items.Add("Performance Counter Trace")
			[void] $objListbox2.Items.Add("Diskspd benchmark")
			[void] $objListbox2.Items.Add("XPerf Trace")
			[void] $objListbox2.Items.Add("Network Trace")
			[void] $objListbox2.Items.Add("Storport Trace")
			$objListbox2.SetSelected(0,$True)

			$objListbox2.Height = 70
			$objForm2.Controls.Add($objListbox2) 
			$objForm2.Topmost = $True
	
			$objForm2.Add_Shown({$objForm2.Activate()})
			[void] $objForm2.ShowDialog()
			foreach ($objItem in $objListbox2.SelectedItems)
						{$customselection += $objItem}
			$Script:array = $customselection
		}
	}
}

function Track-MSSolveCase()
{
	param(
		[string]$scriptVersion
	)

	$functionName = ((Get-Variable MyInvocation).Value).MyCommand.Name

	#check if CX defined an input
	if($SRNumber.Length -ne "" -or $NoSRNumber)
	{
		Write-Debug "$functionName.Using MSSolve Case provided by customer from argument: $SRNumber" 
		$script:SRNumber = $SRNumber
	}
	else
	{
		#$script:SRNumber = [Microsoft.VisualBasic.Interaction]::InputBox("Please Enter MS Support request number`n`n(e.g. 11530714677382)", "MS Support request", "")
		
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

		$script:SRNumber=""
		$objForm = New-Object System.Windows.Forms.Form 
		$objForm.Text = "MS Support request"
		$objForm.Size = New-Object System.Drawing.Size(290,250) 
		$objForm.StartPosition = "CenterScreen"
		$objForm.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($Script:IconFilePath)

		$objForm.AutoScroll = $True
		$objForm.AutoSize = $True
		$objForm.AutoSizeMode = "GrowAndShrink"
		$objForm.MinimizeBox = $False
		$objForm.MaximizeBox = $False
		$objForm.WindowState = "Normal"
		$objForm.SizeGripStyle = "Auto"
		$objForm.ShowInTaskbar = $False
		$objForm.DataBindings.DefaultDataSourceUpdateMode = 0
        $objForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Fixed3D

        $Script:okButtonClicked = $false

		$OKButton = New-Object System.Windows.Forms.Button
		$OKButton.Location = New-Object System.Drawing.Size(114,90)
		$OKButton.Size = New-Object System.Drawing.Size(75,30)
		$OKButton.Text = "OK"
		$OKButton.DataBindings.DefaultDataSourceUpdateMode = 0
		$OKButton.Add_Click({$Script:okButtonClicked=$true; $objForm.Close()})
		$objForm.Controls.Add($OKButton)

		$CancelButton = New-Object System.Windows.Forms.Button
		$CancelButton.Location = New-Object System.Drawing.Size(195,90)
		$CancelButton.Size = New-Object System.Drawing.Size(75,30)
		$CancelButton.Text = "Cancel"
		$CancelButton.DataBindings.DefaultDataSourceUpdateMode = 0
		$CancelButton.Add_Click({$objForm.Close()})
		$objForm.Controls.Add($CancelButton)

		$objLabel = New-Object System.Windows.Forms.Label
		$objLabel.Location = New-Object System.Drawing.Size(10,20) 
		$objLabel.Size = New-Object System.Drawing.Size(270,40) 
        $objLabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
		$objLabel.Text = "Please Enter MS Support request number `n(e.g. 11530714677382)"
		$objForm.Controls.Add($objLabel) 

		$objTextBox = New-Object System.Windows.Forms.TextBox 
		$objTextBox.Location = New-Object System.Drawing.Size(10,60) 
		$objTextBox.Size = New-Object System.Drawing.Size(260,20) 
		$objForm.Controls.Add($objTextBox) 

		$objForm.Topmost = $True
		$objForm.Add_Shown({$objForm.Activate()})

		[void] $objForm.ShowDialog()
        if($Script:okButtonClicked -eq $false)
		{
			Write-Host "User abort."
			
		}
		$script:SRNumber = $objTextBox.Text

		Write-Debug "$functionName.Customer input: $script:SRNumber."
	}

	# check if ticket is valid
	if ($script:SRNumber.Length -lt 1) 
	{     
		$script:SRNumber ="no"
	}

	# enrich script version with guest OS version
	$OS = (Get-WmiObject -Class Win32_OperatingSystem).Version
}

function IsClrV4InPowerShell()
{
    Write-Debug "CLR major version is $($psversiontable.CLRVersion.Major)"
    if ($psversiontable.CLRVersion.Major -ge 4)
    {
		return $true
    }
	else
	{
		return $false
	}
}

function RequirePowerShellWithClrV4()
{
	if ((IsClrV4InPowerShell) -eq $true)
	{
		# CLR is already v4 in PowerShell
		return $false
	}

	# follow up instructions on https://msdn.microsoft.com/en-us/library/hh925568(v=vs.110).aspx
    $dotnet4Versions = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -recurse | Get-ItemProperty -name Version,Release -EA 0 | Where { $_.PSChildName -match '^(?!S)\p{L}' -and $_.Version.StartsWith("4.") } | Select Version
    
    if ($dotnet4Versions.count -le 0)
    {
        Write-Debug ".NET Framework 4.0+ is not installed"
        return $false
    }
    else
    {
		$version = $dotnet4Versions -join '-'
        Write-Debug "Found the following versions of CLR: $version"
        return $true;
    }
}

function Check-AdminModeAndCLR()
{
	$inAdminMode = $true
	if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) 
	{ 
		Write-Debug "Script was run with Admin Mode OFF"
		Write-Debug "Starting new PowerShell with $script:scriptpath"
		$inAdminMode = $false
	}
	else
	{
		Write-Debug "Script was run with Admin Mode ON"
	}
	$requireClrV4 = $false
	if ((RequirePowerShellWithClrV4) -eq $true)
	{
		Write-Debug "current COMPLUS_ApplicationMigrationRuntimeActivationConfigPath: $env:COMPLUS_ApplicationMigrationRuntimeActivationConfigPath"
		if ($RunAsChildProcess -eq $true)
		{
			Write-Debug "Already in child process mode. It means that CLR v4 should have been used."
			return
		}
		# the valid value of version attribute can be found on https://msdn.microsoft.com/en-us/library/jj152935(v=vs.110).aspx
		$powershellAppConfig = @"
<?xml version="1.0" encoding="utf-8" ?>
<configuration>
<startup useLegacyV2RuntimeActivationPolicy="true">
<supportedRuntime version="v4.0"/>
</startup>
</configuration>
"@
		$powershellAppConfigFilePath = "$script:scriptfolder\powershell.exe.activation_config"
		$powershellAppConfig | Out-File -filepath $powershellAppConfigFilePath -Encoding UTF8
		$EnvVarName = 'COMPLUS_ApplicationMigrationRuntimeActivationConfigPath'
		# it only impacts the current process and its children
		[Environment]::SetEnvironmentVariable($EnvVarName, "$script:scriptfolder\");
		$requireClrV4 = $true
	}
	if ($inAdminMode -eq $false -or $requireClrV4 -eq $true)
	{
		$argumentList = "-RunAsChildProcess"
		if($Cleanup){$argumentList += " -Cleanup"}
		if($AcceptDisclaimerAndShareDiagnostics){$argumentList += " -AcceptDisclaimerAndShareDiagnostics"}
		if($Debug){$argumentList += " -Debug"}
		if($NoSRNumber){$argumentList += " -DisableTrackMSSolveCase"}
		if($TempDrive){$argumentList += " -TempDrive `"$TempDrive`""}
		if($SRNumber){$argumentList += " -MSSolveCaseNumber $SRNumber"}
		if($nogui){$argumentList += " -NoGui"}
		if($TracingDuration){$argumentList += " -TracingDuration $TracingDuration"}
		if($Scenario){$argumentList += " -scenario $Scenario"}
		if($CustomScenarioModules){$argumentList += " -CustomScenarioModules $CustomScenarioModules"}
		if($IntegrationTestmode){$argumentList += " -IntegrationTestMode $IntegrationTestmode" }
		Write-Debug "starting new Powerhell with arguments $argumentList"
		Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -Command `"$script:scriptpath $argumentList`"" -Verb RunAs -Wait
		Write-Debug "powershell session ended"
		exit
	}
	else
	{
		Write-Debug "Script was run with Admin Mode ON and PowerShell uses CLR v4+"
	}
}

function Get-Tempdrive()
{
	#check if user provided a valid drive from arguments
	if($TempDrive -ne ""){
		Write-Debug "TempDrive provided by user from argument: $TempDrive"
		if($TempDrive.length -eq 1){
			$TempDrive = $TempDrive + ":"
		}
		if(test-path $TempDrive){
			Write-Debug "TempDrive provided by user from argument: $TempDrive, is valid."
			return $TempDrive
		}else{
			Write-Debug "TempDrive provided by user from argument: $TempDrive, in NOT valid."
		}
	}
	
	# detect temp drive from list of volumes (dik # 1, partition 0 scasi target 1)
	$disk = get-volumemap | where-object {$_.istempdisk}
	# get first data disk, if any exists
	$datadisk = (get-volumemap | where-object {$_.isdatadisk})
	$datadisk0  = if($datadisk -is [system.array]){$datadisk[0]}else{$datadisk}
	$osdisk = get-volumemap | where-object {$_.isosdisk}

	$selectedDrive = ""

	if($disk -ne $null)
	{
		$selectedDrive = $disk.VolumeID
		Write-Debug "Automatically detected TempDrive: <$selectedDrive>"
		$script:AutoDetectedTempDrive = $true
	}
	elseif(!$NoGUI){
		write-debug "unable to autodetect TempDrive. Asking user"
		$selectedDrive = PromptTempDrive
	}elseif($datadisk0 -ne $null){
		write-debug "unable to autodetect TempDrive. NoGUI mode is enabled. Using first DataDisk as tempdrive."
		$selectedDrive = $datadisk0.VolumeID
	}elseif($osdisk -ne $null){
		write-debug "unable to autodetect TempDrive or DataDisk. NoGUI mode is enabled. Using OSDisk as tempdrive."
		$selectedDrive = $osdisk.VolumeID
	}else{
		write-debug "unable to autodetect TempDrive, DataDisk, or OSDisk. NoGUI mode is enabled. Using C: as tempdrive."
		$selectedDrive = "C:"
	}
	
	Write-Debug "Configured TempDrive is: <$selectedDrive>"
	return $selectedDrive
}

function PromptTempDrive () 
{

	Write-Debug "Ask user for TempDrive"
	# Ask for root drive used for tests
	$isValid = $false
	
	do{
		#$selectedDrive = [Microsoft.VisualBasic.Interaction]::InputBox("Please enter your default temporary drive to store the logs generated by the script`nand download additional required files.`n`nDefault is D", "Your Temporary drive", "D")
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

		$selectedDrive=""
		$objForm = New-Object System.Windows.Forms.Form 
		$objForm.Text = "Your Temporary drive"
		$objForm.Size = New-Object System.Drawing.Size(303,153) 
		$objForm.StartPosition = "CenterScreen"
		$objForm.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($Script:IconFilePath)

		$objForm.AutoScroll = $True
		$objForm.AutoSize = $True
		$objForm.AutoSizeMode = "GrowAndShrink"
		$objForm.MinimizeBox = $False
		$objForm.MaximizeBox = $False
		$objForm.WindowState = "Normal"
		$objForm.SizeGripStyle = "Auto"
		$objForm.ShowInTaskbar = $False
		$objForm.DataBindings.DefaultDataSourceUpdateMode = 0
        $objForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Fixed3D

        $Script:okButtonClicked = $false

        $handler_objForm_Load = {
        $objTextBox.Select()
        }
        $objForm.add_Load($handler_objForm_Load)

		$OKButton = New-Object System.Windows.Forms.Button
		$OKButton.Location = New-Object System.Drawing.Size(114,107)
		$OKButton.Size = New-Object System.Drawing.Size(75,30)
		$OKButton.Text = "OK"
		$OKButton.DataBindings.DefaultDataSourceUpdateMode = 0
		$OKButton.Add_Click({$Script:okButtonClicked=$true; $objForm.Close()})
		$objForm.Controls.Add($OKButton)

		$CancelButton = New-Object System.Windows.Forms.Button
		$CancelButton.Location = New-Object System.Drawing.Size(195,107)
		$CancelButton.Size = New-Object System.Drawing.Size(75,30)
		$CancelButton.Text = "Cancel"
		$CancelButton.DataBindings.DefaultDataSourceUpdateMode = 0
		$CancelButton.Add_Click({$objForm.Close()})
		$objForm.Controls.Add($CancelButton)

		$objLabel = New-Object System.Windows.Forms.Label
		$objLabel.Location = New-Object System.Drawing.Size(12,9) 
		$objLabel.Size = New-Object System.Drawing.Size(258,67) 
        $objLabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
		$objLabel.Text = "Please enter your default temporary drive letter to store the logs generated by the script and download additional required files. `n`nDefault is D."
		$objForm.Controls.Add($objLabel) 

		$objTextBox = New-Object System.Windows.Forms.TextBox 
		$objTextBox.Location = New-Object System.Drawing.Size(12,80) 
		$objTextBox.Size = New-Object System.Drawing.Size(257,30) 
		$objTextBox.Text = "D"
		$objForm.Controls.Add($objTextBox)

		$objForm.Topmost = $True
		$objForm.Add_Shown({$objForm.Activate()})

		[void] $objForm.ShowDialog()
		$selectedDrive = $objTextBox.Text
		
		if($selectedDrive -eq "" -or $Script:okButtonClicked -eq $false)
		{
			Write-Host "User abort."
			exit
		}
	
		# add ':' if user provided just a drive letter
		if($selectedDrive.length -eq 1){
			$selectedDrive = $selectedDrive + ":"
		}

		# if chosen drive is invalid use SystemDrive and ask customer
		if(Test-Path $selectedDrive)
		{
			Write-Debug "TempDrive provided by user from input: $selectedDrive, is valid."
			$isValid = $true
		}else
		{
			Write-Debug "TempDrive provided by user from input: $selectedDrive, in NOT valid."
			#$v = [Microsoft.VisualBasic.Interaction]::MsgBox("Invalid drive.`nChoose another one. SystemDrive is "+ $Env:SystemDrive,"OkOnly","Warning")
			$buttons=[system.windows.forms.messageboxbuttons]::OK;
	        $v =[system.windows.forms.messagebox]::Show("Invalid drive.`nChoose another one. SystemDrive is "+ $Env:SystemDrive,"Warning",$buttons,[System.Windows.Forms.MessageBoxIcon]::Warning);
		}
	}
	while(!$isValid) 
	

	Write-Debug "Selected TempDrive: $selectedDrive"
	return $selectedDrive
}

# ========================================
#  worker functions

function Find-ChildProcess 
{
	param($ID=$PID)
	Get-WmiObject -Class Win32_Process -Filter "ParentProcessID=$ID" | Select-Object -Property ProcessName, ProcessID, CommandLine
}

Function CreateOutput()
{
	$logworkingfolder = "Logs"
	$script:logpath = "$Script:tempDrive\$script:workingFolder\$logworkingfolder\$script:StampedDirName"
	$script:logpath_Logs = "$script:logpath\Logs"
	$script:logpath_Output = "$script:logpath\output"
	Write-Debug "logpath is :<$script:logpath>"

	if(!(Test-Path $script:logpath)){
		New-item $script:logpath -ItemType Directory -F | Out-Null
		New-item $script:logpath_Logs -ItemType Directory -F | Out-Null
	}

	# unzip report on log path
	Unzip "$Script:ReportFilePath\PerfInsights_Report" $script:logpath
	remove-item "$script:logpath\Logs\foo.txt"
	#LOG
	$Script:GuestStorageLog = "$script:logpath_Logs\Storage_Info.log"
	$Script:FsutilLog = "$script:logpath_Logs\fsutil.log"
	$script:TaskListLog = "$script:logpath_Logs\tasklist.log"
	$script:SRCLog = "$script:logpath_Logs\Storage_Reliability_Counters.log"
	$script:FilterDriversLog = "$script:logpath_Logs\Filter_Drivers.log"
	$Script:NetstatLog = "$script:logpath_Logs\netstat.log"
	$Script:EventLog = "$script:logpath_Logs\event.log"
	$Script:TranscriptLog = "$script:logpath_Logs\transcript.log"
	$Script:PerformanceDiagnosticsLog = "$script:logpath_Logs\PerformanceDiagnostics.log"
	
	#JS
	
	$script:FindingsJS = "$script:logpath_Output\findings.js"
	$script:DiskJS = "$script:logpath_Output\disks.js"
	$script:PerfDiagJS = "$script:logpath_Output\perfdiag.js"
	$script:TraceJS = "$script:logpath_Output\trace.js"
	
	
	#JSON
	$script:FindingsJson = "$script:logpath_Logs\findings.json"
	$Script:GuestVolumeMapJson = "$script:logpath_Logs\Volume_Map.json"
	$Script:GuestDiskMapJson = "$script:logpath_Logs\Disk_Map.json"
	$Script:GuestVolumeMapNfo = "$script:logpath_Logs\Volume_Map.nfo"
}


function RunDiskSpd()
{
	header "Start Diskspd Testing"

	# set proper diskspd exe file, basing on current process architecture (32bit or 64 bit)
	$platformFolder = ""
	if ([Environment]::Is64BitProcess)
	{
		Write-Debug "Is64BitProcess = true"
		$diskspdExe = "$Script:diskspdWorkingFolder\amd64fre\diskspd.exe"
	}else{
		Write-Debug "Is64BitProcess = false"
		$diskspdExe = "$Script:diskspdWorkingFolder\x86fre\diskspd.exe"
	}

	Write-Debug "RunDiskSpd: diskspdExe=$diskspdExe"
    logmsg "[INFO] Starting Diskspd Testing"   
	
	# get all valid drives
	$OSDrive = get-volumemap | where-object {$_.isosdisk}
	$TempDrive = get-volumemap | where-object {$_.istempdisk}
	$drives = get-volumemap | where-object {$_.isdatadisk}  

	#define array of sessions
	$iterations = @()
	$sessionCount =0

	# load sessions for OS Disk analisys
	if($script:settings.DiskSpdSettings.enableOSDiskAnalysis)
	{
		$iteration = New-Object PSObject -Property @{
			DriveToTest = $OSDrive
			sessions = $script:settings.DiskSpdSettings.os_sessions
		}
		$iterations += $iteration
		$sessionCount += $script:settings.DiskSpdSettings.os_sessions.Count
	}

	# load sessions for Temp Disk analysis
	# skip session if tempdrive was not autodetected
	if($script:settings.DiskSpdSettings.enableTempDiskAnalysis)
	{
		# skip if temp drive was not autodetected
		if($script:AutoDetectedTempDrive){
			$iteration = New-Object PSObject -Property @{
				DriveToTest = $TempDrive
				sessions = $script:settings.DiskSpdSettings.temp_sessions
			}
			$iterations += $iteration
			$sessionCount += $script:settings.DiskSpdSettings.temp_sessions.Count
		}else{
			loginfo "Skipping Temp Drive benchmarking analysis as it was not auto-detected."
		}
	}
	
	# load sessions for Data Disk analysis
	if($script:settings.DiskSpdSettings.enableDataDiskAnalysis -and $drives -ne $null)
	{
		write-debug ("List of data drives to ignore: " + $script:settings.DiskSpdSettings.ignore_drives)
		foreach($DriveToTest in $drives)
		{
			$VolumeID = $DriveToTest.VolumeID
			# ignore non valid drive paths
			if(!(Test-Path -IsValid ($VolumeID))) { 
				Write-Debug "Test-path failed for:<$VolumeID>. skipping"
				continue 
			}

			# ignore drives defined in setting
			if($script:settings.DiskSpdSettings.ignore_drives.split(",") -contains $VolumeID) { 
				Write-Debug "drive:<$VolumeID> matches the ignore drive list"
				continue 
			}

			$iteration = New-Object PSObject -Property @{
				DriveToTest = $DriveToTest;
				sessions = $script:settings.DiskSpdSettings.data_sessions;
				}

			$iterations += $iteration
			$sessionCount += $script:settings.DiskSpdSettings.data_sessions.Count
		}
	}

	$_i = 0
	$session_result_list = @()
	# do actual work
	# loop into each disk-based iteration
	foreach ($iteration in $iterations)
	{
		$DriveToTest = $iteration.DriveToTest
		$VolumeID = $DriveToTest.VolumeID
		
		#set numOfDisks = volume's number of disks
		$NumOfDisks = $DriveToTest.NumOfDisks
		# check RAID config. if not Striped, override NumOfDisks = 1
		if($DriveToTest.IsDynamic -and !$DriveToTest.IsStriped){
			$NumOfDisks = 1
		}

		# take the size of first disk (either if pooled, dynamic or single)
		$singlediksize = $driveToTest.Disks[0].SizeGB

		# calculate volume performance targets
		$maxIOPS = 0
		$maxthroughput = 0

		if($Script:VMSize -ne $null){
			switch($Script:VMSize.StorageTier){
				"Premium"{
					$targetPerf = Get-PremiumDiskTargetPerformance($singlediksize)
					$maxIOPS = $targetPerf.maxIOPS * $NumOfDisks
					$maxthroughput = $targetPerf.maxthroughput * $NumOfDisks
				}
				"Basic"{
					$targetPerf = Get-BasicDiskTargetPerformance($singlediksize)
					$maxiops = $NumOfDisks * 300
					$maxthroughput = $NumOfDisks * 60
				}
				"Standard"{
					$targetPerf = Get-StandardDiskTargetPerformance($singlediksize)
					$maxiops = $NumOfDisks * 500
					$maxthroughput = $NumOfDisks * 60
				}
			}
			
			if($maxIOPS -gt $Script:VMSize.'Max. IOPS'-and $Script:VMSize.'Max. IOPS' -ne 0){
				Write-Debug ("Drive $VolumeID could not reach max iops $maxiops due to VM limit {0}" -f $Script:VMSize.'Max. IOPS')
				$maxiops = [int]$Script:VMSize.'Max. IOPS'
			}
			if($maxthroughput -gt $Script:VMSize.'Max. Throughput' -and $Script:VMSize.'Max. Throughput' -ne $null -and $Script:VMSize.'Max. Throughput' -ne 0){
				Write-Debug ("Drive $VolumeID could not reach max throughput $maxthroughput MBPS due to VM limit {0} mbps" -f $Script:VMSize.'Max. Throughput')
				$maxthroughput = [int]$Script:VMSize.'Max. Throughput'
			}
		}
		write-debug ("Performance Target = Drive {0}, max IOPS {1}, max MBPS {2}" -F $VolumeID, $maxiops, $maxthroughput)
	
		Write-Debug "maxiops = $maxiops" 
		#set thread number = num of column
		$param_thread = "-t" + $NumofDisks

		# loop into each session in current iteration
		foreach ($session in $iteration.sessions){
			$_i = $_i + 1
			Write-Progress -Activity "Running DiskSpd Test" -status "Progress" -percentComplete ($_i / $sessionCount*100)

			$testFile = "{0}\{1}\{2}" -f $VolumeID, $script:settings.DiskSpdSettings.datfilepath, $script:settings.DiskSpdSettings.datfilename 
			$param_filesize = "-c" + $script:settings.DiskSpdSettings.datfilesize

			$param_writeratio = "-w" + $session.write_ratio 
			$param_blocksize = "-b" + $session.block_size

			#override duration, if defined
			if($session.duration -ne $null){
				$param_duration = "-d" + $session.duration
			}else{
				$param_duration = "-d" + $script:settings.DiskSpdSettings.duration
			}
			#override warmup, if defined
			if($session.warmup -ne $null){
				$param_warmup = "-W" + $session.warmup
			}else{
				$param_warmup = "-W" + $script:settings.DiskSpdSettings.warmup
			}
			#override writeratio, if defined
			if($session.write_ratio -ne $null){
				$param_writeratio = "-w" + $session.write_ratio
			}else{
				$param_writeratio = "-w" + $script:settings.DiskSpdSettings.write_ratio
			}
			#override IOType, if defined
			if($session.$IOType -ne $null){
				$IOType = "-" + $session.IOType
			}else{
				$IOType = "-" + $script:settings.DiskSpdSettings.IOType
			}			

			$session_title = $session.title
			#$ocount = ($session.queue_depth).Count

            #logmsg "[INFO] this session will loop on $ocount different -o values"    
			# loop into outstanding ops
			foreach ($o in $session.queue_depth) {
				
				$param_g = ""

				$expectedlat = switch($Script:VMSize.StorageTier){"Premium"{0.015}"Standard"{0.05}"Basic"{0.05}}
				# adapting queue depth to maxiops and max throughput
				if($session_title -eq "IOPS" -and $maxiops -gt 0){
					# formula
                    $param_o_value = ($maxiops * $expectedlat).ToString('#')
                    write-debug "queue depth automatically calculated = $param_o_value"
					
					# do not use -g parameter
					$param_g = ""
                }elseif($session_title -eq "MBPS" -and $maxthroughput -gt 0){
					# do not use blocksize for this test (use default value = 64k)
					$param_blocksize = "" 
					# use QD = 16 as indicated here : https://docs.microsoft.com/en-us/azure/storage/storage-premium-storage-performance#queue-depth
					$param_o_value = 16
                    # formula
					# -g := target number of bytes to operate on per-millisecond per-thread per-target
					$param_g_value = ($maxthroughput * 1MB/ (1000 * $NumofDisks) ).ToString('#')
					write-debug "param g automatically calculated = $param_g_value"
					$param_g = "-g{0}" -f $param_g_value
                }else{
					# use value defined in the settigns file
					$param_o_value = $o
					
				}

				
				$param_qd = "-o{0}" -f $param_o_value

				#run diskspd now

				$maxval = switch($session_title){"IOPS"{$maxiops}"MBPS"{$maxthroughput}}
				Write-Host "$VolumeID. Max $session_title ($maxval). INPUT:$param_duration $param_warmup $param_writeratio $param_thread $param_qd $param_blocksize $IOType $param_g -h -L. " -NoNewline
                $diskspdStartTime = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
				$result = & $diskspdExe $param_filesize $param_duration $param_warmup $param_writeratio $param_thread $param_qd $param_blocksize $IOType $param_g -h -L $testFile
                $diskspdEndTime = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
				foreach ($line in $result) {if ($line -like "Command Line*") { $cmdline = $line; break } }
				foreach ($line in $result) {if ($line -like "total:*") { $total=$line; break } }
				foreach ($line in $result) {if ($line -like "avg.*") { $avg=$line; break } }
				$mbps = $total.Split("|")[2].Trim() 
				$iops = $total.Split("|")[3].Trim()
				$latency = $total.Split("|")[4].Trim()
				$cpu = $avg.Split("|")[1].Trim()
				
				Write-Host "OUTPUT: " -NoNewline
				Write-Host $iops -NoNewline -ForegroundColor cyan
				# draw IOPS stats 
				if($session_title -eq "IOPS" -and $maxiops -gt 0){
					$stats_iops = ($iops / $maxiops * 100).ToString('#')
					if(($stats_iops -90) -ge 0)
						{Write-Host " ($stats_iops%)" -NoNewline -ForegroundColor green}
					else
						{Write-Host " ($stats_iops%)" -NoNewline -ForegroundColor yellow}
				}
				Write-Host " IOPS, " -NoNewline

				Write-Host $mbps -NoNewline -ForegroundColor cyan
				# draw MBPS stats 
				if($session_title -eq "MBPS" -and $maxthroughput -gt 0){
					$stats_mbps = ($mbps / $maxthroughput * 100).ToString('#')
					if(($stats_mbps -90) -ge 0){Write-Host " ($stats_mbps%)" -NoNewline -ForegroundColor green}
					else{Write-Host " ($stats_mbps%)" -NoNewline -ForegroundColor yellow}
				}
				Write-Host " MB/sec, " -NoNewline

				Write-Host $latency -NoNewline -ForegroundColor cyan
				Write-Host " ms avgLat" #, $cpu CPU"
				#log diskSpd result to external file
				# use single file in append mode
				$DiskSpdLogRaw = "$script:logpath_Logs\diskSpd.log"
				"StartTime: [$diskspdStartTime]   EndTime: [$diskspdEndTime]" | Out-File $DiskSpdLogRaw -Append
				$result | Out-File $DiskSpdLogRaw -Append

				# use separated files
				$better_VolumeID = $VolumeID.replace(":","").replace("\","_")
				$DiskSpdLogRaw = "$script:logpath_Logs\diskSpd_{0}_{1}.log" -f $better_VolumeID, $session_title
				"StartTime: [$diskspdStartTime]   EndTime: [$diskspdEndTime]" | Out-File $DiskSpdLogRaw -Append
				$result | Out-File $DiskSpdLogRaw -Append

				# cleanup file created for testing
				Remove-Item ("{0}\{1}" -f $VolumeID , $script:settings.DiskSpdSettings.datfilepath) -Recurse -Force

				$cmdline = $cmdline -replace "\\", "\\"
				# populate json item for current session's result
				$session_result += "{`"CommandLine`":`"$cmdline`",`"StartTime`":`"$diskspdStartTime`",`"Endtime`":`"$diskspdEndTime`",`"Drive`":`"$VolumeID`",`"IOPS`":`"$iops`",`"MBps`":`"$mbps`",`"AvgLat`":`"$latency`",`"CPU`":`"$cpu`"}"
				# add 'comma' if this is not the last item of the array
				if($_i -lt $sessionCount){
					$session_result += ","
				}

				"StartTime : $diskspdStartTime, Endtime : $diskspdEndTime, CommandLine : $cmdline, Drive : $VolumeID , IOPS : $iops, MBps : $mbps, AvgLat : $latency, CPU : $cpu" | Out-File $Script:GuestStorageLog -Append
			} # end loop queue_depth
			
		} # end loop session

	} # end loop iterations


	If($_i -eq 0){
		Logmsg "[WARN] Skipping DiskSpd test. No valid drives found." "Yellow"
	}else{
		# building json output file
		$DiskSpdLogJson = "$script:logpath_Logs\diskSpd.log.json" 
		$log_obj = "{`"Title`":`"DiskSpd results`", `"Results`":[$session_result]}" 
		$log_obj | Out-File $DiskSpdLogJson 
		
		logmsg "[INFO] Diskspd analysis completed."
	}
}

function CleanUp
{
	Write-Host "[INFO] Cleaning up, please wait..." -ForegroundColor Gray
	
	if (($Script:param_perfcounter -eq "Yes") -or ($Script:param_perfcounter -eq "enabled") -or ($Script:param_perfcounter -eq ""))
	{
		#delete the performane counter
		$result = &	"logman" "stop" "GuestVMPerf"
		$result = &	"logman" "delete" "GuestVMPerf"
	}
	
	# stop collection of transcript
	try{Stop-Transcript -ea 0 | out-null}catch{Write-Debug "transcript already stopped"}
	
	#remove workfolder
	cd "$script:scriptfolder\"
	if(test-Path "$Script:tempDrive\$script:workingFolder" ){
		$continue = $false
		$erroraction = "stop"
		$cnt = 0
		while(!$continue)
		{
			try
			{
				Remove-Item "$Script:tempDrive\$script:workingFolder" -Force -Recurse -ErrorAction $erroraction
				$continue = $true
			}
			catch
			{
				$cnt += 1
				Write-Debug "unable to remove working folder, attempt # $cnt "
				if($cnt -eq 3){
					Write-Debug "unable to remove working folder, max attempts reached"
					Write-Host $Error[0].Exception;
					break;
				}
				Start-Sleep -Seconds 2
			}
		}
	}
	
	#unload helper modules
	Write-Debug "unloading PerfInsightsHelper.psm1"
	if((Get-Module "PerfInsightsHelper" -ea 0) -ne $null){Remove-Module "PerfInsightsHelper"}



	#unload integration test module
	if((Get-Module "PerfInsightsIntegrationModule" -ea 0) -ne $null){
		Write-Debug "unloading PerfInsightsIntegrationModule.psm1"
		Remove-Module "PerfInsightsIntegrationModule"
	}

	#free up memory
	Write-Debug "Free up memory"
	if (($i % 200) -eq 0)
	{
		[System.GC]::Collect()
	}
	Write-Host "Done." -ForegroundColor Gray
}

function Get-TaskListInfo
{
	header "TaskList"
	
	logmsg "[INFO] Collecting task list..." 

	[array]$tasklistCmd = tasklist.exe /svc
	Write-Debug ("tasklist obj[0] is : {0}" -f ($tasklistCmd[0]) )
	if($tasklistCmd[0].ToString().StartsWith("INFO: No tasks"))
	{
		loginfo "No task list found."
		return
	}else{
		Write-Debug ("tasklist obj containst {0} elements." -f $tasklistCmd.Count )
	}

	$script:tasklistObj = @()

	For ($i=3;$i -lt ($tasklistCmd.Count);$i++)
	{
		$line = $tasklistCmd[$i]
		[string[]]$words = @()

		$words += $line.Substring(0,25).trim()
		$words += $line.Substring(26,8).trim()
		$words += $line.Substring(35,44).trim()
		while($words[2].EndsWith(',')){
			$line = $tasklistCmd[++$i]
			$words[2] += " " + $line.Substring(35,44).trim()
		}
    
		$tasklistItem = New-Object psobject
		Add-Member -InputObject $tasklistItem -MemberType NoteProperty -Name "TaskName" -value $words[0]
		Add-Member -InputObject $tasklistItem -MemberType NoteProperty -Name "PID" -value $words[1]
		Add-Member -InputObject $tasklistItem -MemberType NoteProperty -Name "Services" -value $words[2]
		$script:tasklistObj += $tasklistItem
	}
	
	$tasklistCmd | out-file $script:TaskListLog

	logmsg "[INFO] Tasklist collected."
}

function msinfo
{
	Write-Debug "launching msinfo32.exe"
	$result = &	"msinfo32.exe" "/nfo" "$script:logpath_Logs\$env:computername.nfo"
}

function Pack
{

	# wait for msinfo32 to complete
	$result = Find-ChildProcess | Where-Object {$_.ProcessName -like "msinfo32.exe"}
	if($result -ne $null){
		Write-host "[INFO] Waiting for msinfo32 to complete" -ForegroundColor Gray -NoNewline
	
		Do{
			Start-Sleep -Seconds 2
			$result = Find-ChildProcess | Where-Object {$_.ProcessName -like "msinfo32.exe"}
			Write-Host "." -NoNewline -ForegroundColor Gray
		}while($result -ne $null)

		Write-host "Done." -ForegroundColor Gray
	}

	Write-host "[INFO] Collecting data and compressing" -ForegroundColor Gray

	Update-AppInsightsInstrumentationKey

	# save a copy of script settings file 
	Write-Debug "copying settings file $Script:RuntimeSettingsFilePath to Log output"
	copy-item $Script:RuntimeSettingsFilePath $script:logpath_Logs

	# ZIP file
	
	cd $script:scriptfolder

	If (!(Test-Path "$Script:tempDrive\$script:outputFolder"))
    {
		New-Item "$Script:tempDrive\$script:outputFolder" -ItemType Directory | Out-Null
    }
    $destination = "$Script:tempDrive\$script:outputFolder\CollectedData_$script:StampedDirName.zip"
    If(Test-path $destination) {Remove-item $destination}

	# create zip file
	$ZipFileName = "$Script:tempDrive\$script:outputFolder\CollectedData_$script:StampedDirName.zip"
    $sourceFolder = "$script:logpath"
	$sourceFiles = "$sourceFolder\*.*"
	New-Zip $ZipFileName
	$initZipFileSize = (Get-Item $ZipFileName).length
	$prevZipFileSize = $initZipFileSize
	
	$shellApplication = new-object -com shell.application
	$zipPackage = $shellApplication.NameSpace($zipfilename)
	$zipPackage.CopyHere($sourceFolder)
	
	# wait for file zip compression to complete
	ForEach($i in 1..30) {
		$zipFileSize = (Get-Item $ZipFileName).length
		# wait until the zip file size doesn't change, at least 3 seconds
		if ($i -gt 3 -and $zipFileSize -ne $initZipFileSize -and $zipFileSize -eq $prevZipFileSize) {
			break
		}
		$prevZipFileSize = $zipFileSize
		Write-Debug "Waiting for file zip compression to complete in iteration $i."
		Start-Sleep 1
	}
	$zipFileSize = (Get-Item $ZipFileName).length
	Write-host "[INFO] Output file created: $destination. Its file size is $zipFileSize." -ForegroundColor Green
}

#second zip functions
function New-Zip
{
	param([string]$zipfilename)

	Write-Debug "Entering New-Zip"
	set-content $zipfilename ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 
	(dir $zipfilename).IsReadOnly = $false
	Write-Debug "Exiting New-Zip"
}


function WaitForFile 
{
	param([string]$inputFileName)

    $guid = [Guid]::NewGuid().ToString()
    $tmpFileName = $inputFileName + $guid
	Write-Debug "WaitForFile: inputFileName: $inputFileName"

    # The main idea is to try to rename target ZIP file. If it success then archiving operation is complete.
    $isCompleted = $false
    
	while(!$isCompleted)
    {
		start-sleep -seconds 1

        Rename-Item $inputFileName $tmpFileName -ea 0 #Try to rename with suppressing errors
        if (Test-Path $tmpFileName)
        {
            Rename-Item $tmpFileName $inputFileName #Rename it back
            $isCompleted = $true
        }else{
            Write-Debug "WaitForFile: rename test failed! retry"
			
        }
    }

}

function collectGenPerfCounter()
{
	#stop/delete any existing collector with same name
	$result = &	"logman" "stop" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append
	Start-Sleep -Seconds 3
	$result = &	"logman" "delete" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append

	# if SQL is present, select SQL specific perf trace counters
	if($script:HasSQLInstance)
	{
		logmsg "[INFO] Script will use SQL Performance settings." "Cyan"
		$logmansettings = $Script:LogmanSQLCountersFilePath
		header "Starting SQL Performance Counters"
		$blgfilename = "$env:computername`_SQLCounters.blg"
	}else{
		logmsg "[INFO] Script will use General Performance settings." "Cyan"
		$logmansettings = $Script:LogmanGeneralCountersFilePath
		header "Starting General Performance Counters"
		$blgfilename = "$env:computername`_GeneralCounters.blg"
	}
	
	# start logman
	$result = &	"logman" "create" "counter" "GuestVMPerf" "-cf" $logmansettings "-o" "$script:logpath_Logs\$blgfilename" "-si" "1"	
	$result = &	"logman" "start" "GuestVMPerf"

}

function collectSQLPerfCounter()
{
	#stop/delete any existing collector with same name
	$result = &	"logman" "stop" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append
	Start-Sleep -Seconds 3
	$result = &	"logman" "delete" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append

	logmsg "[INFO] Script will use SQL Performance settings." "Cyan"
	$logmansettings = $Script:LogmanSQLCountersFilePath
	header "Starting SQL Performance Counters"
	# start logman
	$result = &	"logman" "create" "counter" "GuestVMPerf" "-cf" $logmansettings "-o" "$script:logpath_Logs\$env:computername`_SQLCounters.blg" "-si" "1"
	$result = &	"logman" "start" "GuestVMPerf"

}

function collectSMBCounter()
{
	#stop/delete any existing collector with same name
	$result = &	"logman" "stop" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append
	Start-Sleep -Seconds 3
	$result = &	"logman" "delete" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append

	logmsg "[INFO] Script will use SMB Performance settings." "Cyan"

	# start logman
	header "Starting SMB Performance Counters"
	$result = &	"logman" "create" "counter" "GuestVMPerf" "-c" "\SMB Client Shares(*)\*" "-o" "$script:logpath_Logs\$env:computername`_SMBCounters.blg" "-si" "1"	
	$result = &	"logman" "start" "GuestVMPerf"	
}

function StartPerfCounter()
{
	header "Starting Performance Counters"
	Write-Debug "StartPerfCounter"
	#stop/delete any existing collector with same name
	$result = &	"logman" "stop" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append
	Start-Sleep -Seconds 3
	$result = &	"logman" "delete" "GuestVMPerf"
	$result | Out-File $Script:GuestStorageLog -Append
	
	#Dialog for Performance troubleshooting
	#if($nogui){

	Write-Debug "HasSQLInstance : $script:HasSQLInstance"
	$result = if($script:HasSQLInstance){2}else{1}

	#}else{
	#	do{
	#		$result = [Microsoft.VisualBasic.Interaction]::InputBox("Choose mode:`n`n(1) General Performance`n(2) SQL Server Performance`n`nDefault is 1", "Select Performance Troubleshooting mode", "1")
	#		# if user cancel, redirect to "skip"
	#		if($result -eq ""){$result = 3}
	#		write-debug "User choose option $result"
	#	}while (!($result -match "^([1-2])$"))
	#}

	switch ($result)
	{
		2 {
			logmsg "[INFO] Script will use SQL Server Performance settings." "Cyan"
			$script:Perfselect = $script:SQLPerformance
			$logmansettings = $Script:LogmanSQLCountersFilePath
		}
		1 {
			logmsg "[INFO] Script will use General Performance settings." "Cyan"
			$script:Perfselect = $script:GeneralPerformance
			$logmansettings = $Script:LogmanGeneralCountersFilePath
		}
		default
		{
			logmsg "[INFO] Script skip collecting the performance counters." "Cyan"
			return
		}	
	}

	logmsg "[INFO] Starting Performance Counter tracing"
	# start logman
	$result = &	"logman" "create" "counter" "GuestVMPerf" "-cf" $logmansettings "-o" "$script:logpath_Logs\$env:computername.blg" "-si" "1"	
	$result = &	"logman" "start" "GuestVMPerf"
	
}

function StopPerfCounter()
{
	param(
	# by default show dialog or wait before stopping trace collection
	[bool] $skipdialog=$false
	)

	if(!$skipdialog)
	{
		StopTraceDialog( "Performance Counter Trace")
	}
	
	header "Stopping Performance Counter trace"

	try{	
		logmsg "[INFO] Stopping Performance Counter tracing"
		$result = &	"logman" "stop" "GuestVMPerf"
		#create CSV output files for performance counter traces: IOPS, MBPS, IO size, Latency, QD, Split IO
		$GENc = "$script:logpath_Logs\$env:computername`_GeneralCounters*.blg"
		$SQLc = "$script:logpath_Logs\$env:computername`_SQLCounters*.blg"
	
		If (Test-Path $GENc){
			relog -f CSV $GENc -c "\PhysicalDisk(*)\Disk Transfers/sec" -o "$script:logpath_Logs\General_IOPS.csv"
			relog -f CSV $GENc -c "\PhysicalDisk(*)\Disk Bytes/sec" -o "$script:logpath_Logs\General_MBPS.csv"
			relog -f CSV $GENc -c "\PhysicalDisk(*)\Avg. Disk Bytes/Transfer" -o "$script:logpath_Logs\General_IOsize.csv"
			relog -f CSV $GENc -c "\PhysicalDisk(*)\Avg. Disk sec/Transfer" -o "$script:logpath_Logs\General_Latency.csv"
			relog -f CSV $GENc -c "\PhysicalDisk(*)\Current Disk Queue Length" -o "$script:logpath_Logs\General_QD.csv"
			relog -f CSV $GENc -c "\PhysicalDisk(*)\Split IO/Sec" -o "$script:logpath_Logs\General_SplitIO.csv"	

			$trace_obj = New-Object -TypeName psobject

			If (Test-Path "$script:logpath_Logs\General_IOPS.csv"){
			$iopsobj = (Get-Content "$script:logpath_Logs\General_IOPS.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			$iopsobj = $iopsobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			$iopsobj = $iopsobj.Replace("\\\\$env:computername\\PhysicalDisk(_Total)\Disk Transfers/sec","totaliops")
			$iopsobj = $iopsobj.Replace("\\\\$env:computername\\PhysicalDisk(*)\Disk Transfers/sec","iops")
			Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "iopsobj" -Value $iopsobj
			Remove-Item "$script:logpath_Logs\General_IOPS.csv" -Force
			}

			#If (Test-Path "$script:logpath_Logs\General_MBPS.csv"){
			#$mbpsobj = (Get-Content "$script:logpath_Logs\General_MBPS.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$mbpsobj = $mbpsobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "mbpsobj" -Value $mbpsobj
			#Remove-Item "$script:logpath_Logs\GGeneral_MBPS.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_IOsize.csv"){
			#$iosizeobj = (Get-Content "$script:logpath_Logs\General_IOsize.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json 
			#$iosizeobj = $iosizeobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "iosizeobj" -Value $iosizeobj
			#Remove-Item "$script:logpath_Logs\General_IOsize.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_Latency.csv"){
			#$latencyobj = (Get-Content "$script:logpath_Logs\General_Latency.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$latencyobj = $latencyobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "latencyobj" -Value $latencyobj
			#Remove-Item "$script:logpath_Logs\General_Latency.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_QD.csv"){
			#$qdobj = (Get-Content "$script:logpath_Logs\General_QD.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$qdobj = $qdobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "qdobj" -Value $qdobj
			#Remove-Item "$script:logpath_Logs\General_QD.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_SplitIO.csv"){
			#$splitioobj = (Get-Content "$script:logpath_Logs\General_SplitIO.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json 
			#$splitioobj = $splitioobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "splitioobj" -Value $splitioobj
			#Remove-Item "$script:logpath_Logs\General_SplitIO.csv" -Force
			#}
		
			#Start commening Tracing feature
			#$traceJS = ConvertTo-PS2JS -inputObject $trace_obj -variablename "traceObj" 
			#$traceJS | Out-File -filepath $script:TraceJS

			#(Get-Content $script:TraceJS) -replace '\\' -replace '"\[', '[' -replace ']\"', ']' |   Out-File $script:TraceJS
			#End commening Tracing feature
		}
		If (Test-Path $SQLc){
			relog -f CSV $SQLc -c "\PhysicalDisk(*)\Disk Transfers/sec" -o "$script:logpath_Logs\General_IOPS.csv"
			relog -f CSV $SQLc -c "\PhysicalDisk(*)\Disk Bytes/sec" -o "$script:logpath_Logs\General_MBPS.csv"
			relog -f CSV $SQLc -c "\PhysicalDisk(*)\Avg. Disk Bytes/Transfer" -o "$script:logpath_Logs\General_IOsize.csv"
			relog -f CSV $SQLc -c "\PhysicalDisk(*)\Avg. Disk sec/Transfer" -o "$script:logpath_Logs\General_Latency.csv"
			relog -f CSV $SQLc -c "\PhysicalDisk(*)\Current Disk Queue Length" -o "$script:logpath_Logs\General_QD.csv"
			relog -f CSV $SQLc -c "\PhysicalDisk(*)\Split IO/Sec" -o "$script:logpath_Logs\General_SplitIO.csv"	 


			$trace_obj = New-Object -TypeName psobject

			If (Test-Path "$script:logpath_Logs\General_IOPS.csv"){
			$iopsobj = (Get-Content "$script:logpath_Logs\General_IOPS.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			$iopsobj = $iopsobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			$iopsobj = $iopsobj.Replace("\\\\$env:computername\\PhysicalDisk(_Total)\Disk Transfers/sec","totaliops")
			$iopsobj = $iopsobj.Replace("\\\\$env:computername\\PhysicalDisk(*)\Disk Transfers/sec","iops")
			Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "iopsobj" -Value $iopsobj
			Remove-Item "$script:logpath_Logs\General_IOPS.csv" -Force
			}
			#If (Test-Path "$script:logpath_Logs\General_MBPS.csv"){
			#$mbpsobj = (Get-Content "$script:logpath_Logs\General_MBPS.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$mbpsobj = $mbpsobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")		
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "mbpsobj" -Value $mbpsobj 
			#Remove-Item "$script:logpath_Logs\General_MBPS.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_IOsize.csv"){
			#$iosizeobj = (Get-Content "$script:logpath_Logs\General_IOsize.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$iosizeobj = $iosizeobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "iosizeobj" -Value $iosizeobj
			#Remove-Item "$script:logpath_Logs\General_IOsize.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_Latency.csv"){
			#$latencyobj = (Get-Content "$script:logpath_Logs\General_Latency.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$latencyobj = $latencyobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time") 
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "latencyobj" -Value $latencyobj
			#Remove-Item "$script:logpath_Logs\General_Latency.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_QD.csv"){
			#$qdobj = (Get-Content "$script:logpath_Logs\General_QD.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$qdobj = $qdobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "qdobj" -Value $qdobj
			#Remove-Item "$script:logpath_Logs\General_QD.csv" -Force
			#}
			#If (Test-Path "$script:logpath_Logs\General_SplitIO.csv"){
			#$splitioobj = (Get-Content "$script:logpath_Logs\General_SplitIO.csv" -Raw | ConvertFrom-CSV) | ConvertTo-Json
			#$splitioobj = $splitioobj.Replace("(PDH-CSV 4.0) (Coordinated Universal Time)(0)","time")
			#Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "splitioobj" -Value $splitioobj
			#Remove-Item "$script:logpath_Logs\General_SplitIO.csv" -Force
			#}
				
			#Start commenting Tracing feature		
			#$traceJS = ConvertTo-PS2JS -inputObject $trace_obj -variablename "traceObj" 
			#$traceJS | Out-File -filepath $script:TraceJS

			#(Get-Content $script:TraceJS) -replace '\\' -replace '"\[', '[' -replace ']\"', ']' |   Out-File $script:TraceJS
			#End commenting Tracing feature

		}
	}catch{
		logmsg "[INFO] Performance Counter tracing already stopped"
	}
}

function StartStorport()
{
	header "Starting Storport"
	#stop any existing collector with same name
	Write-Debug "storport, trying to stop any existing storport traces"
	$result = &	"logman" "stop" "storport" "-ets"
	$result | Out-File $Script:GuestStorageLog -Append

	Write-Debug "storport, start new trace"
	$result = &	"logman" "create" "trace" "storport" "-ow" "-o" "$script:logpath_Logs\storport.etl" "-p" "Microsoft-Windows-StorPort" "0xffffffffffffffff" "0xff" "-nb" "16" "16" "-bs" "1024" "-mode" "Circular" "-f" "bincirc" "-max" "4096" "-ets"

	return $true
}

function StartTraceDialog([string] $toolname)
{
	if(!$NoGUI){
		# wait for user to proceed
		$buttons=[system.windows.forms.messageboxbuttons]::OKCancel;
	    $diag =[system.windows.forms.messagebox]::Show("Please, click OK to start the $toolname trace. Please make sure the performance issue is ongoing. Otherwise it might not capture useful information.","Starting $toolname Trace",$buttons,[System.Windows.Forms.MessageBoxIcon]::Information);

		if($diag -ne "OK"){
			Write-Debug "User aborted"
			logmsg "[INFO] Skipping $toolname data collection. User canceled operation."
			return $false
		}
	}else{
		Write-Debug "$toolname, nogui mode enabled, skipping the request to start trace"
	}
	return $true
}

function StopTraceDialog([string] $msg){
	if($NoGUI){
		Write-Debug "starting to sleep for $script:TracingDuration seconds."
		start-sleep -Seconds $script:TracingDuration
	}else{
		$buttons=[system.windows.forms.messageboxbuttons]::OK;
	    $diag =[system.windows.forms.messagebox]::Show("Please, click OK to stop $msg","Stopping $msg",$buttons,[System.Windows.Forms.MessageBoxIcon]::Information);
	}
}

function StartXPerf()
{
	header "Starting XPerf"

	$res = StartTraceDialog("XPerf")
	if(!$res){ return $res }
	
	# run xperf
	cd "$Script:xperfWorkingFolder" 
	Write-Debug "Running Xperf for General"
	#.\XPERF -on PROC_THREAD+LOADER+FLT_IO_INIT+FLT_IO+FLT_FASTIO+FLT_IO_FAILURE+FILENAME+FILE_IO+FILE_IO_INIT+DISK_IO+HARD_FAULTS+DPC+INTERRUPT+CSWITCH+PROFILE+DRIVERS+DISPATCHER -stackwalk MiniFilterPreOpInit+MiniFilterPostOpInit+CSWITCH+PROFILE+ThreadCreate+ReadyThread+DiskReadInit+DiskWriteInit+DiskFlushInit+FileCreate+FileCleanup+FileClose+FileRead+FileWrite -BufferSize 1024 -MaxBuffers 1024 -MaxFile 200 -FileMode Circular -f $script:logpath_Logs\xperftrace.etl
	.\XPERF -on PROC_THREAD+LOADER+FLT_IO_INIT+FLT_IO+FLT_FASTIO+FLT_IO_FAILURE+FILENAME+FILE_IO+FILE_IO_INIT+DISK_IO+HARD_FAULTS+DPC+INTERRUPT+CSWITCH+PROFILE+DRIVERS+DISPATCHER -stackwalk MiniFilterPreOpInit+MiniFilterPostOpInit+CSWITCH+PROFILE+ThreadCreate+ReadyThread+DiskReadInit+DiskWriteInit+DiskFlushInit+FileCreate+FileCleanup+FileClose+FileRead+FileWrite -BufferSize 1024 -MaxBuffers 1024 -MaxFile 200 -FileMode Circular -f $script:logpath_Logs\xperftrace.kernel.etl

	return $true
}


function StartNWtrace()
{
	header "Starting Network Trace"

	$res = StartTraceDialog("Network")
	if(!$res){ return $res }

	#run netsh
	netsh TRACE START CAPTURE=yes maxsize=200 filemode=circular overwrite=yes TRACEFILE="$script:logpath_Logs\networktrace.etl" 

	return $true
}

function StartPerformanceDiagnostics
{
	param([bool]$showStartUI=$false, [bool]$runBenchmark)

	Write-Debug "StartPerformanceDiagnostics, showStartUI=$showStartUI, runBenchmark=$runBenchmark"
	if ((IsClrV4InPowerShell) -eq $false)
	{
		logmsg "[INFO] CLR version on this machine doesn't support Performance Diagnostics feature"
		return $false
	}

	header "Starting Performance Diagnostics"

	if ($showStartUI) {
		$res = StartTraceDialog("Performance Diagnostics")
	    if(!$res){ return $res }
	}

	[System.Reflection.Assembly]::LoadFrom($Script:traceEventAssemblyPath)
	[System.Reflection.Assembly]::LoadFrom($Script:diagnosticsAssemblyPath)
	[System.Reflection.Assembly]::LoadFrom($Script:sqlDmfAssemblyPath)
	$Script:ruleEngineFactory = New-Object Microsoft.Azure.Performance.Diagnostics.RuleEngineFactory($Script:PerformanceDiagnosticsLog, $true)
	$Script:ruleEngine = $Script:ruleEngineFactory.CreateRuleEngine()
	$configContent = [IO.File]::ReadAllText($Script:ruleEngineConfigFilePath)

	# intentionally disable HighResolutionDiskRule for benchmark, since the created perfdiag.js file might be
	# too big to open in browser.
	if ($runBenchmark) {
		# remove HighResolutionDiskRuleConfiguration section so ugly because PowerShell 2.0(on WS2008R2) doesn't support ConvertFrom-Json
		$startRuleName = $configContent.IndexOf("HighResolutionDiskRuleConfiguration")
		$startRule = $configContent.LastIndexOf("{", $startRuleName)
		$endRule = $configContent.IndexOf("{", $startRuleName)
		$configContent = $configContent.Substring(0, $startRule) + $configContent.Substring($endRule)
	}

	$Script:ruleEngine.Start($configContent)

	return $true
}

function StopPerformanceDiagnostics()
{
	if ($Script:ruleEngine -eq $null) {
		return;
	}
	$Script:ruleEngine.Stop()
	$ruleResults = $Script:ruleEngine.GetResults()
	$Script:ruleEngine.SaveResultsAsJsFile($script:PerfDiagJS, "perfDiagObj")

	if ($ruleResults.Results.Length -gt 0) {
		[Microsoft.Azure.Performance.Diagnostics.Rules.HighCpuRule.HighCpuRuleResult]$highCpuRuleResult = $ruleResults.Results | Where-Object {$_.RuleName -eq "HighCpuRule"}
		[Microsoft.Azure.Performance.Diagnostics.Rules.HighDiskRule.HighDiskRuleResult]$highDiskRuleResult = $ruleResults.Results | Where-Object {$_.RuleName -eq "HighDiskRule"}
		[Microsoft.Azure.Performance.Diagnostics.Rules.HighMemoryRule.HighMemoryRuleResult]$highMemoryRuleResult = $ruleResults.Results | Where-Object {$_.RuleName -eq "HighMemoryRule"}

		if ($highCpuRuleResult -ne $null -and $highCpuRuleResult.HighProcessorsUsagePeriods -ne $null -and $highCpuRuleResult.HighProcessorsUsagePeriods.Length -gt 0)
		{
			logWarn "High CPU usage periods were detected. Look <a href='#' onclick='return OpenHighCpuConsumersLocation();'>Top CPU Consumers tab</a> for further details "
		}

		if ($highDiskRuleResult -ne $null -and $highDiskRuleResult.HighDisksUsagePeriods -ne $null -and $highDiskRuleResult.HighDisksUsagePeriods.Length -gt 0)
		{
			logWarn "High Disk usage periods were detected. Look <a href='#' onclick='return OpenHighDiskConsumersLocation();'>Top Disk Consumers tab</a> for further details "
		}

	    if ($highMemoryRuleResult -ne $null -and $highMemoryRuleResult.HighMemoryUsagePeriods -ne $null -and $highMemoryRuleResult.HighMemoryUsagePeriods.Length -gt 0)
		{
			logWarn "High Memory usage periods were detected. Look <a href='#' onclick='return OpenHighMemoryConsumersLocation();'>Top Memory Consumers tab</a> for further details "
		}
	}
	$Script:ruleEngineFactory.Dispose()
}

function verb([string] $msg = "", [string] $color = "Gray") 
{
	if($verbose){
		#prepare message
		$datetimenow = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
		$msgToWrite = "[$datetimenow]:[VERB] $msg"
	
		# write on console output using defined color
		Write-Host $msgToWrite -ForegroundColor $color
	
		# append to app log file
		$msgToWrite  | Out-File $Script:GuestStorageLog -Append
	}
}

function logmsg ([string] $msg = "", [string] $color = "Gray") 
{
	#prepare message
	$datetimenow = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
	$msgToWrite = "[$datetimenow]:"
	
	# write on console output using defined color
	Write-Host $msgToWrite -NoNewline -ForegroundColor Gray
	Write-Host $msg -ForegroundColor $color
	# append to app log file
	($msgToWrite + $msg) | Out-File $Script:GuestStorageLog -Append
}

function logInfo
{
	param(
		[string] $m, [switch]$NoConsole=$false)
		if(!$NoConsole){logmsg "[INFO] $m"}
		Log-HA $m -Class info -ClassScore 3
}
function logWarn
{
	param(
		[string] $m, [switch]$NoConsole=$false)
		if(!$NoConsole){logmsg "[WARN] $m"}
		Log-HA $m -Class warning -ClassScore 2
}
function logErr
{
	param(
		[string] $m, [switch]$NoConsole=$false)
		if(!$NoConsole){logmsg "[ERROR] $m" "yellow"}
		Log-HA $m -Class danger -ClassScore 1
}

function Header($title)
{
	Write-Host "`n"
	
	$m = "=========================================================================================================="
	Write-Host $m -ForegroundColor Gray
	$m | Out-File $Script:GuestStorageLog -Append

	$m=  "`t`t$title" 
	Write-Host $m -ForegroundColor Gray
	$m | Out-File $Script:GuestStorageLog -Append
	
	$m = "=========================================================================================================="
	Write-Host $m -ForegroundColor Gray
	$m | Out-File $Script:GuestStorageLog -Append

	Write-Host "`n"
}

function ShutDown()
{
	header "Shut Down"

	Finalize
	Pack
	if($Integrationtestmode -ne ""){
	$logname = "$Integrationtestmode.zip"

	Rename-Item "$Script:tempDrive\$script:outputFolder\CollectedData_$script:StampedDirName.zip" $logname
	
	UploadLogs -logname $logname -filepath "$Script:tempDrive\$script:outputFolder" -scriptfolder $scriptfolder
	}
	Cleanup
}

# SRC

function CollectStartupSRC
{
	header "Storage Reliability Counters (Startup)"

	$script:SRC_Startup_Obj = Get-StorageReliabilityCounters ("Startup")
	Reset-StorageReliabilityCounters
}

function Get-StorageReliabilityCounters ([string] $phase)
{
	if($os -eq "Win8orWin10")
	{
		$msg = ("Collecting storage reliability counter for disks ({0})..." -f $phase)
		loginfo $msg
		$msg | Out-File $Script:SRCLog -Append

		$table = Get-physicaldisk | Get-StorageReliabilityCounter | Select-Object Deviceid, FlushLatencyMax, ReadLatencyMax, WriteLatencyMax, ObjectId
		$table | Out-File $Script:SRCLog -Append

	}
	return $table
}

function Reset-StorageReliabilityCounters
{
	if($os -eq "Win8orWin10")
	{
		loginfo "Reset storage reliability counter..."
		"`nReset Storage Reliability Counters" | Out-File $Script:SRCLog -Append
		try
		{
			#try run with dingle disks as argument
			forEach ($disk in Get-physicaldisk)
			{
				$diskout = $disk | Reset-StorageReliabilityCounter -ea 0	
			}
		}catch{
			try
			{
				# try running the command with no arguments
				Reset-StorageReliabilityCounter -ea 0
			}catch{
				loginfo "Unable to reset stroage reliability counters. Check output file."
				$Error[0].Exception | Out-File $Script:SRCLog -Append
			}
		}
	}
}

# get fsutil 

function Get-FsUtil
{
	header "fsutil fsinfo ntfsinfo (all volumes)"
		
	# fsutil
	$drives = get-volumeMap | Where-Object {$_.IsPartition} |Select VolumeID

	$script:fsutilObj = @()

	if($drives -ne $null){
		write-debug "Collecting FsUtil..."

		#loop over drives
		$drives | %{
			$fsutilcmd = fsutil fsinfo ntfsinfo $_.VolumeID
					
			$item = New-Object psobject
			Add-Member -InputObject $item -MemberType NoteProperty -Name "VolumeID" -Value $_.VolumeID
			$fsutilcmd | %{
				$a = $_.split(":")
				Add-Member -InputObject $item -MemberType NoteProperty -Name $a[0].trim().replace(' ', '_') -Value $a[1].trim()
			}
			
			# fix RMI identifier
			if( (Get-Member -InputObject $item -Name "Resource_Manager_Identifier") -eq $null){
				$val = if($item.RM_Identifier -ne $null){$item.RM_Identifier}else{$null}
				Add-Member -InputObject $item -MemberType NoteProperty -Name "Resource_Manager_Identifier" -Value $val
			}

			#fix LFS identifier
			if( (Get-Member -InputObject $item -Name "LFS_Version") -eq $null){
				Add-Member -InputObject $item -MemberType NoteProperty -Name "LFS_Version" -Value $null
			}

			# fix NTFS Version
			if( (Get-Member -InputObject $item -Name "NTFS_Version") -eq $null){
				$val = if($item.Version -ne $null){$item.Version}else{$null}
				Add-Member -InputObject $item -MemberType NoteProperty -Name "NTFS_Version" -Value $val
			}

			$script:fsutilObj += $item

			("VolumeID : {0}" -f $_.VolumeID) | out-file $script:fsutilLog -append
			$fsutilcmd  | out-file $script:fsutilLog -append
			""| out-file $script:fsutilLog -append
		}
		write-debug "Collecting FsUtil completed."

		loginfo "Collecting FsUtil completed."
	}
	
	#check fsutil DisableDeleteNotify
	$ddn = fsutil behavior query DisableDeleteNotify
	# on wind 10 the command may return multiple lines
	if($ddn.count -gt 1){
		$ddn = fsutil behavior query DisableDeleteNotify NTFS
	}
	loginfo $ddn
}

# Check filter driver
function Get-FilterDriver
{
	header "Filter driver (fltmc.exe)"
	
	$fltmc=fltmc.exe

	if($fltmc.length -eq $null)
	{
		loginfo "No Filter drivers found." 
		return
	}

	write-debug "Collecting filter drivers"
	
	$script:filterdriversObj = @()

	For ($i=3;$i -lt ($fltmc.Count);$i++)
	{
		$line = $fltmc[$i]
		[string[]]$words = @()

		$words = $line.Split(' ',[System.StringSplitOptions]::RemoveEmptyEntries)

		$item = New-Object psobject
		Add-Member -InputObject $item -MemberType NoteProperty -Name "FilterName" -value $words[0]
		Add-Member -InputObject $item -MemberType NoteProperty -Name "NumInstances" -value $words[1]
		Add-Member -InputObject $item -MemberType NoteProperty -Name "Altitude" -value $words[2]
		Add-Member -InputObject $item -MemberType NoteProperty -Name "Frame" -value $words[3]
		$script:filterdriversObj += $item
	}
	
	write-debug "Filter drivers collected."

	loginfo "Filter drivers collected."

	$fltmc | Out-File $Script:FilterDriversLog -Append
	
}

function Finalize ()
{

	$script:SRC_Shutdown_Obj = Get-StorageReliabilityCounters ("Shutdown")

	$script:VMOverviewObj = New-Object -TypeName psobject
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "VMName" -Value $env:computername
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "ScriptVersion" -Value $script:ver
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "Scenario" -Value $Script:runselection
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "OSVersion" -Value $Script:OSVer
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "TempDrive" -Value $Script:tempdrive
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "SRNumber" -Value $script:SRNumber
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "ExecutionTime" -Value $script:ExecutionTime
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "CommandLine" -Value $Script:commandline
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "VMSize" -Value $Script:VMSize
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "HasSQLInstance" -Value $Script:HasSQLInstance
	Add-Member -InputObject $script:VMOverviewObj  -MemberType NoteProperty -Name "SQLInstanceCount" -Value $script:SQLInstanceCount 
	# flush the findings into json formatted object
	# save the json file into output file
	if ($script:findings_Obj.Count -gt 0) {
	    $script:findings_Obj = $script:findings_Obj | sort ClassScore, Time | select Value, Message, Time,EventId,Entity,Class, Misc, ClassScore, Value1
	}
	
	$main_obj = New-Object -TypeName psobject
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "FindingsObj" -Value $script:findings_Obj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "TasklistObj" -Value $script:tasklistObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "NetstatObj" -Value $script:NetstatObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "tcpipregObj" -Value $script:tcpipregObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "throughputObj" -Value $script:throughputObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "interfaceObj" -Value $script:interfaceObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "mtuObj" -Value $script:mtuObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "tcpglobalObj" -Value $script:tcpglobalObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "tcpipverslObj" -Value $script:tcpipverslObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "smbconfigObj" -Value $script:smbconfigObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "FirewallObj" -Value $script:FirewallObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "FsutilObj" -Value $script:fsutilObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "FilterDriversObj" -Value $script:FilterDriversObj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "SRC_StartupObj" -Value $script:SRC_Startup_Obj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "SRC_ShutdownObj" -Value $script:SRC_Shutdown_Obj
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "DiskObj" -Value (Get-ReversedVolumeMap | sort DiskNumber)
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "VolumeObj" -Value (get-volumeMap | sort VolumeNumber)
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "EventsObj" -Value $script:masterGuestEvents

	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "VMOverviewObj" -Value $script:VMOverviewObj

	$script:DiskOverview = New-Object -TypeName psobject
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "AllDiskpartObj" -Value $script:DiskOverview_AllDiskpartObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "AllSpaceportObj" -Value $script:DiskOverview_AllSpaceportObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "AllVolumesObj" -Value $script:DiskOverview_AllVolumesObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "MultiVolumesDiskObj" -Value $script:DiskOverview_MultiVolumesDiskObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "AUSObj" -Value $script:DiskOverview_AUSObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "PoolsObj" -Value $script:DiskOverview_PoolsObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "AutoClusterObj" -Value $script:DiskOverview_AutoClusterObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "VirtualDisksObj" -Value $script:DiskOverview_VirtualDisksObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "PooledDisksObj" -Value $script:DiskOverview_PooledDisksObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "MultiVirtualDiskPoolesObj" -Value $script:DiskOverview_MultiVirtualDiskPoolesObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "WrongNOCObj" -Value $script:DiskOverview_WrongNOCObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "WrongInterleaveObj" -Value $script:DiskOverview_WrongInterleaveObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "wrongResiliencySettingObj" -Value $script:DiskOverview_wrongResiliencySettingObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "wrongRAIDObj" -Value $script:DiskOverview_wrongRAIDObj
	Add-Member -InputObject $script:DiskOverview  -MemberType NoteProperty -Name "RAIDObj" -Value $script:DiskOverview_RAIDObj

	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "DiskOverview" -Value $script:DiskOverview
	
	Add-Member -InputObject $main_obj  -MemberType NoteProperty -Name "SQLObj" -Value $script:SQL_Obj

	$findingsLogsJS = ConvertTo-PS2JS -inputObject $main_obj -variablename "outputObj" 
	$findingsLogsJS | Out-File $script:FindingsJS 

	$mainJson_obj = New-Object -TypeName psobject
	Add-Member -InputObject $mainJson_obj -MemberType NoteProperty -Name "array" -Value $script:findings_Obj

	$findingsLogsJSon = ConvertTo-PS2JSon -inputObject $mainJson_obj
	$findingsLogsJSon | Out-File $script:FindingsJSon

	loginfo "Finalize completed. This should be the last entry in the output file."
}

# check if required files are available, exit the script otherwise
function CheckForSettingsFiles()
{
	$success = $true

	$list = @()
	$list += $Script:RuntimeSettingsFilePath
	$list += $Script:LogmanGeneralCountersFilePath
	$list += $Script:LogmanSQLCountersFilePath
	$list += $Script:PerfInsightsHelperFilePath
	$list += $script:vmlookupFilePath
	$list += $script:SCSIInsightsFilePath
	$list += $Script:ReportFilePath

	if($IntegrationTestMode -ne ""){
		$list += $script:PerfInsightsIntegrationModuleFilePath
	}

	# loop over list of setting files
	$list | %{
		If(!(Test-Path $_))
		{
			Write-Error "[CRITICAL] Unable to locate required script file: $_." -Category ObjectNotFound -RecommendedAction "Please make sure file $_ is on same location of $script:scriptFileName"
			$success = $false
		}
	}
	
	If(!$success)
	{
		"[CRITICAL] Script execution is aborted." 
		Exit
	}
}

function Check-ThroughputOptimized()
{
	Write-Debug "Checking Throughput Optimization Enabled..."
	try{
		$tp = (Get-NetAdapterRss).Enabled
		Write-Debug "Checking Throughput Optimization Enabled Completed = $tp"
		
		if ($tp)
		{
			loginfo "Network throughput optimization enabled"
		}
		else
		{
			logwarn "Network throughput optimization not enabled, for further information see <a href='#' onclick='return OpenNetworkLocation();'>Network tab</a>"
			$script:throughputObj = @()
			$throughputlink = "<a target='_blank' href='https://docs.microsoft.com/en-us/azure/virtual-network/virtual-network-optimize-network-bandwidth'>Network throughput optimization</a>"
			$networkItemthroughput = New-Object psobject
		    Add-Member -InputObject $networkItemthroughput -MemberType NoteProperty -Name "throughputlink" -value $throughputlink
			$script:throughputObj += $networkItemthroughput
		}

	}catch{
		Write-Debug "Throughput Optimization Enabled is not supported for current OS."
	}
	
}

function CheckForKBs()
{
	header "Check For Important KBs"
	
	$ver = [System.Environment]::OSVersion.Version

	# only on OS 6.3 - Win Srv 2012 R2 - Win 8.1
	IF (Test-OSVersion -major 6 -minor 3)
	{

		Write-Debug "checking KB3153887"
        try
		{
			Get-HotFix -Id KB3153887 -ErrorAction Stop
			loginfo "KB3153887 is installed"
        }
		catch
		{
			try
			{
				Get-HotFix -Id KB3161606 -ErrorAction Stop
				loginfo "KB3153887, included in KB3161606 is installed"
			}
			catch
			{
				try
				{
					Get-HotFix -Id KB3172614 -ErrorAction Stop
					loginfo "KB3153887, included in KB3172614 is installed"
				}
				catch
				{
					logwarn "KB3153887 is not installed, but please consider installing it: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3153887'>KB3153887</a>"
				}
			}
        }

		Write-Debug "checking KB3000850"
		try{
			Get-HotFix -Id KB3000850 -ErrorAction Stop
			loginfo "KB3000850 is installed"
		}catch{
			logwarn "KB3000850 is not installed, but please consider installing it: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3000850'>KB3000850</a>"
		}

		Write-Debug "checking KB3063075"
		try{
			$file = Get-Item "$env:windir\system32\drivers\spaceport.sys"
			loginfo ("SPACEPORT.SYS file version = {0}.{1}.{2}.{3}" -f $file.VersionInfo.FileMajorPart, $file.VersionInfo.FileMinorPart, $file.VersionInfo.FileBuildPart ,$file.VersionInfo.FilePrivatePart)
			$check = Test-FileVersion $file.VersionInfo 6 3 9600 17819
			If ($check -eq $true)
			{
				loginfo "KB3063075 or higher hotfix is already installed."
			}
			else
			{
				Get-HotFix -Id KB3063075 -ErrorAction Stop
			}
		}catch{
			#$found = check129
			If ($script:HasEvt129)
			{
				logerr "KB3063075 is not installed - Found Event ID 129 on System Event Logs, please install: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3063075'>KB3063075</a>"
			}
			else
			{
				logwarn "KB3063075 is not installed - Haven't found Event ID 129 on System Event Logs, but please consider installing: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3063075'>KB3063075</a>"
			}
		}

		Write-Debug "checking KB3033930"
		try{
			$file = Get-Item "$env:windir\system32\drivers\afd.sys"
			loginfo ("AFD.SYS file version = {0}.{1}.{2}.{3}" -f $file.VersionInfo.FileMajorPart, $file.VersionInfo.FileMinorPart, $file.VersionInfo.FileBuildPart ,$file.VersionInfo.FilePrivatePart)
			$check = Test-FileVersion $file.VersionInfo 6 3 9600 17663
			If ($check -eq $true)
			{
				loginfo "KB3033930 or higher hotfix is already installed."
			}
			else
			{
				Get-HotFix -Id KB3033930 -ErrorAction Stop
			}
		}catch{
			logwarn "KB3033930 is not installed, but please consider installing it: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3033930'>KB3033930</a>"
		}

		Write-Debug "checking KB3114025"
		try{
			$file = Get-Item "$env:windir\system32\drivers\Mrxsmb.sys"
			loginfo ("MRXSMB.SYS file version = {0}.{1}.{2}.{3}" -f $file.VersionInfo.FileMajorPart, $file.VersionInfo.FileMinorPart, $file.VersionInfo.FileBuildPart ,$file.VersionInfo.FilePrivatePart)
			$check = Test-FileVersion $file.VersionInfo 6 3 9600 18123
			If ($check -eq $true)
			{
				loginfo "KB3114025 or higher hotfix is already installed."
			}
			else
			{
				Get-HotFix -Id KB3114025 -ErrorAction Stop
			}
		}catch{
			logwarn "KB3114025 is not installed, but please consider installing it: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3114025'>KB3114025</a>"
		}

	}

}

function Get-NetstatInfo()
{
	header "Netstat"
	logmsg "[INFO] Collecting Netstat..."

	$script:NetstatObj = @()
    $Computer = Get-WmiObject -Class Win32_ComputerSystem
	$processes = Get-Process -ComputerName $Computer.Name  -ErrorAction stop | select name, id
	$results = netstat -ano | Select-String -Pattern '\s+(TCP|UDP)'
	foreach($result in $results) {
            
    	            $item = $result.line.split(' ',[System.StringSplitOptions]::RemoveEmptyEntries)
    
    	            if($item[1] -notmatch '^\[::'){
                    
                        #parse the netstat line for local address and port
    	                    if (($la = $item[1] -as [ipaddress]).AddressFamily -eq 'InterNetworkV6'){
    	                        $localAddress = $la.IPAddressToString
    	                        $localPort = $item[1].split('\]:')[-1]
    	                    }
    	                    else {
    	                        $localAddress = $item[1].split(':')[0]
    	                        $localPort = $item[1].split(':')[-1]
    	                    }
                    
                        #parse the netstat line for remote address and port
    	                    if (($ra = $item[2] -as [ipaddress]).AddressFamily -eq 'InterNetworkV6'){
    	                        $remoteAddress = $ra.IPAddressToString
    	                        $remotePort = $item[2].split('\]:')[-1]
    	                    }
    	                    else {
    	                        $remoteAddress = $item[2].split(':')[0]
    	                        $remotePort = $item[2].split(':')[-1]
    	                    }
    	    		
                        #parse the netstat line for other properties
    	    		        $procId = $item[-1]
    	    		        $proto = $item[0]
    	    		        $status = if($item[0] -eq 'tcp') {$item[3]} else {$null}	
                        
                             #handle case where process spun up in the time between running get-process and running netstat
                             if($procName = $processes | Where {$_.id -eq $procId} | select -ExpandProperty name ){ }
                                else {$procName = "Unknown"}    						

                $netstatItem = New-Object psobject
		        Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "Protocol" -value $proto
		        Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "State" -value $status
		        Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "LocalAddress" -value $localAddress
		        Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "LocalPort" -value $localPort
                Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "RemoteAddress" -value $remoteAddress
                Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "RemotePort" -value $remotePort
                Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "ProcessName" -value $procName
                Add-Member -InputObject $netstatItem -MemberType NoteProperty -Name "PID" -value $procId
		
		        $script:NetstatObj += $netstatItem
							
             }
      }

	#saving plain file with current timestamp as header
	$datetimenow = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
	"[$datetimenow]" | Out-File $Script:NetstatLog
	$results | Out-File $Script:NetstatLog -Append

	logmsg "[INFO] Netstat collected."
}

function Get-NetworkInfo()
{
			
			#TCP IP Parameters from Registry
			$script:tcpipregObj = @()
			$tcpipreg = Get-ItemProperty -Path Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters
			$networkItemtcpreg = New-Object psobject
		    Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "DataBasePath" -value $tcpipreg.DataBasePath
			Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "DhcpDomain" -value $tcpipreg.DhcpDomain
		    Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "DhcpNameServer" -value $tcpipreg.DhcpNameServer
            Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "Domain" -value $tcpipreg.Domain
            Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "ForwardBroadcasts" -value $tcpipreg.ForwardBroadcasts
            Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "Hostname" -value $tcpipreg.Hostname
            Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "ICSDomain" -value $tcpipreg.ICSDomain
			Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "IPEnableRouter" -value $tcpipreg.IPEnableRouter
			Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "NameServer" -value $tcpipreg.NameServer
			Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "PSChildName" -value $tcpipreg.PSChildName
			Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "PSPath" -value $tcpipreg.PSPath
			Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "MaxUserPort" -value $tcpipreg.MaxUserPort
			Add-Member -InputObject $networkItemtcpreg -MemberType NoteProperty -Name "TcpTimedWaitDelay" -value $tcpipreg.TcpTimedWaitDelay
		    $script:tcpipregObj += $networkItemtcpreg


			#Netsh TCP global values
			$script:tcpglobalObj = @()
			$tcpglobal = netsh int tcp show global
			$networkItemtcpgb = New-Object psobject

			# Initialize the properties
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal4"  -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal5"  -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal6"  -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal7"  -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal8"  -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal9"  -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal10" -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal11" -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal12" -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal13" -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal14" -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal15" -value ''
			Add-Member -InputObject $networkItemtcpgb -MemberType NoteProperty -Name "tcpglobal16" -value ''

            #parse through output and extract and assign values
            foreach ($outputLine in $tcpglobal)
            {
                $parts = $outputLine.Split(":")
                if ($parts.Length -eq 2) {
                    if ($parts[0] -match 'Receive-Side Scaling State')
                    {
						$networkItemtcpgb.tcpglobal4 = $tcpglobal[4].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'Chimney Offload State')
                    {
						$networkItemtcpgb.tcpglobal5 = $tcpglobal[5].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'NetDMA State')
                    {
						$networkItemtcpgb.tcpglobal6 = $tcpglobal[6].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'Direct Cache Access (DCA)')
                    {
						$networkItemtcpgb.tcpglobal7 = $tcpglobal[7].Split(":")[7].Trim()
                    }

                    if ($parts[0] -match 'Receive Window Auto-Tuning Level')
                    {
						$networkItemtcpgb.tcpglobal8 = $tcpglobal[8].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'Add-On Congestion Control Provider')
                    {
						$networkItemtcpgb.tcpglobal9 = $tcpglobal[9].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'ECN Capability')
                    {
						$networkItemtcpgb.tcpglobal10 = $tcpglobal[10].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'RFC 1323 Timestamps')
                    {
						$networkItemtcpgb.tcpglobal11 = $tcpglobal[11].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'Initial RTO')
                    {
						$networkItemtcpgb.tcpglobal12 = $tcpglobal[12].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'Receive Segment Coalescing State')
                    {
						$networkItemtcpgb.tcpglobal13 = $tcpglobal[13].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'Non Sack Rtt Resiliency')
                    {
						$networkItemtcpgb.tcpglobal14 = $tcpglobal[14].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'Max SYN Retransmissions')
                    {
						$networkItemtcpgb.tcpglobal15 = $tcpglobal[15].Split(":")[1].Trim()
                    }

                    if ($parts[0] -match 'TCP Fast Open')
                    {
						$networkItemtcpgb.tcpglobal16 = $tcpglobal[16].Split(":")[1].Trim()
                    }
                }
            } 

			$script:tcpglobalObj += $networkItemtcpgb


			#Fileversion of tcpip.sys
			$script:tcpipverslObj = @()
			#tcpip.sys
			$tcpipvers = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$env:windir\System32\drivers\tcpip.sys").FileVersion
			#dfsc.sys 
			$dfscvers = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$env:windir\System32\drivers\dfsc.sys").FileVersion
			#mup.sys 
			$mupvers = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$env:windir\System32\drivers\mup.sys").FileVersion
			#rdbss.sys
			$rdbssvers = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$env:windir\System32\drivers\rdbss.sys").FileVersion
			#mrxsmb.sys 
			$mrxsmbvers = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$env:windir\System32\drivers\mrxsmb.sys").FileVersion
			#mrxsmb10.sys 
			$mrxsmb10vers = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$env:windir\System32\drivers\mrxsmb10.sys").FileVersion
			#mrxsmb20.sys
			$mrxsmb20vers = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("$env:windir\System32\drivers\mrxsmb20.sys").FileVersion

			$networkItemtcpvers = New-Object psobject
		    Add-Member -InputObject $networkItemtcpvers -MemberType NoteProperty -Name "tcpipvers" -value $tcpipvers
			Add-Member -InputObject $networkItemtcpvers -MemberType NoteProperty -Name "dfscvers" -value $dfscvers
			Add-Member -InputObject $networkItemtcpvers -MemberType NoteProperty -Name "mupvers" -value $mupvers
			Add-Member -InputObject $networkItemtcpvers -MemberType NoteProperty -Name "rdbssvers" -value $rdbssvers
			Add-Member -InputObject $networkItemtcpvers -MemberType NoteProperty -Name "mrxsmbvers" -value $mrxsmbvers
			Add-Member -InputObject $networkItemtcpvers -MemberType NoteProperty -Name "mrxsmb10vers" -value $mrxsmb10vers
			Add-Member -InputObject $networkItemtcpvers -MemberType NoteProperty -Name "mrxsmb20vers" -value $mrxsmb20vers
			$script:tcpipverslObj += $networkItemtcpvers

			#if OS is on 2012 or higher
			If ($Script:OSVer -like "6.4.*" -or $Script:OSVer -like "6.3.*" -or $Script:OSVer -like "6.2.*" -or $Script:OSVer -like "10.0.*")
			{
			$script:smbconfigObj = @()
			$smb = Get-SmbClientConfiguration 
			$smbconfig = New-Object psobject
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "ConnectionCountPerRssNetworkInterface" -value $smb.ConnectionCountPerRssNetworkInterface
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "DirectoryCacheEntriesMax" -value $smb.DirectoryCacheEntriesMax              
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "DirectoryCacheEntrySizeMax" -value $smb.DirectoryCacheEntrySizeMax            
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "DirectoryCacheLifetime" -value $smb.DirectoryCacheLifetime                
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "EnableBandwidthThrottling" -value $smb.EnableBandwidthThrottling             
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "EnableByteRangeLockingOnReadOnlyFiles" -value $smb.EnableByteRangeLockingOnReadOnlyFiles 
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "EnableLargeMtu" -value $smb.EnableLargeMtu                       
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "EnableMultiChannel" -value $smb.EnableMultiChannel                    
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "DormantFileLimit" -value $smb.DormantFileLimit                      
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "EnableSecuritySignature" -value $smb.EnableSecuritySignature               
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "ExtendedSessionTimeout" -value $smb.ExtendedSessionTimeout                
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "FileInfoCacheEntriesMax" -value $smb.FileInfoCacheEntriesMax               
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "FileInfoCacheLifetime" -value $smb.FileInfoCacheLifetime                 
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "FileNotFoundCacheEntriesMax" -value $smb.FileNotFoundCacheEntriesMax           
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "FileNotFoundCacheLifetime" -value $smb.FileNotFoundCacheLifetime             
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "KeepConn" -value $smb.KeepConn                              
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "MaxCmds" -value $smb.MaxCmds                              
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "MaximumConnectionCountPerServer" -value $smb.MaximumConnectionCountPerServer       
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "OplocksDisabled" -value $smb.OplocksDisabled                      
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "RequireSecuritySignature" -value $smb.RequireSecuritySignature              
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "SessionTimeout" -value $smb.SessionTimeout                       
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "UseOpportunisticLocking" -value $smb.UseOpportunisticLocking               
			Add-Member -InputObject $smbconfig -MemberType NoteProperty -Name "WindowSizeThreshold" -value $smb.WindowSizeThreshold
			$script:smbconfigObj += $smbconfig
			}

			#Firewall settings
			$script:FirewallObj = @()
			$RegistryKeys= @()
			#Local
			$RegistryKeys += 'Registry::HKLM\System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'
			#GPO
			$GpoRegistryKeys += 'Registry::HKLM\Software\Policies\Microsoft\WindowsFirewall\FirewallRules'
			
			Foreach ($Key in $RegistryKeys) {
				if (Test-Path -Path $Key) {
					(Get-ItemProperty -Path $Key).PSObject.Members |
					Where-Object {(@('PSPath','PSParentPath','PSChildName') -notcontains $_.Name) -and ($_.MemberType -eq 'NoteProperty') -and ($_.TypeNameOfValue -eq 'System.String')} |
					 ForEach-Object {
        
						# Prepare hashtable
						$HashProps = @{
							NameOfRule = $_.Name
							RuleVersion = ($_.Value -split '\|')[0]
							Action = $null
							Active = $null
							Dir = $null
							Protocol = $null
							LPort = $null
							RPort = $null
							Name = $null
							Profile = $null
							#App = $null
							#Desc = $null
							#EmbedCtxt = $null
							#RA4 = $null
							#RA6 = $null
							#Svc = $null
							#ICMP6 = $null
							#Edge = $null
							#LA4 = $null
							#LA6 = $null
							#ICMP4 = $null
							#LPort2_10 = $null
							#RPort2_10 = $null
						}

						# Determine if this is a local or a group policy rule and display this in the hashtable
						if ($Key -match 'HKLM\\System\\CurrentControlSet') {
							$HashProps.RuleType = 'Local'
						} else {
							$HashProps.RuleType = 'GPO'
						}

						# Iterate through the value of the registry key and fill PSObject with the relevant data
						ForEach ($FireWallRule in ($_.Value -split '\|')) {
							switch (($FireWallRule -split '=')[0]) {
								'Action' {$HashProps.Action = ($FireWallRule -split '=')[1]}
								'Active' {$HashProps.Active = ($FireWallRule -split '=')[1]}
								'Dir' {$HashProps.Dir = ($FireWallRule -split '=')[1]}
								'Protocol' {$HashProps.Protocol = ($FireWallRule -split '=')[1]}
								'LPort' {$HashProps.LPort = ($FireWallRule -split '=')[1]}
								'RPort' {$HashProps.RPort = ($FireWallRule -split '=')[1]}
								'Name' {$HashProps.Name = ($FireWallRule -split '=')[1]}
								'Profile' {$HashProps.Profile = ($FireWallRule -split '=')[1]}
								#'App' {$HashProps.App = ($FireWallRule -split '=')[1]}
								#'Desc' {$HashProps.Desc = ($FireWallRule -split '=')[1]}
								#'EmbedCtxt' {$HashProps.EmbedCtxt = ($FireWallRule -split '=')[1]}
								#'RA4' {[array]$HashProps.RA4 += ($FireWallRule -split '=')[1]}
								#'RA6' {[array]$HashProps.RA6 += ($FireWallRule -split '=')[1]}
								#'Svc' {$HashProps.Svc = ($FireWallRule -split '=')[1]}
								#'ICMP6' {$HashProps.ICMP6 = ($FireWallRule -split '=')[1]}
								#'Edge' {$HashProps.Edge = ($FireWallRule -split '=')[1]}
								#'LA4' {[array]$HashProps.LA4 += ($FireWallRule -split '=')[1]}
								#'LA6' {[array]$HashProps.LA6 += ($FireWallRule -split '=')[1]}
								#'ICMP4' {$HashProps.ICMP4 = ($FireWallRule -split '=')[1]}
								#'LPort2_10' {$HashProps.LPort2_10 = ($FireWallRule -split '=')[1]}
								#'RPort2_10' {$HashProps.RPort2_10 = ($FireWallRule -split '=')[1]}
								Default {}
							}

						}
						
						#protocol lookup
						switch($HashProps.Protocol)
						{
						0 {$protocol = "HOPOPT"} 
						1 {$protocol = "ICMPv4"} 
						2 {$protocol = "IGMP"}
						6 {$protocol = "TCP"}
						17 {$protocol = "UDP"}
						41 {$protocol = "IPv6"}
						43 {$protocol = "IPv6-Route"}
						44 {$protocol = "IPv6-Frag"}
						47 {$protocol = "GRE"}
						58 {$protocol = "ICMPv6"}
						59 {$protocol = "IPv6NoNxt"}
						60 {$protocol = "IPv6Opts"}
						112 {$protocol = "VRRP"}
						113 {$protocol = "PGM"}
						115 {$protocol = "L2TP"}
						default {$protocol = "Unknown"}
						}

						$firewallrule = New-Object psobject
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "NameOfRule" -value $HashProps.NameOfRule
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Name" -value $HashProps.Name
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Active" -value $HashProps.Active
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Protocol" -value $protocol
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Profile" -value $HashProps.Profile
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Action" -value $HashProps.Action
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "RuleType" -value $HashProps.RuleType
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "RPort" -value $HashProps.RPort
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "LPort" -value $HashProps.LPort
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Dir" -value $HashProps.Dir
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "RuleVersion" -value $HashProps.RuleVersion
						$script:FirewallObj += $firewallrule

					}
				}
			}

			Foreach ($Key in $GpoRegistryKeys) {
				if (Test-Path -Path $Key) {
					(Get-ItemProperty -Path $Key).PSObject.Members |
					Where-Object {(@('PSPath','PSParentPath','PSChildName') -notcontains $_.Name) -and ($_.MemberType -eq 'NoteProperty') -and ($_.TypeNameOfValue -eq 'System.String')} |
					 ForEach-Object {
        
						# Prepare hashtable
						$HashProps = @{
							NameOfRule = $_.Name
							RuleVersion = ($_.Value -split '\|')[0]
							Action = $null
							Active = $null
							Dir = $null
							Protocol = $null
							LPort = $null
							RPort = $null
							Name = $null
							Profile = $null
							#App = $null
							#Desc = $null
							#EmbedCtxt = $null
							#RA4 = $null
							#RA6 = $null
							#Svc = $null
							#ICMP6 = $null
							#Edge = $null
							#LA4 = $null
							#LA6 = $null
							#ICMP4 = $null
							#LPort2_10 = $null
							#RPort2_10 = $null
						}

						# Determine if this is a local or a group policy rule and display this in the hashtable
						if ($Key -match 'HKLM\\System\\CurrentControlSet') {
							$HashProps.RuleType = 'Local'
						} else {
							$HashProps.RuleType = 'GPO'
						}

						# Iterate through the value of the registry key and fill PSObject with the relevant data
						ForEach ($FireWallRule in ($_.Value -split '\|')) {
							switch (($FireWallRule -split '=')[0]) {
								'Action' {$HashProps.Action = ($FireWallRule -split '=')[1]}
								'Active' {$HashProps.Active = ($FireWallRule -split '=')[1]}
								'Dir' {$HashProps.Dir = ($FireWallRule -split '=')[1]}
								'Protocol' {$HashProps.Protocol = ($FireWallRule -split '=')[1]}
								'LPort' {$HashProps.LPort = ($FireWallRule -split '=')[1]}
								'RPort' {$HashProps.RPort = ($FireWallRule -split '=')[1]}
								'Name' {$HashProps.Name = ($FireWallRule -split '=')[1]}
								'Profile' {$HashProps.Profile = ($FireWallRule -split '=')[1]}
								#'App' {$HashProps.App = ($FireWallRule -split '=')[1]}
								#'Desc' {$HashProps.Desc = ($FireWallRule -split '=')[1]}
								#'EmbedCtxt' {$HashProps.EmbedCtxt = ($FireWallRule -split '=')[1]}
								#'RA4' {[array]$HashProps.RA4 += ($FireWallRule -split '=')[1]}
								#'RA6' {[array]$HashProps.RA6 += ($FireWallRule -split '=')[1]}
								#'Svc' {$HashProps.Svc = ($FireWallRule -split '=')[1]}
								#'ICMP6' {$HashProps.ICMP6 = ($FireWallRule -split '=')[1]}
								#'Edge' {$HashProps.Edge = ($FireWallRule -split '=')[1]}
								#'LA4' {[array]$HashProps.LA4 += ($FireWallRule -split '=')[1]}
								#'LA6' {[array]$HashProps.LA6 += ($FireWallRule -split '=')[1]}
								#'ICMP4' {$HashProps.ICMP4 = ($FireWallRule -split '=')[1]}
								#'LPort2_10' {$HashProps.LPort2_10 = ($FireWallRule -split '=')[1]}
								#'RPort2_10' {$HashProps.RPort2_10 = ($FireWallRule -split '=')[1]}
								Default {}
							}

						}
						
						#protocol lookup
						switch($HashProps.Protocol)
						{
						0 {$protocol = "HOPOPT"} 
						1 {$protocol = "ICMPv4"} 
						2 {$protocol = "IGMP"}
						6 {$protocol = "TCP"}
						17 {$protocol = "UDP"}
						41 {$protocol = "IPv6"}
						43 {$protocol = "IPv6-Route"}
						44 {$protocol = "IPv6-Frag"}
						47 {$protocol = "GRE"}
						58 {$protocol = "ICMPv6"}
						59 {$protocol = "IPv6NoNxt"}
						60 {$protocol = "IPv6Opts"}
						112 {$protocol = "VRRP"}
						113 {$protocol = "PGM"}
						115 {$protocol = "L2TP"}
						default {$protocol = "Unknown"}
						}

						$firewallrule = New-Object psobject
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "NameOfRule" -value $HashProps.NameOfRule
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Name" -value $HashProps.Name
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Active" -value $HashProps.Active
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Protocol" -value $protocol
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Profile" -value $HashProps.Profile
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Action" -value $HashProps.Action
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "RuleType" -value $HashProps.RuleType
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "RPort" -value $HashProps.RPort
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "LPort" -value $HashProps.LPort
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "Dir" -value $HashProps.Dir
						Add-Member -InputObject $firewallrule -MemberType NoteProperty -Name "RuleVersion" -value $HashProps.RuleVersion
						$script:FirewallObj += $firewallrule

					}
				}
			}

			#interfaces
			try {
				$script:interfaceObj = @()
				$interfaces = get-netipinterface
				foreach ($int in $interfaces) {
				$interface = New-Object psobject
				Add-Member -InputObject $interface -MemberType NoteProperty -Name "InterfaceAlias" -value $int.InterfaceAlias
				Add-Member -InputObject $interface -MemberType NoteProperty -Name "AddressFamily" -value $int.AddressFamily
				Add-Member -InputObject $interface -MemberType NoteProperty -Name "NlMtu" -value $int.NlMtu
				Add-Member -InputObject $interface -MemberType NoteProperty -Name "InterfaceMetric" -value $int.InterfaceMetric
				Add-Member -InputObject $interface -MemberType NoteProperty -Name "Dhcp" -value $int.Dhcp
				Add-Member -InputObject $interface -MemberType NoteProperty -Name "ConnectionState" -value $int.ConnectionState
				$script:interfaceObj += $interface
				}
			}
			catch [Exception] 
			{
				$script:interfaceObj = $null
				Write-Host "Error while collecting Network Interface info: $_.Exception.Message"
			}

			#MTU-Size test
			try {
				$script:mtuObj = @()
				$Ping = New-Object System.Net.NetworkInformation.Ping 
				$PingOptions = New-Object System.Net.NetworkInformation.PingOptions 
				$PingOptions.DontFragment = $true 
		
				[int]$Timeout = 1000 
				[int]$SmallMTU=1 
				[int]$LargeMTU=35840 
				$IPaddress = "204.79.197.200" #IP Address of bing.com
 
				[byte[]]$databuffer = ,0xAC * $LargeMTU 
 
				While (-not ($SmallMTU -eq ($LargeMTU - 1))) { 
					[int]$xTest= ($LargeMTU - $SmallMTU) / 2 + $SmallMTU 
         
					$PingReply = $Ping.Send($IPaddress, $Timeout, $($DataBuffer[1..$xTest]), $PingOptions) 
					#Write-Verbose "testing $($xTest + 28) byte transmission unit size"  
					if ($PingReply.Status -match "Success"){     
						$SmallMTU = $xTest 
					} 
					else{ 
						$LargeMTU = $xTest 
					} 
					Start-Sleep -Milliseconds 50 
				} 
     
				If($SmallMTU -eq 1){ 
					$script:mtuObj = $null
					Write-Error "The IP address $IPaddress does not respond."  
				}else{
					#show in report 
					$MTU = $SmallMTU + 28 # add 28 bytes because 20 bytes are reserved for the IP header and 8 bytes must be allocated for the ICMP Echo Request header. 
					$mtusize = New-Object psobject
					Add-Member -InputObject $mtusize -MemberType NoteProperty -Name "mtusize" -value $MTU
					$script:mtuObj += $mtusize
					return 
				} 
			}
			catch [Exception] 
			{
				$script:mtuObj = $null
				Write-Host "Error while collecting MTU info: $_.Exception.Message"
			}
}

function CollectPageFileInfo()
{
	header "PageFile Usage"
	$CurrentPageFile = Get-WmiObject -Class Win32_PageFileUsage
	$name = $CurrentPageFile.Name
	$base = $CurrentPageFile.AllocatedBaseSize
	$current = $CurrentPageFile.CurrentUsage
	$peak = $CurrentPageFile.PeakUsage
	$percent = $current/($base/100)  
	loginfo "PageFile location: $name" 
	loginfo "PageFile AllocatedBaseSize:  $base"
	loginfo "PageFile CurrentUsage:  $current"
	loginfo "PageFile PeakUsage:  $peak"
	loginfo "PageFile utilization: currently $percent % of PageFile in use."
	loginfo "PageFile utilization: currently $percent % of PageFile in use."
}

function CollectVMUtil()
{
	$Computer = Get-WmiObject -Class Win32_ComputerSystem  
	$OS = gwmi -Class win32_operatingsystem -computername $Computer.Name | 
	Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }} 
	$osdiskLetter = (get-volumemap | Where-Object {$_.isOsDisk}).VolumeID
	Write-Debug "CollectVMUtil: OsDiskLetter autodetected is $osdiskLetter"
	$vol = Get-WmiObject -Class win32_Volume -ComputerName $Computer.Name -Filter "DriveLetter = '$osdiskLetter'" | 
	Select-object @{Name = "C PercentFree"; Expression = {“{0:N2}” -f  (($_.FreeSpace / $_.Capacity)*100) } } 
	   
	$MemLoad = "Current average Memory Usage: "+$OS.MemoryUsage+"%" 
	$CDrive = "PercentFree on OS Disk: "+$vol.'C PercentFree'+"%"
	#logmsg $CPULoad
	loginfo $MemLoad
	if([math]::Round($vol.'C PercentFree') -gt 5){loginfo $CDrive}else{logerr "$CDrive. Should be greater than 5%. Please move files to data disks, free up disk space or <a target='_blank' href='https://blogs.msdn.microsoft.com/madan/2015/11/02/resizing-azure-vm-os-or-data-disk/'>extend disk size</a>."}

}

function CheckOSVersion()
{
    #Get OS version
	$Script:OSVer = (Get-WmiObject -Class Win32_OperatingSystem).Version

	#Check OS version. Only Win7, Win8 and Win10 supported
	If ($Script:OSVer -like "6.4.*" -or $Script:OSVer -like "6.3.*" -or $Script:OSVer -like "6.2.*" -or $Script:OSVer -like "10.0.*")
	{
		loginfo "Operating System: $Script:OSVer, Win8orWin10"
		$Script:OS = "Win8orWin10"
	}
	ElseIf ($Script:OSVer -like "6.1.*")
	{
		logwarn "Operating System: $Script:OSVer, Win7or2008R2 - Not capable of Storage Spaces"
		$Script:OS = "Win7"
	}
	Else
	{
		logerr "Operating System: $Script:OSVer, OlderThanWin7 - NOT SUPPORTED!"
		$Script:OS = "OlderThanWin7"
	}

}


function Disclaimer()
{
	if($Cleanup){
		Write-Debug "skip disclaimer : cleanup mode"
		return
	}
	if($NoGUI) {
		Write-Host "$Script:DisclaimerText $Script:TrustCenterText ($Script:TrustCenterLink)`n" -ForegroundColor Yellow
		if(-not $AcceptDisclaimerAndShareDiagnostics) {
			$response = Read-Host "Agree to share diagnostic information? (Y/N) [$Script:ShareDiagInfoLink]"
			if ($response -ne 'Y' -and $response -ne 'y') {
				Write-Host "User Abort"
				Exit
			}
			Write-Host "User agrees to share diagnostic information.`n"

			$response = Read-Host "Agree with PerfInsights EULA? (Y/N) [$Script:EULAFilePath]"
			if ($response -ne 'Y' -and $response -ne 'y') {
				Write-Host "User Abort"
				Exit
			}
			Write-Host "User agrees with PerfInsights EULA.`n"
		} else {
			Write-Host "User agrees to share diagnostic information. [$Script:ShareDiagInfoLink]" -ForegroundColor Green
			Write-Host "User agrees with PerfInsights EULA. [$Script:EULAFilePath]" -ForegroundColor Green
		}
		return
	}


[reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
[reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null

$form1 = New-Object System.Windows.Forms.Form
$label1 = New-Object System.Windows.Forms.Label
$button1 = New-Object System.Windows.Forms.Button
$button2 = New-Object System.Windows.Forms.Button
$checkBox1 = New-Object System.Windows.Forms.CheckBox
$EulaCheckbox = New-Object System.Windows.Forms.CheckBox
$InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState
$LinkLabel = New-Object System.Windows.Forms.LinkLabel 
$EulaLinkLabel = New-Object System.Windows.Forms.LinkLabel 
$TrustCenterLabel = New-Object System.Windows.Forms.LinkLabel 

$handler_checkbox_selected=
{
    if ($checkBox1.Checked -and $EulaCheckbox.Checked)     {  
    #enable button
    $button1.Enabled = $True
    }

    if ( !$checkBox1.Checked ) {   
    #disable button
    $button1.Enabled = $False
    } 
}

$handler_EulaCheckbox_selected=
{
    if ($checkBox1.Checked -and $EulaCheckbox.Checked)     {  
    #enable button
    $button1.Enabled = $True
    }

    if ( !$EulaCheckbox.Checked ) {   
    #disable button
    $button1.Enabled = $False
    } 
}

$handler_button1_Click= 
{
#go
    Write-Debug "Consensus accepted!"
	$form1.Close()
	$Script:CancelExecution = $False
	return
}

$handler_button2_Click= 
{
# exit
	Write-Debug "User did not accept disclaimer. Exiting."
	$form1.Close()
}

#----------------------------------------------
#region Generated Form Code
$form1.Text = "Notice and Consent"
$form1.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($Script:IconFilePath)
$form1.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 450
$System_Drawing_Size.Height = 400
$form1.ClientSize = $System_Drawing_Size
$form1.StartPosition = "CenterScreen"
$form1.AutoScroll = $True
$form1.AutoSize = $True
$form1.AutoSizeMode = "GrowAndShrink"
$form1.MinimizeBox = $False
$form1.MaximizeBox = $False
$form1.WindowState = "Normal"
#$form1.SizeGripStyle = "Auto"
$form1.ShowInTaskbar = $False
$form1.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Fixed3D

$button1.TabIndex = 4
$button1.Name = "button1"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 80
$System_Drawing_Size.Height = 30
$button1.Size = $System_Drawing_Size
$button1.UseVisualStyleBackColor = $True
$button1.Enabled = $False
$button1.Text = "Run Script"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 242
$System_Drawing_Point.Y = 356
$button1.Location = $System_Drawing_Point
$button1.DataBindings.DefaultDataSourceUpdateMode = 0
$button1.add_Click($handler_button1_Click)

$form1.Controls.Add($button1)


$button2.TabIndex = 3
$button2.Name = "button2"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 80
$System_Drawing_Size.Height = 30
$button2.Size = $System_Drawing_Size
$button2.UseVisualStyleBackColor = $True

$button2.Text = "Exit"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 327
$System_Drawing_Point.Y = 356
$button2.Location = $System_Drawing_Point
$button2.DataBindings.DefaultDataSourceUpdateMode = 0
$button2.add_Click($handler_button2_Click)

$form1.Controls.Add($button2)

$checkBox1.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 20
$System_Drawing_Size.Height = 24
$checkBox1.Size = $System_Drawing_Size
$checkBox1.TabIndex = 0
$checkBox1.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
$checkBox1.Text = ""
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 12
$System_Drawing_Point.Y = 300
$checkBox1.Location = $System_Drawing_Point
$checkBox1.DataBindings.DefaultDataSourceUpdateMode = 0
$checkBox1.Add_CheckStateChanged($handler_checkbox_selected)

$form1.Controls.Add($checkBox1)

$EulaCheckbox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 160
$System_Drawing_Size.Height = 24
$EulaCheckbox.Size = $System_Drawing_Size
$EulaCheckbox.TabIndex = 0
$EulaCheckbox.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
$EulaCheckbox.Text = "I have read and agree to the "
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 12
$System_Drawing_Point.Y = 325
$EulaCheckbox.Location = $System_Drawing_Point
$EulaCheckbox.DataBindings.DefaultDataSourceUpdateMode = 0
$EulaCheckbox.Add_CheckStateChanged($handler_EulaCheckbox_selected)

$form1.Controls.Add($EulaCheckbox)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 380
$System_Drawing_Size.Height = 300
$label1.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 12
$System_Drawing_Point.Y = 3
$label1.Location = $System_Drawing_Point
$label1.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
$label1.Text = $Script:DisclaimerText

$form1.Controls.Add($label1)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 150
$System_Drawing_Size.Height = 24
$TrustCenterLabel.Size = $System_Drawing_Size
$TrustCenterLabel.TabIndex = 1
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 138
$System_Drawing_Point.Y = 267
$TrustCenterLabel.Location = $System_Drawing_Point
$TrustCenterLabel.LinkColor = "BLUE" 
$TrustCenterLabel.ActiveLinkColor = "RED" 
$TrustCenterLabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
$TrustCenterLabel.Text = $Script:TrustCenterText
$TrustCenterLabel.add_Click({[system.Diagnostics.Process]::start($Script:TrustCenterLink)}) 
$form1.Controls.Add($TrustCenterLabel)

[void]$TrustCenterLabel.BringToFront()

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 220
$System_Drawing_Size.Height = 24
$LinkLabel.Size = $System_Drawing_Size
$LinkLabel.TabIndex = 1
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 30
$System_Drawing_Point.Y = 305
$LinkLabel.Location = $System_Drawing_Point
$LinkLabel.LinkColor = "BLUE" 
$LinkLabel.ActiveLinkColor = "RED" 
$LinkLabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
$LinkLabel.Text = "Share diagnostic Information" 
$LinkLabel.add_Click({[system.Diagnostics.Process]::start($Script:ShareDiagInfoLink)}) 
$form1.Controls.Add($LinkLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 175
$System_Drawing_Size.Height = 24
$EulaLinkLabel.Size = $System_Drawing_Size
$EulaLinkLabel.TabIndex = 1
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 170
$System_Drawing_Point.Y = 329
$EulaLinkLabel.Location = $System_Drawing_Point
$EulaLinkLabel.LinkColor = "BLUE" 
$EulaLinkLabel.ActiveLinkColor = "RED" 
$EulaLinkLabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8,0,3,1)
$EulaLinkLabel.Text = "PerfInsights EULA" 
$EulaLinkLabel.add_Click({[system.Diagnostics.Process]::start($Script:EULAFilePath)}) 
$form1.Controls.Add($EulaLinkLabel)

$form1.Topmost = $True
	
$form1.Add_Shown({$form1.Activate()})
#Show the Form
[void]$form1.ShowDialog()
}


function ReadConfig()
{
		# get list of running processes
		Get-TaskListInfo

		CollectStartupSRC

		Get-FilterDriver
		Get-Fsutil

		# get MsInfo32
		msinfo
		parseEventlogs
		CheckForKBs
		checkClusterConfig
		Get-NetstatInfo
		Get-NetworkInfo
		CollectPageFileInfo
		CollectVMUtil
		checkDiskConfig
		checkVMsize
		Check-ThroughputOptimized
		Get-SQLSettings
		checkPowerPlan
}

function startTests()
{
	Write-Debug "start tests"
	if ($Script:runselection -ne $null)
	{
		Write-Debug "runselection is $Script:runselection"

		Log-ScriptRun -scenarioToRun $Script:runselection -customActionsTorun $Script:array

		switch($Script:runselection)
		{
			"Collect basic configuration" {
				$perfDiagRes = StartPerformanceDiagnostics -runBenchmark $false
				logmsg "[INFO] User selected: Collect basic configuration"
				Write-host "[INFO] User selected: Collect basic configuration" -ForegroundColor Green
				ReadConfig
			}

			"Benchmarking"{
				$perfDiagRes = StartPerformanceDiagnostics -runBenchmark $true
				logmsg "[INFO] User selected: Benchmarking"
				Write-host "[INFO] User selected: Benchmarking" -ForegroundColor Green
				ReadConfig
				RunDiskSpd
			}

			"Slow VM analysis"{
				$perfDiagRes = StartPerformanceDiagnostics -runBenchmark $false
				logmsg "[INFO] User selected: Slow VM analysis"
				Write-host "[INFO] User selected: Slow VM analysis" -ForegroundColor Green
				ReadConfig

				if(!$NoGUI){
					#Dialog for Performance troubleshooting
					$buttons=[system.windows.forms.messageboxbuttons]::OK;
					$Script:param_sptrace =[system.windows.forms.messagebox]::Show("Please try to reproduce the slow performance issue and then stop the trace with the second dialog.", "Start Performance Counter Trace",$buttons,[System.Windows.Forms.MessageBoxIcon]::Information);
				}

				If($Script:param_sptrace -eq "OK" -or $NoGUI)
				{
					collectGenPerfCounter
				}
				StopPerfCounter
			}

			"Slow VM analysis and benchmarking"{
				$perfDiagRes = StartPerformanceDiagnostics -runBenchmark $true
				logmsg "[INFO] User selected: Slow VM analysis and benchmarking"
				Write-host "[INFO] User selected: Slow VM analysis and benchmarking" -ForegroundColor Green
				ReadConfig
				if(!$NoGUI){
					$buttons=[system.windows.forms.messageboxbuttons]::OK;
					$Script:param_sptrace =[system.windows.forms.messagebox]::Show("Please try to reproduce the slow performance issue and`n" +
						 "`nthen stop the trace with the second dialog.", "Start Performance Counter Trace",$buttons,[System.Windows.Forms.MessageBoxIcon]::Information);
				}
				If($Script:param_sptrace -eq "OK" -or $NoGUI)
				{
					collectGenPerfCounter
				}
				StopPerfCounter
				RunDiskSpd
			}

			"Azure Files analysis"{
				$perfDiagRes = StartPerformanceDiagnostics -runBenchmark $false
				logmsg "[INFO] User selected: Azure Files analysis"
				Write-host "[INFO] User selected: Azure Files analysis" -ForegroundColor Green
				ReadConfig

				if(!$nogui) {
					$buttons=[system.windows.forms.messageboxbuttons]::OK;
					$Script:param_sptrace =[system.windows.forms.messagebox]::Show("Please try to reproduce the slow performance issue and`n" +
					 "`nthen stop the trace with the second dialog.", "Start Trace",$buttons,[System.Windows.Forms.MessageBoxIcon]::Information);
				}

				If($Script:param_sptrace -eq "OK" -or $NoGUI)
				{
					logmsg "[INFO] Starting Azure Files trace..."
					collectSMBCounter
					netsh TRACE START CAPTURE=yes TRACEFILE="$script:logpath_Logs\networktrace.etl" 
				}

				try{
				
					# Sleep for tracingDuration or ask user interaction
					if($NoGUI){
						Write-Debug "starting to sleep for $script:TracingDuration seconds."
						start-sleep -Seconds $script:TracingDuration
					}else{

						$buttons=[system.windows.forms.messageboxbuttons]::OK;
					    $result =[system.windows.forms.messagebox]::Show("Please, click OK to stop the trace", "Stopping Trace",$buttons,[System.Windows.Forms.MessageBoxIcon]::Information);
					}

					if($result -eq "OK" -or $nogui){
						header "Stopping Azure Files trace"
						logmsg "[INFO] Stopping Azure Files trace."
						$result = &	"logman" "stop" "GuestVMPerf"
						#collect time of stop
						$script:tracestop = Get-Date -Format "MM/dd/yyyy HH:mm:ss.sss"	
						#collect information about configured time zone
						$script:timezone = [TimeZoneInfo]::Local.DisplayName
						netsh trace stop
						#Create CSV output files for performance counter traces: IOPS, MBPS, IO size, Latency, QD
						$SMBc = "$script:logpath_Logs\$env:computername`_SMBCounters*.blg"
						If (Test-Path $SMBc){
							relog -f CSV $SMBc -c "\SMB Client Shares(*)\Data Requests/sec" -o "$script:logpath_Logs\SMB_IOPS.csv"
							relog -f CSV $SMBc -c "\SMB Client Shares(*)\Data Bytes/sec" -o "$script:logpath_Logs\SMB_MBPS.csv"
							relog -f CSV $SMBc -c "\SMB Client Shares(*)\Avg. sec/Data Request" -o "$script:logpath_Logs\SMB_Latency.csv"
							relog -f CSV $SMBc -c "\SMB Client Shares(*)\Current Data Queue Length" -o "$script:logpath_Logs\SMB_QD.csv"

							$trace_obj = New-Object -TypeName psobject
							If (Test-Path "$script:logpath_Logs\SMB_IOPS.csv"){
							$temp = Get-Content "$script:logpath_Logs\SMB_IOPS.csv"
							$temp[0] = $temp[0].replace($temp[0], '"time","totaliops","iops"')
							#collect time of start
							$script:tracestart = $temp[1].substring(1,23)
							Set-Content -Path "$script:logpath_Logs\SMB_IOPS.csv" -Value $temp;
							$smbiopsobj = (Get-Content "$script:logpath_Logs\SMB_IOPS.csv" -Raw | ConvertFrom-CSV)| ConvertTo-Json
							Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "smbiopsObj" -Value $smbiopsobj
							Remove-Item "$script:logpath_Logs\SMB_IOPS.csv" -Force
							}
							If (Test-Path "$script:logpath_Logs\SMB_MBPS.csv"){
							$temp = Get-Content "$script:logpath_Logs\SMB_MBPS.csv"
							$temp[0] = $temp[0].replace($temp[0], '"time", "totalmbps", "mbps"')
							Set-Content -Path "$script:logpath_Logs\SMB_MBPS.csv" -Value $temp;
							$smbmbpsobj = (Get-Content "$script:logpath_Logs\SMB_MBPS.csv" -Raw | ConvertFrom-CSV)| ConvertTo-Json
							Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "smbmbpsobj" -Value $smbmbpsobj
							Remove-Item "$script:logpath_Logs\SMB_MBPS.csv" -Force
							}
							If (Test-Path "$script:logpath_Logs\SMB_Latency.csv"){
							$temp = Get-Content "$script:logpath_Logs\SMB_Latency.csv"
							$temp[0] = $temp[0].replace($temp[0], '"time", "totalavgsec", "avgsec"')
							Set-Content -Path "$script:logpath_Logs\SMB_Latency.csv" -Value $temp;
							$smblatobj = (Get-Content "$script:logpath_Logs\SMB_Latency.csv" -Raw | ConvertFrom-CSV)| ConvertTo-Json
							Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "smblatobj" -Value $smblatobj
							Remove-Item "$script:logpath_Logs\SMB_Latency.csv" -Force
							}
							If (Test-Path "$script:logpath_Logs\SMB_QD.csv"){
							$temp = Get-Content "$script:logpath_Logs\SMB_QD.csv"
							$temp[0] = $temp[0].replace($temp[0], '"time", "totalqd", "qd"')
							Set-Content -Path "$script:logpath_Logs\SMB_QD.csv" -Value $temp;
							$smbqdobj = (Get-Content "$script:logpath_Logs\SMB_QD.csv" -Raw | ConvertFrom-CSV)| ConvertTo-Json
							Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "smbqdobj" -Value $smbqdobj
							Remove-Item "$script:logpath_Logs\SMB_QD.csv" -Force
							}

							$timeframe_obj = New-Object -TypeName psobject
							Add-Member -InputObject $timeframe_obj  -MemberType NoteProperty -Name "AnalysisStartTime" -Value $script:tracestart
							Add-Member -InputObject $timeframe_obj  -MemberType NoteProperty -Name "AnalysisEndTime" -Value $script:tracestop
							Add-Member -InputObject $timeframe_obj  -MemberType NoteProperty -Name "TimeZone" -Value $script:timezone
							
							Add-Member -InputObject $trace_obj  -MemberType NoteProperty -Name "Analysistimeframe" -Value $timeframe_obj

							$traceJS = ConvertTo-PS2JS -inputObject $trace_obj -variablename "traceObj"
							Out-File -FilePath $script:TraceJS -InputObject $traceJS -Encoding ASCII

							(Get-Content $script:TraceJS) -replace '\\' -replace '"\[', '[' -replace ']\"', ']' |   Out-File $script:TraceJS
						}
					}
				}catch{
					logmsg "[INFO] Performance Counter already stopped"
				}
			}

			"Custom slow VM analysis"{
				logmsg "[INFO] User selected: Custom slow VM analysis"
				Write-host "[INFO] User selected: Custom slow VM analysis" -ForegroundColor Green
				
				#collect config regardless of custom modules
				ReadConfig
				
				if ($Script:array.Count -gt 0){
					
					$rundiskspd = $false
					$stopperf = $false
					$stopxperf = $false
					$stopnwtrace = $false
					$stopsptrace = $false
					
					
					# start traces
					foreach ($config in $Script:array){

						logmsg "[INFO] Custom Functionality: $config"
						
						switch($config){
							"Performance Counter Trace"{
								StartPerfCounter
								$stopperf = $true
							}
								"Diskspd benchmark"{
								$rundiskspd = $true
							}
							"XPerf Trace"{
								$res = StartXPerf
								$stopxperf = $res
							}
							"Network Trace"{
								StartNWtrace
								$stopnwtrace = $true
							}
							"Storport Trace"{
								StartStorport
								$stopsptrace = $true
							}
						}
					}

					$perfDiagRes = StartPerformanceDiagnostics -runBenchmark $rundiskspd
					
					#stop traces
					if (($stopperf -eq $true) -or ($stopxperf -eq $true) -or ($stopnwtrace -eq $true) -or ($stopsptrace -eq $true)){
						
						#stop all traces
						StopTraceDialog ("All traces")

						if ($stopperf -eq $true)
						{
							header "Stopping Performance Counter trace"
							Write-Debug "Stopping Performance Counter trace."
			 				$result = &	"logman" "stop" "GuestVMPerf"	
						}
						if ($stopxperf -eq $true)
						{
			 				header "Stopping XPerf trace"
							Write-Debug "Stopping XPerf trace."
			 				.\XPERF -stop -d $script:logpath_Logs\xperftrace.etl
                            Remove-Item $script:logpath_Logs\xperftrace.kernel.etl -Force

						}
						if ($stopnwtrace -eq $true)
						{
							header "Stopping Network trace"
							write-debug "Stopping Network trace."
				 			netsh trace stop
						}
						if ($stopsptrace -eq $true)
						{
							header "Stopping Storport trace"
							write-debug "Stopping Storport trace."
			 				$result = &	"logman" "stop" "storport" "-ets"	
						}							
					}
					# run diskspd "after" all traces has been run
					if ($rundiskspd -eq $true)
					{
						#DownLoadDiskSpd
						RunDiskSpd 
					}
				}
			}
		}
		if ($perfDiagRes -eq $true)
		{
			header "Stopping Performance Diagnostics"
			write-debug "Stopping Performance Diagnostics Engine."
			StopPerformanceDiagnostics
		}
	}
}

function parseEventlogs()
{
	#zero variables
	$appevt_err = @()
	$sysevt_info = @()
	$sysevt_warn = @()
	$sysevt_err = @()
	$evt_129 = @()
	$script:masterGuestEvents = @()
	$totaltime = 0
	$app_masterGuestEvents = @()
	$sys_masterGuestEvents = @()
	
	$EventParserWindowLen= $script:settings.EventParserWindowLen
	$EventParserMaxEvents = $script:settings.EventParserMaxEvents
	
	$sys_csv = "$script:logpath_Logs\System_Events.csv" 
	$app_csv = "$script:logpath_Logs\Application_ErrorEvents.csv" 

	header "Check Eventlog for Critical/Error" 
	
	# export Event Logs to file.
	logmsg "[INFO] Exporting event logs to file... "
	$time = (Measure-Command{
		collectEventlogs
	} | select totalseconds).totalseconds
	write-debug ("Exporting event logs completed in {0} seconds." -f $time)
	$totaltime += $time

	#critical events in last x days, where x := $EventParserWindowLen
	$StartTime = (Get-Date).AddDays(-$EventParserWindowLen)
	Write-Debug "eventParer start time : $StartTime"

	# define error event filter based on os version
	#if ($Script:OS -eq "Win8orWin10"){
	#	$EntryTypeFiler = @("Error","Critical")
	#}else{
	#	$EntryTypeFiler = @("Error")
	#}
	$EntryTypeFiler = @("Error")

	#=======================
	# Application Event Logs
	#=======================
	Write-Debug "start checking Application events..."
	try{
		Write-Debug "checking critical events"
		
		# get all applicaion/error logs in last x days
		logmsg "[INFO] Collecting Application Error logs. This operation can take some time..."
		$time = (Measure-Command{
			$appevt_err = get-eventlog -LogName Application -EntryType $EntryTypeFiler -after $starttime -ComputerName $env:computername -ea 0 `
			| select eventid, timegenerated, source, message, entrytype, properties `
			| Sort-Object -Property TimeGenerated -Descending `
			| Select-Object -First $EventParserMaxEvents 
		} | select totalseconds).totalseconds
		write-debug ("Collecting Application Error logs completed in {0} seconds." -f $time)
		$totaltime += $time


		# parsing errors
		logmsg "[INFO] Parsing Application Error logs..."
		$time = (Measure-Command{
			$app_masterGuestEvents += $appevt_err 
		} | select totalseconds).totalseconds
		write-debug ("Parsing Application Error logs completed in {0} seconds." -f $time)
		$totaltime += $time

	}catch{
		Write-Debug $Error[0].Exception
	}
	Write-Debug "end checking Application events"

	#=======================
	# System Event Logs
	#=======================

	#error events
	Write-Debug "start checking System events..."
	try
	{
		# get all system/info logs in last x days
		logmsg "[INFO] Collecting System Info logs. This operation can take some time..."
		$time = (Measure-Command{
			$sysevt_info = get-eventlog -LogName System -after $starttime -EntryType Information -ComputerName $env:computername -ea 0 `
			| select eventid, timegenerated, source, message, entrytype, properties `
			| Sort-Object -Property TimeGenerated -Descending `
			| Select-Object -First $EventParserMaxEvents 
		} | select totalseconds).totalseconds
		write-debug ("Collecting System Info logs completed in {0} seconds." -f $time)
		$totaltime += $time

		# get all system/info logs in last x days
		logmsg "[INFO] Collecting System Warning logs. This operation can take some time..."
		$time = (Measure-Command{
			$sysevt_warn = get-eventlog -LogName System -after $starttime -EntryType Warning -ComputerName $env:computername -ea 0 `
			| select eventid, timegenerated, source, message, entrytype, properties `
			| Sort-Object -Property TimeGenerated -Descending `
			| Select-Object -First $EventParserMaxEvents 
			
		} | select totalseconds).totalseconds
		write-debug ("Collecting System Warning logs completed in {0} seconds." -f $time)
		$totaltime += $time

		# get all system/error logs in last x days
		logmsg "[INFO] Collecting System Error logs. This operation can take some time..."
		$time = (Measure-Command{
			$sysevt_err = get-eventlog -LogName System -after $starttime -EntryType $EntryTypeFiler -ComputerName $env:computername -ea 0 `
			| select eventid, timegenerated, source, message, entrytype, properties `
			| Sort-Object -Property TimeGenerated -Descending `
			| Select-Object -First $EventParserMaxEvents 
			
		} | select totalseconds).totalseconds
		write-debug ("Collecting System Error logs completed in {0} seconds." -f $time)
		$totaltime += $time


		# parsing info
		logmsg "[INFO] Parsing System Info logs..."
		$time = (Measure-Command{
			$sys_masterGuestEvents  += $sysevt_info |Where-Object{`
			(($_.EventId -eq 11 -and $_.Source -match "disk") `
			-or ($_.EventId -eq 157 -and $_.Source -match "disk") `
			-or $_.EventId -eq 1074 `
			-or $_.EventId -eq 833 `
			-or (($_.EventId -eq 13 -or $_.EventId -eq 12) -and $_.Source -match "kernel-general")) `
			}
		} | select totalseconds).totalseconds
		write-debug ("Parsing System Info logs completed in {0} seconds." -f $time)
		$totaltime += $time

		# parsing warnings
		logmsg "[INFO] Parsing System Warning logs..."
		$time = (Measure-Command{
			$evt_129 = $sysevt_warn |Where-Object{$_.EventId -eq 129 -and $_.Source -match "storvsc"}
			#set flag
			$script:HasEvt129 = ($evt_129.Count -gt 0)
			$sys_masterGuestEvents  += $evt_129
		} | select totalseconds).totalseconds
		write-debug ("Parsing System Warning logs completed in {0} seconds." -f $time)
		$totaltime += $time

		# parsing errors
		logmsg "[INFO] Parsing System Error logs..."
		$time = (Measure-Command{
			$cluster_threshold = $sysevt_err | Where-Object{$_.EventID -eq 1135 -and $_.Source -match "Microsoft-Windows-FailoverClustering"}
			$script:HasClusterThreshold  = ($cluster_threshold -gt 0)
			$sys_masterGuestEvents  += $sysevt_err 
		} | select totalseconds).totalseconds
		write-debug ("Parsing System Error logs completed in {0} seconds." -f $time)
		$totaltime += $time

	}catch{
		Write-Debug $Error[0].Exception
	}
	Write-Debug "end checking System events"

	logmsg "[INFO] Post-processing..."
	$time = (Measure-Command{
		try{
			# process app logs
			Write-Debug "post-processing app logs"
			Write-Debug ("app_masterGuestEvents.Count = {0}" -f $app_masterGuestEvents.Count)
			if($app_masterGuestEvents.Count -gt 0){
				$app_masterGuestEvents | % {
					if($_.Message.Length -eq 0)
					{
			    		$tmpMsg = ""
			    		for($i = 0; $i -lt $_.Properties.Count; $i ++)
			    		{
			    			$tmpMsg += $properties[$i].Value.ToString() 
							if($i -ne ($_.Properties.Count-1)){
								$tmpMsg += " | "
							}
			    		}

						$_.Properties = $null
			    		$_.Message = $tmpMsg
						Write-Debug ("app log empty message found, {0}" -f $tmpMsg)
					}
				
					if($_ -ne $null){
						Add-Member -InputObject $_ -MemberType NoteProperty -Name "LogType" -value "Application"
						$script:masterGuestEvents += $_ | select eventid,timegenerated,source,message,entrytype,LogType
					}
				}

				#export app logs to csv
				$app_masterGuestEvents | export-csv –path $app_csv -ea 0

			}else{
				logmsg "[INFO] No app events to process."
			}
		
			# process syslogs
			Write-Debug "post-processing sys logs"
			Write-Debug ("sys_masterGuestEvents.Count = {0}" -f $sys_masterGuestEvents.Count)
			if($sys_masterGuestEvents.Count -gt 0){
			
				$sys_masterGuestEvents | % {
					if($_.Message.Length -eq 0)
					{
			    		$tmpMsg = ""
			    		for($i = 0; $i -lt $_.Properties.Count; $i ++)
			    		{
			    			$tmpMsg += $properties[$i].Value.ToString() 
							if($i -ne ($_.Properties.Count-1)){
								$tmpMsg += " | "
							}
			    		}

						$_.Properties = $null
			    		$_.Message = $tmpMsg
						Write-Debug ("sys log empty message found, {0}" -f $tmpMsg)
					}
					
					if($_ -ne $null){
						Add-Member -InputObject $_ -MemberType NoteProperty -Name "LogType" -value "System"
						$script:masterGuestEvents += $_ | select eventid,timegenerated,source,message,entrytype,LogType
					}
				}

				#export app logs to csv
				$sys_masterGuestEvents | export-csv –path $sys_csv -ea 0
				
			}else{
				logmsg "[INFO] No sys events to process."
			}
		
		}catch{
			Write-Debug $Error[0].Exception
		}
	} | select totalseconds).totalseconds
	write-debug ("Post processing completed in {0} seconds." -f $time)
	$totaltime += $time

	#sort object 
	logmsg "[INFO] Sorting..."	
	$time = (Measure-Command{
		if($script:masterGuestEvents.Count -gt 0)
		{
			$script:masterGuestEvents = $script:masterGuestEvents | Sort-Object -Property TimeGenerated -Descending | ConvertTo-Array
		}
	} | select totalseconds).totalseconds
	write-debug ("Sorting completed in {0} seconds." -f $time)
	$totaltime += $time

	#need to apply filter for events
	
	# ===============================
	("Check event log completed in {0} seconds." -f $totaltime) | Out-File $Script:GuestStorageLog -Append
	write-host "Check event log completed in " -NoNewline -ForegroundColor Gray
	write-host $totaltime -ForegroundColor Cyan -NoNewline
	Write-Host " seconds." -ForegroundColor Gray
}

function collectEventlogs()
{
	Write-Debug "start collecting event logs"
	#function will copy all evt files to logpath
	$Eventlogs = Get-WmiObject -Class Win32_NTEventLogFile -ComputerName $env:COMPUTERNAME 

	ForEach($log in $EventLogs)
	{
		write-debug ("Saving event log {0} ..." -f $log.LogFileName)
		$path = "$script:logpath_Logs\{0}_{1}.evt" -f $env:COMPUTERNAME,$log.LogFileName 
		Copy-Item -path $log.Name -dest "$path" -force 
	}
	$path = "$script:logpath_Logs\{0}_{1}.evt" -f $env:COMPUTERNAME,"application"
	Remove-Item $path 

	Write-Debug "end collecting event logs"
}

function checkClusterConfig()
{
	header "Displaying Cluster Thresholds"

	#
	if($script:HasClusterThreshold){
		logerr "Please verify that cluster network thresholds are set correctly. Please see <a target='_blank' href='https://blogs.msdn.microsoft.com/alwaysonpro/2014/06/02/iaas-with-sql-alwayson-tuning-failover-cluster-network-thresholds/'>this article</a>"
	}

	try{

	$cluster = (get-wmiobject -namespace root\MSCluster -class MSCluster_Cluster -ErrorAction Stop)
	if ($cluster){
       
		loginfo ("CrossSubnetThreshold: {0}" -f $cluster.CrossSubnetThreshold)
		loginfo ("SameSubnetThreshold: {0}" -f $cluster.SameSubnetThreshold)
		loginfo ("RouteHistoryLength: {0}" -f $cluster.RouteHistoryLength)

		$clusterthres = get-cluster | fl *subnet* | Out-File $Script:GuestStorageLog -Append
		
		Write-Debug "checking KB2854082"
        try{
              Get-HotFix -Id KB2854082 -ErrorAction Stop
              loginfo "KB2854082 is installed"
        }catch{
			   if ($script:HasSQLInstance){
               logErr "KB2854082 is not installed, but it's required for SQL Cluster installtions: <a target='_blank' href='https://support.microsoft.com/en-us/kb/2854082'>KB2854082</a>"
			   }
        }

		If ($cluster.CrossSubnetThreshold -lt 20 -or $cluster.SameSubnetThreshold -lt 20 -or $cluster.RouteHistoryLength -lt 20) {
			Write-Debug "checking KB3161606,KB3172614,KB3153887"
			try{			
				   Get-HotFix -Id KB3161606 -ErrorAction Stop
                   $KB3161606 = $True
                   loginfo "KB3161606 is installed"
            }
            catch{ 
                   loginfo "KB3161606 is not installed"
                   $KB3161606 = $False
            }
            try{
				   Get-HotFix -Id KB3172614 -ErrorAction Stop
                   $KB3172614 = $True
                   loginfo "KB3172614 is installed"
            }catch{
                   loginfo "KB3172614 is not installed"
                   $KB3172614 = $False
            }
            if (!$KB3161606 -and !$KB3172614){
                logErr "KB3161606 and KB3172614 are not installed, please review KB3153887 to set the correct threshold settings or install KB3172614: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3153887'>KB3153887</a>"
			}
            else
            {
                logwarn "Please review KB3153887 as we could identify settings/thresholds which seem not to be set optimal: <a target='_blank' href='https://support.microsoft.com/en-us/kb/3153887'>KB3153887</a>"
            }
		}

		#create cluster validation report	
		#11-30-2017 - Disabling the cluster validation report due to an active issue in Test-Cluster commandlet where the cluster may be negatively affected or disks removed while running storage related tests
		 
		#Test-Cluster -Force -ReportName "$script:logpath_Logs\clusterreport"

		#if(Test-Path $script:logpath_Logs\clusterreport.mht)
		#{
		#	loginfo "Link to validation tests report for failover cluster settings: <a target='_blank' href='../logs/clusterreport.mht'>Report</a>"
		#}

		#get cluster logs of last 24 hours
		#Get-Clusterlog -Destination "$script:logpath_Logs" -TimeSpan 1440
     }
	}
	catch
	{
		Write-Debug "No cluster found."
	} 

}

function checkVMsize()
{
	header "Check VM Size" 
	
	$Computer = Get-WmiObject -Class Win32_ComputerSystem  
	#number of cores and speed of cores
	$processors = get-wmiobject -computername $env:COMPUTERNAME win32_Processor
	#$cpuSpeed = ((get-wmiobject -computername $Computer.Name Win32_Processor).MaxClockSpeed)/1000
	$cpuSpeed = (get-wmiobject Win32_Processor).MaxClockSpeed
	$cpuspeedstring = ("{0}" -f  $cpuspeed)
	$cpuspeedint = ([int]$cpuspeedstring)/1000

	$cores=0
	if (@($processors)[0].NumberOfCores)
	{
		$cores = @($processors).Count * @($processors)[0].NumberOfCores
	}
	else
	{
		$cores = @($processors).Count
	}
	
	$script:cores = $cores

	#size of memory
	$wmi_mem = get-wmiobject Win32_ComputerSystem -cn $env:COMPUTERNAME | select TotalPhysicalMemory
	$script:memory = $wmi_mem.TotalPhysicalMemory
	$mem = $wmi_mem | select @{name="PhysicalMemory";Expression={"{0:N2}" -f($script:memory/1gb).tostring("N0")}},NumberOfProcessors,Name,Model
	$memory = $mem.PhysicalMemory
	
	$TempDrive = "DeviceID='$Script:tempDrive'" 

	#size of temp disk
	$disk = Get-WmiObject Win32_LogicalDisk -ComputerName $env:COMPUTERNAME -Filter $TempDrive | Select-Object Size
	#$disksize = "{0:N0}" -f ($disk.Size/1gb)
	$disksize = ($disk.Size/1gb).ToString('#')

	#paste values to log
	$vmsizetext = "CPU speed:$cpuspeedint Number of cores:$cores Memory Size:$memory Temp Disk Size:$disksize" 
	#$vmsizetext | Out-File $Script:GuestStorageLog -Append
	loginfo $vmsizetext
	#lookup table missing

	# Lookup the VM Size from the lookup table
	$db = Import-csv $script:vmlookupFilePath -Delimiter ","

	$Script:VMSize = $db | Where-Object { 
		($_.'CPU cores' -eq $cores) -and (("{0:N1}" -f ([double]$_.'CPU speed') )-eq ("{0:N1}" -f ([double]$cpuspeedint)) ) -and ($_.'memory size' -eq $memory) -and ($_.'Max. Temp disk size in GB' -eq $disksize)
	} | Select Size, 'Max. IOPS', 'Max. data disks', 'Max. Throughput', StorageTier

	if($Script:VMSize -eq $null)
	{
		logInfo "Could not detect VM size."
	}else{
	
		if($Script:VMSize -is [System.Array] -and $Script:VMSize.Count -gt 1){
			loginfo ("More than 1 VM size detected, using the first one in the list: {0}." -f $Script:VMSize[0].Size)
			
			$Script:VMSize | ft * -AutoSize
			$Script:VMSize | ft * -AutoSize | Out-File $Script:GuestStorageLog -Append

			$Script:VMSize = $Script:VMSize[0]
		}else{
			$strSize = $Script:VMSize.Size
			logInfo ("VM size detected: {0}. " -f $strSize) 
			write-host $strSize  -ForegroundColor Green
		}
	
		loginfo ("This script will use storage performance tier = {0} DataDisk " -f $Script:VMSize.StorageTier) 
	}
}

function checkPowerPlan() {

	header "Checking Power Plan Options"

	$HighPerfPowerPlan = powercfg -l | %{if($_.contains("High performance")) {$_.split()[3]}}
	$CurrPowerPlan = $(powercfg -getactivescheme).split()[3]
	if ($CurrPowerPlan -ne $HighPerfPowerPlan) 
	{
		logwarn "Power plan is not set to High Performance, for more information see <a target='_blank' href='https://technet.microsoft.com/en-us/library/dd744398(v=ws.10).aspx'>Configure Power Plans</a>" 
	}
	else
	{
		loginfo "Power plan is set to High Performance."
	}
}

function checkStorageSpaces() {

	header "Displaying Storage Spaces Configuration"
	
	# get all non-primordial pools from the machine 
	$pools = Get-Pools

	# list storage spaces
	
	if($pools -ne $null){
		logmsg "[INFO] Listing all (non-primordial) storage pools: "
		$script:DiskOverview_PoolsObj = @()
		$pools | select PoolName, OperationalStatus, HealthStatus, IsReadonly, VirtualDiskCount, PhysicalDiskCount | % {
			$script:DiskOverview_PoolsObj += $_
		}
		$script:DiskOverview_PoolsObj | ft -AutoSize -Wrap
		$script:DiskOverview_PoolsObj | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append

	}else{
		# no pool detected, return
		logmsg "[INFO] No storage pools detected."
		return
	}

	logmsg "[INFO] List automatic clustering settings for storage subsystems:"
	$storageSubClustering =  Get-StorageSubsystem 
	$script:DiskOverview_AutoClusterObj = @()
	$storageSubClustering | select  FriendlyName, AutomaticClusteringEnabled | % {
		$script:DiskOverview_AutoClusterObj += $_
	}
	$script:DiskOverview_AutoClusterObj | ft -Wrap -AutoSize
	$script:DiskOverview_AutoClusterObj | Ft -Wrap -AutoSize | Out-File $Script:GuestStorageLog -Append


	"" | Out-File $Script:GuestStorageLog -Append

	# get primordial pools 
	
	$poolVDisks = $pools | % {
		$pool = $_
		$pool.Pool | Get-VirtualDisk | % {
			$vd = $_
			New-Object PSObject -Property @{
				PoolName = $pool.PoolName
				VDiskName = $vd.FriendlyName
				ResiliencySettingName = $vd.ResiliencySettingName
				ProvisioningType = $vd.ProvisioningType
				NumberOfColumns = $vd.NumberOfColumns
				Interleave = $vd.Interleave
				HealthStatus = $vd.HealthStatus
				OpStatus = $vd.OperationalStatus
				PhysicalDiskCount = $pool.PhysicalDiskCount
				IsManualAttach = $vd.IsManualAttach
			}
		}
	} 
       
	if($poolVDisks -ne $null){
		logmsg "[INFO] Listing virtual disks:"
		$script:DiskOverview_VirtualDisksObj = @()
		$poolVDisks | select VDiskName, PoolName, ResiliencySettingName, Interleave, NumberOfColumns, PhysicalDiskCount, HealthStatus, OpStatus  | % { 
			$script:DiskOverview_VirtualDisksObj += $_
		}
		$script:DiskOverview_VirtualDisksObj | ft -Wrap -AutoSize
		$script:DiskOverview_VirtualDisksObj | ft -Wrap -AutoSize | Out-File $Script:GuestStorageLog -Append
	}else{
		logmsg "[INFO] No virtual disk detected."
	}

	"" | Out-File $Script:GuestStorageLog -Append
	
	$poolDisks = $pools | % {
		$pool = $_
		$pool.Pool | Get-PhysicalDisk | %{
			$physicaldisk = $_
			New-Object PSObject -Property @{
				PoolName = $pool.PoolName
				PhysicalDiskName = $devicename = ("PhysicalDrive{0}" -f $physicaldisk.DeviceID)
				FriendlyName = $physicaldisk.FriendlyName
				OperationalStatus = $physicaldisk.OperationalStatus
				HealthStatus = $physicaldisk.HealthStatus
				SizeInGB = ($physicaldisk.Size / 1GB).ToString('#')
				Usage = $physicaldisk.Usage
			}
		}
	}
	if($poolDisks -ne $null){
		logmsg "[INFO] Listing pooled physical disks:"
		$script:DiskOverview_PooledDisksObj = @()
		$poolDisks | select PhysicalDiskName, FriendlyName, PoolName, SizeInGB, HealthStatus, OperationalStatus, Usage | % {
			$script:DiskOverview_PooledDisksObj += $_ 
		}
		$script:DiskOverview_PooledDisksObj | ft -Wrap -AutoSize
		$script:DiskOverview_PooledDisksObj | ft -Wrap -AutoSize | Out-File $Script:GuestStorageLog -Append
	}else{
		logmsg "[INFO] No pooled physical disks detected."
	}
		

	header "Analysis on Storage Spaces Configuration"

	# check for automatic clustering
	$ss = Get-StorageSubsystem
	$ss | %	{
		$sub = $_
		If ($sub.AutomaticClusteringEnabled -eq $true)  {
			logerr ("Subsystem [{0}] has clustering enabled. This should be disabled on Azure VMs. <a target='_blank' href='https://technet.microsoft.com/en-us/library/hh831739.aspx#BKMK_AZURE'>Link to Best Practices</a>" -f $sub.FriendlyName)

		}else{
			loginfo ("Subsystem [{0}] has clustering disabled." -f $sub.FriendlyName)
		}
	}

	"" | Out-File $Script:GuestStorageLog -Append

	#get pools with more than 1 VirtualDisk
	$wrongpools = $pools | where-object {$_.VirtualDiskCount -gt 1} | % { 
	    $p = $_
	    $p.VirtualDisks | % {
	        New-Object PSObject -Property @{
	            PoolName = $p.PoolName
	            VirtualDiskName = $_.FriendlyName
	        }	
	    }
	}
	$multiDiskPools = $pools | where-object {$_.VirtualDiskCount -gt 1}
	if($multiDiskPools -ne $null){
		logmsg "[INFO] Checking if all pools have single virtual disk:"
		$multiDiskPools | % {
			$vds = ""
			$_.VirtualDisks | % { $vds = $vds + ("{0}," -f $_.FriendlyName) }
			logerr ("Pool {0} has more than 1 virtual disk. Should have 1: [ {1} ]  <a target='_blank' href='https://technet.microsoft.com/en-us/library/hh831739.aspx#BKMK_AZURE'>Link to Best Practices</a>" -f $_.PoolName, $vds)
		}
		$script:DiskOverview_MultiVirtualDiskPoolesObj = @()
		$wrongpools | % {
			$script:DiskOverview_MultiVirtualDiskPoolesObj += $_
		}
		$script:DiskOverview_MultiVirtualDiskPoolesObj | ft -AutoSize -Wrap
		$script:DiskOverview_MultiVirtualDiskPoolesObj | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
		
	}else{
		loginfo "All pools have single virtual disk"
	}

	"" | Out-File $Script:GuestStorageLog -Append

	# get vdisk with numberOfColumns different than number of disks
	$wrongvdisks = $poolVDisks | % { 
	    $p = $_
		if($p.PhysicalDiskCount -ne $p.NumberOfColumns){
			logerr ("Virtual disk ({0}) on pool ({1}) has NumberOfColumn ({2}) != PhysicalDiskCount ({3}). Recreate the virtual disk using PS cmdlet: New-VirtualDisk with option NumberOfColumns. <a target='_blank' href='https://technet.microsoft.com/en-us/library/hh831739.aspx#BKMK_AZURE'>Link to Best Practices</a>" -f $p.VDiskName, $p.PoolName, $p.NumberOfColumns, $p.PhysicalDiskCount)
			$p
		}
	}
	if($wrongvdisks -ne $null){
		$script:DiskOverview_WrongNOCObj = @()
		$wrongvdisks | select VDiskName, PoolName, NumberOfColumns, PhysicalDiskCount | % {
			$script:DiskOverview_WrongNOCObj += $_ 
		}
		$script:DiskOverview_WrongNOCObj | ft -AutoSize -Wrap
		$script:DiskOverview_WrongNOCObj | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
	}else{
		loginfo "All virtual disks have NumberOfColumn equal to the number of pooled disks."
	}

	"" | Out-File $Script:GuestStorageLog -Append

	# get vdisk with numberOfColumns = 1
	$wrongvdisks1 = $poolVDisks | Where-Object {$_.NumberOfColumns -eq 1} 
	if($wrongvdisks1 -ne $null){
		$wrongvdisks1 | % {
			logwarn ("Virtual disk {0} has NumberOfColumn = 1. Storage Spaces requires at least 2 disks to improve performance. <a target='_blank' href='https://technet.microsoft.com/en-us/library/hh831739.aspx#BKMK_AZURE'>Link to Best Practices</a>" -f $_.VDiskName)
		}
		
	}else{
		loginfo "All virtual disks have NumberOfColumn > 1."
	}

	"" | Out-File $Script:GuestStorageLog -Append

	# get vdisk with wrong interleave
	$wrongInterleave = $poolVDisks | Where-Object { !(((64 * 1KB), (256 * 1KB)) -contains  $_.Interleave)} 
	if($wrongInterleave -ne $null){
		$script:DiskOverview_WrongInterleaveObj = @()
		$wrongInterleave | select VDiskName, Interleave | % {
			$script:DiskOverview_WrongInterleaveObj += $_
		}
		$script:DiskOverview_WrongInterleaveObj	| ft -AutoSize -Wrap
		$script:DiskOverview_WrongInterleaveObj	| ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
		$wrongInterleave | % {
			logerr ("VirtualDisk {0} has unexpected interleave value: {1}. Expected values are: 65536 (for OLTP IO load), 262144 (for DataWarehouse IO Load). <a target='_blank' href='https://blogs.msdn.microsoft.com/mast/2014/10/14/configuring-azure-virtual-machines-for-optimal-storage-performance/'>Link to Best Practices</a>" -f $_.VDiskName, $_.Interleave)
		}
	}else{
		loginfo "All virtual disks have valid interleave value."
	}
	
	"" | Out-File $Script:GuestStorageLog -Append

	# get vdisk with resiliencysettings not Simple
	$wrongResSet = $poolVDisks | Where-Object {$_.ResiliencySettingName -ne "Simple"} 
	if($wrongResSet -ne $null){
		$script:DiskOverview_wrongResiliencySettingObj  = @()
		$wrongResSet  | select VDiskName, ResiliencySettingName | % {
			$script:DiskOverview_wrongResiliencySettingObj += $_
			logerr ("Virtual disk {0} has improper ResiliencySettingName value for optimal performance: {1}. Expected values is: Simple. Redundancy is already implemented in Azure Storage. <a target='_blank' href='https://technet.microsoft.com/en-us/library/hh831739.aspx#BKMK_AZURE'>Link to Best Practices</a>" -f $_.VDiskName, $_.ResiliencySettingName)
		}
		$script:DiskOverview_wrongResiliencySettingObj	| ft -AutoSize -Wrap
		$script:DiskOverview_wrongResiliencySettingObj	| ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
	}else{
		loginfo "All virtual disks have valid ResiliencySettingName value."
	}

	# get vdisk with IsManualAttach set to True
	$wrongIsManualAttach = $poolVDisks | Where-Object {$_.IsManualAttach -eq $true} 
	if($wrongIsManualAttach -ne $null){
		$script:DiskOverview_wrongIsManualAttachObj  = @()
		$wrongIsManualAttach  | select VDiskName, IsManualAttach | % {
			$script:DiskOverview_wrongIsManualAttachObj += $_
			logerr ("Virtual disk {0} is configured with improper IsManualAttach setting : {1}. For the disk to be automatically attached upon server restart, this property must be set to False. <a target='_blank' href='https://blogs.msdn.microsoft.com/dfurman/2014/04/27/using-storage-spaces-on-an-azure-vm-cluster-for-sql-server-storage/'>Link to Best Practices</a>" -f $_.VDiskName, $_.IsManualAttach)
		}
		$script:DiskOverview_wrongIsManualAttachObj	| ft -AutoSize -Wrap
		$script:DiskOverview_wrongIsManualAttachObj	| ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
	}else{
		loginfo "All virtual disks have valid IsManualAttach value."
	}

	"" | Out-File $Script:GuestStorageLog -Append
}

function checkDiskConfig() {

	# ======================================================================

	header "Storage Configuration"

	#list all volumes in summary
	logmsg "All physical disks from DISKPART"
	$script:DiskOverview_AllDiskpartObj = @()
	Get-DiskMap | Select PhysicalDiskName, SCSIPort, SCSIBus, SCSITargetId, SCSILun, SizeGB | % {
		$script:DiskOverview_AllDiskpartObj += $_ 
	}
	# Comment out these redundant log to console, since they make PowerShell pipeline stop on WS2008R2.
	# It is not clear why it didn't happen before. But it can stably repro on WS2008R2 VMs.
	#$script:DiskOverview_AllDiskpartObj | ft -AutoSize
	$script:DiskOverview_AllDiskpartObj | ft -AutoSize | Out-File $Script:GuestStorageLog -Append

	if($os -eq "Win8orWin10"){
		logmsg "All physical disks from SPACEPORT"
		$script:DiskOverview_AllSpaceportObj = @()
		Get-DetailedPhysicalDisks | Select PhysicalDiskName, SCSIPort, SCSIBus, SCSITargetId, SCSILun, SizeGB | % {
			$script:DiskOverview_AllSpaceportObj +=  $_
		}
		#$script:DiskOverview_AllSpaceportObj | ft -AutoSize
		$script:DiskOverview_AllSpaceportObj | ft -AutoSize | Out-File $Script:GuestStorageLog -Append
		
	}

	"" | Out-File $Script:GuestStorageLog -Append

	logmsg "All volumes in summary"
	$script:DiskOverview_AllVolumesObj = @()
	Get-VolumeMap | Select VolumeID, SizeGB, FreeGB, Type, IsOSDisk, IsTempDisk, IsDataDisk, IsDynamic, IsPooled, VDisk_ResiliencySettingName, AllocationUnitSize  | % {
		$script:DiskOverview_AllVolumesObj += $_ 
	}
	#$script:DiskOverview_AllVolumesObj | ft -AutoSize -Wrap
	$script:DiskOverview_AllVolumesObj | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append

	"" | Out-File $Script:GuestStorageLog -Append

	#list all volumes
	logmsg "[INFO] Saving all volumes..."
	#Get-VolumeMap | fl * | Out-File $Script:GuestVolumeMapJS -Append
	$o = Get-VolumeMap
	$j = ConvertTo-PS2Json -inputObject $o -variablename "outputObj" -arrayname "volumeObj"
	$j | Out-File $Script:GuestVolumeMapJSon -Append
	
	write-debug "export volumemap as NFO file"
	Get-NfoVolumeMap | Out-File $Script:GuestVolumeMapNfo

	#list all disks
	logmsg "[INFO] Saving all disks..."
	$o = Get-DiskMap
	$j = ConvertTo-PS2Json -inputObject $o -variablename "outputObj" -arrayname "diskObj"
	$j | Out-File $Script:GuestDiskMapJSon -Append


	# ======================================================================


	header "Analysis on Basic Storage Configuration"

	logmsg "[INFO] Checking physical disks with multiple volumes:"

	$volumesPerDisk  = get-reversedvolumemap | select *, @{Expression={$_.Volumes.Count};Label="Count"}
	 
	#$volumesPerDisk  | select PhysicalDiskName, Count | ft -AutoSize -Wrap 
	$volumesPerDisk  | select PhysicalDiskName, Count | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
	
	$script:DiskOverview_MultiVolumesDiskObj = @()
	$volumesPerDisk | where-object {$_.Volumes.Count -gt 1} | % {
		$script:DiskOverview_MultiVolumesDiskObj += $_
	}

	if($script:DiskOverview_MultiVolumesDiskObj -ne $null){
		$script:DiskOverview_MultiVolumesDiskObj | % {
			logwarn ("Physical disk {0} has {1} Volumes/Partitions, it should have 1. Check <a href='#' onclick='return OpenDiskmapLocation();'>DiskMap Tab</a> for details. <a target='_blank' href='https://technet.microsoft.com/en-us/library/hh831739.aspx#BKMK_AZURE'>Link to Best Practices</a>." -f $_.PhysicalDiskName, $_.Count)
		}
	}else{
		loginfo "All disks have one volume/partition."
	}
	
	logmsg "[INFO] Checking data disk volumes with wrong allocation unit size:"
	
	$allDisks = Get-VolumeMap | where-object {$_.IsDataDisk -or $_.IsOSDisk -or $_.IsTempDisk}
	$script:DiskOverview_AUSObj = @()
	$allDisks  | select VolumeID, ClusterSize, IsOSDisk, IsTempDisk, IsDataDisk | % {
		$script:DiskOverview_AUSObj += $_
	} 
	#$script:DiskOverview_AUSObj | ft -AutoSize -Wrap 
	$script:DiskOverview_AUSObj | ft -AutoSize -Wrap  | Out-File $Script:GuestStorageLog -Append

	$wrongclustersize = $allDisks  | where-object {$_.IsDataDisk -and ($_.ClusterSize /1KB) -ne 64 }
	if($wrongclustersize -ne $null){
		$wrongclustersize | % {
			if($script:HasSQLInstance){
				logerr ("Volume {0} has allocation unit size equal to {1}K. Since this VM is running SQLServer, this value should be 64K. <a target='_blank' href='https://technet.microsoft.com/en-us/library/cc966412.aspx#EEAA'>Link to Best Practices</a>" -f $_.VolumeID, ($_.ClusterSize /1KB))
			}else{
				logwarn ("Volume {0} has allocation unit size equal to {1}K. For generic scenarios it is preferrable to have 64K. <a target='_blank' href='https://technet.microsoft.com/en-us/library/hh831739.aspx#BKMK_AZURE'>Link to Best Practices</a>" -f $_.VolumeID, ($_.ClusterSize /1KB))
			}
		}
	}else{
		loginfo "All data disks volumes have allocation unit size equal to 64K."
	}
	
	checkRAID

	if($os -eq "Win8orWin10"){
		checkStorageSpaces
	}
}

function checkRAID()
{
	header "Dynamic Disk RAID Configuration"
	
	#get dynamic disk RAID volumes 
	$RAID_volumes = get-volumemap | Where-Object {$_.IsDynamic}

	# if no RAID exit
	if($RAID_volumes -eq $null){
		loginfo "No dynamic disk RAID found."
		return
	}

	logmsg "[INFO] Listing dynamic disk RAID volumes:"
		
	$script:DiskOverview_RAIDObj = @()

	$RAID_volumes | % {
		$rv = $_ | select VolumeID, type, NumOfDisks
		$script:DiskOverview_RAIDObj += $rv
	}

	#$script:DiskOverview_RAIDObj | ft -AutoSize -Wrap
	$script:DiskOverview_RAIDObj | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
		
	

	header "Analysis on Dynamic Disk RAID"

	logmsg "[INFO] Checking dynamic disk RAID volumes not configured as striped:"

	#Spanned Volumes
	$wrongRAID = $RAID_volumes | where-object {$_.IsSpanned} 
	if($wrongRAID -ne $null){
		
		$script:DiskOverview_wrongRAIDObj = @()

		$wrongRAID | % {
			$script:DiskOverview_wrongRAIDObj += $_
			logerr ("Volume {0} has unexpected RAID type. found : {1}. Should be : striped (RAID 0). Spanned disks do not improve performances. <a target='_blank' href='https://technet.microsoft.com/en-us/library/cc732422(v=ws.11).aspx'>Link to Best Practices</a>" -f $_.VolumeID, $_.type)
		}

		#$script:DiskOverview_wrongRAIDObj | ft -AutoSize -Wrap
		$script:DiskOverview_wrongRAIDObj | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
		
	}else{
		loginfo "All dynamic disks are configured with striping."
	}

	#Raid5 or Mirror
	$wrongRAID = $RAID_volumes | where-object {$_.IsMirrored -or $_.IsRAID5} 
	if($wrongRAID -ne $null){
		
		$script:DiskOverview_wrongRAIDObj = @()

		$wrongRAID | % {
			$script:DiskOverview_wrongRAIDObj += $_
			logerr ("Volume {0} has unexpected RAID type. found : {1}. Should be : striped (RAID 0). Redundancy is already implemented on Azure Storage. <a target='_blank' href='https://technet.microsoft.com/en-us/library/cc732422(v=ws.11).aspx'>Link to Best Practices</a>" -f $_.VolumeID, $_.type)
		}

		#$script:DiskOverview_wrongRAIDObj | ft -AutoSize -Wrap
		$script:DiskOverview_wrongRAIDObj | ft -AutoSize -Wrap | Out-File $Script:GuestStorageLog -Append
		
	}else{
		loginfo "All dynamic disks are configured with striping."
	}
}

function Get-SQLSettings()
{
	if(!$script:HasSQLInstance){
		Write-Debug "No SQL Server Instance found. Skipping data collection."
		return;
	}
	#get sql server instancenames from registry
	$sqlreg = Get-ItemProperty "HKLM:\software\microsoft\Microsoft SQL Server\" -ErrorAction SilentlyContinue
	
	#header "Checking SQL Server Settings"
	Write-Debug "found at least one SQL Server Instance installed in the VM"

	# load SMO library
	[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null

	#list of all SQL Instances present in the VM
	$SQLinstances = $sqlreg.InstalledInstances
	$script:SQLInstanceCount = $SQLinstances.Count
	
	# focus on data disks and OS disk
	$volumesHash = Get-VolumeMap -HashTable | where {$_.isdatadisk -or $_.isosdisk} 

	# total max memory defined for all SQL Server instances
	$totalMaxServerMemory = 0
	
	$script:SQLGroupedObj = @()
	# repeat for all SQL Instances
	foreach ($instanceName  in $SQLinstances) 
	{
 
		logmsg  "[INFO] Checking SQL Instance name: $instanceName"
		
		# Get the SQL Server "Server Name" used for connection
		if ( $instanceName -eq "MSSQLSERVER") # default instance 
		{ 
			$serverName = $env:computername 
			logmsg "[INFO] This is a default instance name. Actual server name used will be the computername : $serverName"
		}
		else # named instance
		{
			$serverName = $env:computername +"\" + $instanceName
			logmsg "[INFO] Server name is: $serverName"
		} 

		# configure SMO object
		$server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList $serverName

		logmsg "[INFO] Checking if SQL Server Instance $instanceName is running..."

		# log sql instance status
		$Status = $server.Status
		loginfo "SQL Server Instance $instanceName is $Status"
		

		try
		{
			# -----------------------------------------
			# analysis of instance configuration
			# -----------------------------------------

			Write-Debug "analysis of instance configuration"

			$maxDop = ($server.Configuration.Properties | where-object {$_.DisplayName -EQ "max degree of parallelism"}).RunValue
			$minServerMemory = ($server.Configuration.Properties | where-object {$_.DisplayName -EQ "min server memory (MB)"}).RunValue
			$maxServerMemory = ($server.Configuration.Properties | where-object {$_.DisplayName -EQ "max server memory (MB)"}).RunValue
			$version = ($server.Information.Properties | where-object {$_.Name -EQ "VersionString"}).Value
			$edition = ($server.Information.Properties | where-object {$_.Name -EQ "Edition"}).Value


			# -----------------------------------------
			# collecting database file location
			# -----------------------------------------
			Write-Debug "collecting database file location"

			# get accessible DataBases 
			$databases = $server.databases | Where-Object {$_.IsAccessible }
			Write-Debug ("accessible databases count: {0}" -f $databases.count)

			if( $databases -ne $null) 
			{
				# array of files
				$files = @()
				$dbs = @()
				# iterate over all databases of current sqlinstance
				foreach ($database in $databases) 
				{
					$dbfiles = @()
					 
					Write-Debug "database: $dataBase.Name"
					# collect DataFiles settings
					foreach ($filegroup in $database.FileGroups)
					{
						foreach ($file in $filegroup.Files)
						{
                            $file_volumeID = Get-VolumeIDFromPath -Path $file.filename
                            $file_volume = (Get-VolumeDisks -HashTable)[$file_volumeID]
							$dbfileitem = $file  | select name, filename, `
                                @{Expression={"Data"};Label="FileType"}, `
                                @{Expression={$file_volume};Label="Volume"}

							$files += $dbfileitem | select *, `
							    @{Expression={$dataBase.Name};Label="DataBaseName"}, `
								@{Expression={$dataBase.ID};Label="DataBaseId"}, `
								@{Expression={$dataBase.IsSystemObject};Label="IsSystemObject"}
							
							$dbfiles += $dbfileitem
						}
					}
                
					# collect TLogFiles settings
					foreach ($file in $database.LogFiles) 
					{
						$file_volumeID = Get-VolumeIDFromPath -Path $file.filename
						$file_volume = (Get-VolumeDisks -HashTable)[$file_volumeID]

						$dbfileitem = $file  | select name, filename, `
								@{Expression={"Log"};Label="FileType"}, `
                                @{Expression={$file_volume};Label="Volume"}

						$files += $dbfileitem | select *, `
								@{Expression={$dataBase.Name};Label="DataBaseName"}, `
								@{Expression={$dataBase.ID};Label="DataBaseId"}, `
								@{Expression={$dataBase.IsSystemObject};Label="IsSystemObject"}

						$dbfiles += $dbfileitem
					}

					$dbitem = New-Object PSCustomObject;
					Add-Member -InputObject $dbitem -MemberType NoteProperty -Name Name -Value $dataBase.Name;
					Add-Member -InputObject $dbitem -MemberType NoteProperty -Name ID -Value $dataBase.ID;
					Add-Member -InputObject $dbitem -MemberType NoteProperty -Name IsSystemObject -Value $dataBase.IsSystemObject;
					Add-Member -InputObject $dbitem -MemberType NoteProperty -Name Files -Value $dbfiles;
					$dbs += $dbitem
				} #foreach database
				
			}#if databases is not null
			else
			{
				loginfo "SQL Server Instance $instanceName has no accessible Databases."
			}

		}catch{
			logmsg "Script encountered errors while collecting data from SQL Server Instance $instanceName. Skipping SQL Settings check."
			Write-Debug $Error[0].Exception
		}
	

		$sqlObjItem = New-Object PSCustomObject;
		# collect general SQL Instance options
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name InstanceName -Value $instancename;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name ServerName -Value $serverName;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name Version -Value $version;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name Edition -Value $edition;
		# collect basic SQL Instance options
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name Information -Value $server.Information.Properties;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name Settings -Value $server.Settings.Properties;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name UserOptions -Value $server.UserOptions.Properties;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name Configuration -Value $server.Configuration.Properties;
		# collect perf settings
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name MaxDop -Value $maxDop;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name MinServerMemory -Value $minServerMemory;
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name MaxServerMemory -Value $maxServerMemory;
		# collect databases object		
		Add-Member -InputObject $sqlObjItem -MemberType NoteProperty -Name DataBases -Value $dbs;

		# add to array of instances
		$script:SQLGroupedObj += $sqlObjItem

	}# foreach instance
	
}

function Create-DiskJS
{
	$v = get-VolumeMap
}

# generate a Log record, compliant with Host Analyzer's findings json-format

##############################
#json structure HA, samples
        #                    "Value":  1.5,
        #                    "Message":  "Average XIOPS (xstore)",
        #                    "Time":  "",
        #                    "EventId":  "",
        #                    "Entity":  "/saaseu/vhds/realmeu-saaseu-2016-01-05.vhd",
        #                    "Class":  "info",
        #                    "Misc":  "BlobPerf",
        #                    "ClassScore":  1,
        #                    "Value1":  "0618164a-64b4-47e5-a202-aa7ba7bcc771"

		#                        {
        #                    "Value":  3,
        #                    "Message":  "IO(s) took more than Receive Timeout",
        #                    "Time":  "",
        #                    "EventId":  "",
        #                    "Entity":  "/seasonsvhd/vhds/SeasonsRemAppCloud-SeasonsSQL2014-2015-10-06.vhd",
        #                    "Class":  "danger",
        #                    "Misc":  "BlobPerf",
        #                    "ClassScore":  3,
        #                    "Value1":  "04c50239-ddc5-4a00-b500-f77e7cca0f82"
        #                },
##############################

function Log-HA {
	param(
		[Parameter(Mandatory=$True,Position=1)]
		[string]$Message="",
		[ValidateSet('info','warning','danger')]
		[string]$Class="info",
		[string]$Misc=$script:HostAnalizerLogMisc,
		[string]$Value="",
		[string]$EventId="",
		[string]$Entity="",
		[string]$ClassScore="",
		[string]$Value1="",
		[string]$Time=""
	)
		
	$Time=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
		$log = New-Object PSObject;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "Value" -Value $Value;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "Message" -Value $Message;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "Time" -Value $Time;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "EventId" -Value $EventId;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "Entity" -Value $Entity;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "Class" -Value $Class;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "Misc" -Value $Misc;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "ClassScore" -Value $ClassScore;
		Add-Member -InputObject $log -MemberType NoteProperty -Name "Value1" -Value $Value1;

	# add current log record to list
	$script:findings_Obj += $log
}

function Save-JS 
{
param(
	[object] $inputobject,
	[string] $objname = "array",
	[string] $variableName = "outputObj",
	[string] $filepath
)
	$output = New-Object -TypeName psobject
	$output | Add-Member -MemberType NoteProperty -Name $ObjName -Value $inputObject
	$outJS = ConvertTo-PS2JS -inputObject $output -variablename $variableName 
	$outJS | Out-File $filepath
}

# unique place for all automatic analysis
function Start-AutoAnalysis
{
	header "Auto Analysis"
	Run-SQLAnalysis
}

function Run-SQLAnalysis
{
	
	if(!$script:HasSQLInstance){
		Write-Debug "No SQL Server Instance found. Skipping Analysis."
		return;
	}

	logmsg "[INFO] SQL Server analysis"
	
	# -----------------------------------------
	# analysis of database file location
	# -----------------------------------------

	$FilesLocation = @()
	$FilesLocationUnique = @()
	$WrongLocation = @()

	# all files from all instances, normalized 
    $FilesLocation = foreach ( $sqlObjItem in $script:SQLGroupedObj){

        foreach( $db in $sqlObjItem.DataBases ){
            foreach ( $file in $db.files ) {
                foreach ( $disk in $file.volume.disks ) {
                    
                    $resultItem = New-Object PSCustomObject;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name VolumeID -Value $file.volume.VolumeID;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name PhysicalDiskName -Value $disk.PhysicalDiskName;
					Add-Member -InputObject $resultItem -MemberType NoteProperty -Name DiskNumber -Value $disk.DiskNumber;
					Add-Member -InputObject $resultItem -MemberType NoteProperty -Name SCSILun -Value $disk.SCSILun;
					Add-Member -InputObject $resultItem -MemberType NoteProperty -Name SCSIPort -Value $disk.SCSIPort;
					Add-Member -InputObject $resultItem -MemberType NoteProperty -Name SCSITargetId -Value $disk.SCSITargetId;
					Add-Member -InputObject $resultItem -MemberType NoteProperty -Name SCSIBus -Value $disk.SCSIBus;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name DatabaseName -Value $db.Name;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name DatabaseId -Value $db.ID;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name FileName -Value $file.name
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name FilePath -Value $file.FileName;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name FileType -Value $file.FileType;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name IsSystem -Value $db.IsSystemObject;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name InstanceName -Value $sqlObjItem.InstanceName;
				    Add-Member -InputObject $resultItem -MemberType NoteProperty -Name IsOSDisk -Value $file.Volume.IsOSDisk;
					Add-Member -InputObject $resultItem -MemberType NoteProperty -Name IsDataDisk -Value $file.Volume.IsDataDisk;
					Add-Member -InputObject $resultItem -MemberType NoteProperty -Name IsTempDisk -Value $file.Volume.IsTempDisk;
				    # return the item
				    $resultItem
                }
            }
        }
    }

	
	Write-Debug "analysis of database file location"

	# group sql files by physicaldiskName and filetype
	# improper configuration is detected with physicaldiskName behind at least 2 files of different types 	
	# step 1 is find misused disks by grouping with count > 1
	$misusedDisks = $FilesLocation | select DiskNumber, filetype -Unique | group DiskNumber | Where-Object {$_.count -gt 1} 

	# step 2 is filtering sql files on mixed IO disks => wronglocation
	$WrongLocation = foreach($misdisk in $misusedDisks) 	{
		$FilesLocation | Where-Object { $misDisk.Name -eq $_.DiskNumber } 
	}
	$WrongLocation = $WrongLocation | sort DiskNumber, VolumeID
	
	# smart object
	$rm = get-reversedvolumemap -HashTable 
	$WrongLocationGroupedByDisk = $WrongLocation | group DiskNumber | select name, group , @{Expression={$rm[[int]$_.name]};Label="VolumeDisk"}

	# step 3 log results
	$WrongLocation | select InstanceName, Databasename, isSystem -Unique | % {
		$dbtype = if($_.isSystem){"System"}else{"User"}
		logErr ("SQL Server Instance {0} : {1} Database '{2}' is located on physical disk(s) running with mixture of Data/TLOG files. Look <a href='#' onclick='return OpenSqlLocation();'>SQL tab</a> for further details and best practices." -f $_.instanceName, $dbtype, $_.Databasename)
	}

	# detect databases located on the OS Disk
	$FilesLocation | select InstanceName, Databasename, isSystem, IsOSDIsk -Unique | Where-Object {$_.IsOSDisk} | % {
		$dbtype = if($_.isSystem){"System"}else{"User"}
		logErr ("SQL Server Instance {0} : {1} Database '{2}' is running on The OS Disk. OS Disk should not be used to run SQL Database Files. Look <a href='#' onclick='return OpenSqlLocation();'>SQL tab</a> for further details and best practices." -f $_.instanceName, $dbtype, $_.Databasename)
	}

	# -----------------------------------------
	# analysis of memory management
	# -----------------------------------------

	Write-Debug "analysis of memory management"
	
	# MEMORY analysis
	foreach ( $sqlObjItem in $script:SQLGroupedObj){
		
		$totalMaxServerMemory += $sqlObjItem.MaxServerMemory
		
		# check if max server mem is unbounded
		if($sqlObjItem.maxServerMemory -eq 2147483647) {
			logWarn ("SQL Server Instance {0} has unlimited maximum server memory (MB) : {1}. It is recommended to limit this value and keep enough free memory for the system. <a target='_blank' href='https://blogs.msdn.microsoft.com/slavao/2006/11/13/q-a-does-sql-server-always-respond-to-memory-pressure/'>Link to Best Practices</a>" -f $instanceName, $maxServerMemory)
		}

		# check if min server mem = max server mem 
		if($sqlObjItem.minServerMemory -eq $sqlObjItem.maxServerMemory) {
			logWarn ("SQL Server instance {0} is running with the same value of {1}MB for both minimum server memory and maximum server memory. It is not recommended to set min server memory and max server memory server configuration options to the same value, thereby fixing the amount of memory allocated to SQL Server. Please use dynamic memory allocation as it gives you the best overall performance over time. <a target='_blank' href='https://technet.microsoft.com/en-us/library/ms177455(v=sql.105).aspx'>Link to Best Practices</a> " -f $instanceName, $minServerMemory)
		}
	}

	# check if free memory (total memory - max server memory) is at least 2 GB
	$freeMemory = ( ($script:memory / 1MB ) - $totalMaxServerMemory ) 
	# if negative, overrides with 0
	if($freeMemory -lt 0){$freeMemory=0}
	if($freeMemory -lt 1024 ) {
		logWarn ("Available Memory (total memory - max server memory used by all SQL Instances) is less than 1024 (MB) : {0} . It is recommended to leave enough free memory for the system. <a target='_blank' href='https://blogs.msdn.microsoft.com/slavao/2006/11/13/q-a-does-sql-server-always-respond-to-memory-pressure/'>Link to Best Practices</a>" -f $freeMemory)
	}else{
		logInfo ("Available Memory (total memory - max server memory used by all SQL Instances) = {0} (MB)." -f $freeMemory)
	}

	# -----------------------------------------
	# analysis of parallelism 
	# -----------------------------------------

	Write-Debug "analysis of parallelism"
	foreach ( $sqlObjItem in $script:SQLGroupedObj){
		# maxdop
			$sqlObjItem.Configuration | where-object {$_.Displayname -eq "max degree of parallelism"} | % {
			if($_.runvalue -gt $script:cores){
				logErr ("SQL Server Instance {0} is running with max degree of parallelism = {1}. This value should not be greater than available CPU Cores Number : {2}. <a target='_blank' href='https://support.microsoft.com/en-us/help/2806535/recommendations-and-guidelines-for-the-max-degree-of-parallelism-configuration-option-in-sql-server'>Link to Best Practices</a>" -f $sqlObjItem.instanceName, $_.runvalue, $script:cores)
			}
		}
	}
	# -----------------------------------------
	# wrap up all results
	# -----------------------------------------

	Write-Debug "wrap up all results"


	$script:SQL_Obj = new-object pscustomobject
	$script:SQL_Obj | Add-Member -MemberType NoteProperty -Name	WrongLocation -Value $WrongLocation;
	$script:SQL_Obj | Add-Member -MemberType NoteProperty -Name	Grouped -Value $script:SQLGroupedObj;
	$script:SQL_Obj | Add-Member -MemberType NoteProperty -Name	WrongGrouped -Value $WrongLocationGroupedByDisk

}

function InitializeAppInsights
{
	# Init Applicaiton Insights
	$Script:eventSourceAssemblyPath = $Script:scriptfolder + "\tools\Microsoft.Diagnostics.Tracing.EventSource.dll"
	$Script:appInsightsAssemblyPath = $Script:scriptfolder + "\tools\Microsoft.ApplicationInsights.dll"
	[System.Reflection.Assembly]::LoadFrom($Script:eventSourceAssemblyPath)
	[System.Reflection.Assembly]::LoadFrom($Script:appInsightsAssemblyPath)
	$Script:AppInsightsClient = New-Object "Microsoft.ApplicationInsights.TelemetryClient"
	$Script:AppInsightsClient.InstrumentationKey = $script:settings.AppInsightsInstrumentationKey

	[System.Reflection.Assembly]::LoadFrom($Script:diagnosticsAssemblyPath)

	$customizedInitializer = New-Object "Microsoft.Azure.Performance.Diagnostics.Common.CustomizedTelemetryInitializer"
	$activeConfig = [Microsoft.ApplicationInsights.Extensibility.TelemetryConfiguration]::Active
	$initializers = $activeConfig.TelemetryInitializers
	$initializers.Add($customizedInitializer)
}

function Update-AppInsightsInstrumentationKey
{
	$reportHtmlFilePath = "$script:logpath\PerfInsights Report.html"
	$htmlContent = [IO.File]::ReadAllText($reportHtmlFilePath)
    $htmlContent.Replace('AppInsightsInstrumentationKeyValueToReplace', $script:settings.AppInsightsInstrumentationKey) | Set-Content $reportHtmlFilePath
}

function Log-ScriptRun
{
	param
	(
		[string] $scenarioToRun,
		[array] $customActionsToRun
	)

	# $PsBoundParameters is not used because it doesn't have default values.
	$paramsDict = New-Object "System.Collections.Generic.Dictionary``2[System.String, System.String]"
	$paramsDict.Add("Cleanup", $Cleanup)
	$paramsDict.Add("AcceptDisclaimerAndShareDiagnostics", $AcceptDisclaimerAndShareDiagnostics)
	$paramsDict.Add("TempDrive", $TempDrive)
	$paramsDict.Add("Debug", $Debug)
	$paramsDict.Add("NoSRNumber", $NoSRNumber)
	$paramsDict.Add("SRNumber", $SRNumber)
	$paramsDict.Add("RunAsChildProcess", $RunAsChildProcess)
	$paramsDict.Add("Scenario", $Scenario)
	$paramsDict.Add("CustomScenarioModules", $CustomScenarioModules)
	$paramsDict.Add("IntegrationTestMode", $IntegrationTestMode)
	$paramsDict.Add("NoGUI", $NoGUI)
	$paramsDict.Add("TracingDuration", $TracingDuration)

	$paramsDict.Add("PerfInsightsScriptVersion", $script:ver)
	$paramsDict.Add("ScenarioToRun", $scenarioToRun)
	$customActions = $customActionsToRun -join ','
	$paramsDict.Add("CustomActionsToRun", $customActions)

	$Script:AppInsightsClient.TrackEvent('PerfInsightsPSRun', $paramsDict, $null)
	$Script:AppInsightsClient.Flush()
}

function Unblock-Files
{
	param
	(
		[string] $folder
	)

	Get-ChildItem $folder -Recurse | where {-not $_.PSIsContainer} | ForEach-Object {
		$filePath = $_.FullName
		# start diagnostics engine
		# unblock-file cmdlet is not available on Windows Server 2008 R2, so 
		# we use echo to unblock assemblies
		$cmdToRemoveZoneId = "echo.>`""+$filePath+":Zone.Identifier`""
		cmd /c "$cmdToRemoveZoneId"
	}
}

# #############################
#initialize variables and load settings
Init

# Do cleanup if switch is on and exit
if($Cleanup)
{
	Cleanup
	Exit
}

if ($Script:CancelExecution -eq $False -or $nogui)
{
	# Main workflow
	Main

	# Finalize script, pack output end exit
	ShutDown
}else{
	write-debug "Main: CancelExecution = true. Exiting as user did not accepted disclaimer"
}

Exit
# #############################

# SIG # Begin signature block
# MIIdjgYJKoZIhvcNAQcCoIIdfzCCHXsCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUwwVXpExznyDvP3Z7r6kbJEB4
# hXygghhSMIIEwTCCA6mgAwIBAgITMwAAANjkdflFb0j3rgAAAAAA2DANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTcxMDAyMjI1NzU3
# WhcNMTkwMTAyMjI1NzU3WjCBsTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEMMAoGA1UECxMDQU9DMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo3
# MERELTRCNUItNDU2ODElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMR2sf6C9y+kIdyj
# 16QouyVvlvPjzdmE1FFIAb7gUl7UCknd2nlquXeGJHQdX22zmY18QH/8EjH8voTu
# 57DqKJRFkqkD+PQ87+M4j2aW27QCHiHVATEHdHelT0ANUSoxETlAe4d6gd6sL/aA
# wkqFSqTncLfVeAenMJ7Te3tLmLYBk59CI/Tmf2YCsU+Z0nQ0S0AH6IHAKbDLLUPZ
# 1KW4d5Mmig1YMInsaoDHJvmuXyUZ6GxluZ7GX+WxF2XoxFRuMo6OWrCER3gnx/W3
# omzHOc1/C/oBI8hELBQH8uTJYqI8iGx8yqDyYETHoZNdH0oFeIOfAvVFlUYTE3JW
# pbMtF0cCAwEAAaOCAQkwggEFMB0GA1UdDgQWBBSgHm6PHyXdykNng5Up+ne9UdYe
# VjAfBgNVHSMEGDAWgBQjNPjZUkZwCu1A+3b7syuwwzWzDzBUBgNVHR8ETTBLMEmg
# R6BFhkNodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNyb3NvZnRUaW1lU3RhbXBQQ0EuY3JsMFgGCCsGAQUFBwEBBEwwSjBIBggrBgEF
# BQcwAoY8aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3Nv
# ZnRUaW1lU3RhbXBQQ0EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3
# DQEBBQUAA4IBAQCFDewTPdV6/bMFMK0kqgvI8Y7t1YvHrGmvpdA/Y2zx+ERd0g9d
# ENtHTlfAPC1X15YlDXZNPdo7LY6wMJco/rXcjzFZ/tIvGHcIaQE52tJKW+pmXfrv
# QWW4X3pQdbPTsCwcDSGPcDImnec0dathWPicWxBg1NIeSDDsdsqpESp0kSs9g9fL
# QWUi9wHlFehburgOJCWpQ1jkNspUvJ7xMmtTTEIu6WPEDGHU8LxHraClsL0/BzPN
# KE85uB3+5/yOurKU/V8kH/obxzB03XxI4QpbpU1D2yasOd7JVmCGEbHBRamtHVz6
# SnVVVviJUsoGV5/jdzHuXyUIy9LKSUwuTdykMIIGADCCA+igAwIBAgITMwAAAMMO
# m6fYstz3LAAAAAAAwzANBgkqhkiG9w0BAQsFADB+MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWdu
# aW5nIFBDQSAyMDExMB4XDTE3MDgxMTIwMjAyNFoXDTE4MDgxMTIwMjAyNFowdDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAu1fXONGxBn9JLalts2Oferq2OiFbtJiujdSkgaDFdcUs74JAKreBU3fzYwEK
# vM43hANAQ1eCS87tH7b9gG3JwpFdBcfcVlkA4QzrV9798biQJ791Svx1snJYtsVI
# mzNiBdGVlKW/OSKtjRJNRmLaMhnOqiJcVkixb0XJZ3ZiXTCIoy8oxR9QKtmG2xoR
# JYHC9PVnLud5HfXiHHX0TszH/Oe/C4BHKf/PzWmxDAtg62fmhBubTf1tRzrH2cFh
# YfKVEqENB65jIdj0mRz/eFWB7qV56CCCXwratVMZVAFXDYeRjcJ88VSGgOFi24Jz
# PiZe8EAS0jnVJgMNhYgxXwoLiwIDAQABo4IBfzCCAXswHwYDVR0lBBgwFgYKKwYB
# BAGCN0wIAQYIKwYBBQUHAwMwHQYDVR0OBBYEFKcTXR8hiVXoA+6eFzbq8lSINRmv
# MFEGA1UdEQRKMEikRjBEMQwwCgYDVQQLEwNBT0MxNDAyBgNVBAUTKzIzMDAxMitj
# ODA0YjVlYS00OWI0LTQyMzgtODM2Mi1kODUxZmEyMjU0ZmMwHwYDVR0jBBgwFoAU
# SG5k5VAF04KqFzc3IrVtqMp1ApUwVAYDVR0fBE0wSzBJoEegRYZDaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljQ29kU2lnUENBMjAxMV8yMDEx
# LTA3LTA4LmNybDBhBggrBgEFBQcBAQRVMFMwUQYIKwYBBQUHMAKGRWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljQ29kU2lnUENBMjAxMV8y
# MDExLTA3LTA4LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4ICAQBN
# l080fvFwk5zj1RpLnBF+aybEpST030TUJLqzagiJmZrLMedwm/8UHbAHOX/kMDsT
# It4OyJVnu25++HyVpJCCN5Omg9NJAsGsrVnvkbenZgAOokwl1NznXQcCyig0ZTs5
# g62VKo7KoOgIOhz+PntASZRNjlQlCuWxxwrucTfGm1429adCRPu8h7ANwDXZJodf
# /2fvKHT3ijAEEYpnzEs1YGoh58ONB4Nem6udcR8pJgkR1PWC09I2Bymu6JJtkH8A
# yahb7tAEZfuhDldTzPKYifOfFZPIBsRjUmECT1dIHPX7dRLKtfn0wmlfu6GdDWmD
# J+uDPh1rMcPuDvHEhEOH7jGcBgAyfLcgirkII+pWsBjUsr0V7DftZNNrFQIjxooz
# hzrRm7bAllksoAFThAFf8nvBerDs1NhS9l91gURZFjgnU7tQ815x3/fXUdwx1Rpj
# NSqXfp9mN1/PVTPvssq8LCOqRB7u+2dItOhCww+KUViiRgJhJloZv1yU6ahAcOdb
# MEx8gNRQZ6Kl7g7rPbXx5Xke4fVYGW+7iW144iBYJf/kSLPmr/GyQAQXRlDUDGyR
# FH3uyuL2Jt4bOwRnUS4PpBf3Qv8/kYkx+Ke8s+U6UtwqM39KZJFl2GURtttqt7Rs
# Uvy/i3EWxCzOc5qg6V0IwUVFpSmG7AExbV50xlYxCzCCBgcwggPvoAMCAQICCmEW
# aDQAAAAAABwwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZ
# MBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTA3MDQwMzEyNTMwOVoXDTIxMDQw
# MzEzMDMwOVowdzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEh
# MB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAn6Fssd/bSJIqfGsuGeG94uPFmVEjUK3O3RhOJA/u
# 0afRTK10MCAR6wfVVJUVSZQbQpKumFwwJtoAa+h7veyJBw/3DgSY8InMH8szJIed
# 8vRnHCz8e+eIHernTqOhwSNTyo36Rc8J0F6v0LBCBKL5pmyTZ9co3EZTsIbQ5ShG
# Lieshk9VUgzkAyz7apCQMG6H81kwnfp+1pez6CGXfvjSE/MIt1NtUrRFkJ9IAEpH
# ZhEnKWaol+TTBoFKovmEpxFHFAmCn4TtVXj+AZodUAiFABAwRu233iNGu8QtVJ+v
# HnhBMXfMm987g5OhYQK1HQ2x/PebsgHOIktU//kFw8IgCwIDAQABo4IBqzCCAacw
# DwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUIzT42VJGcArtQPt2+7MrsMM1sw8w
# CwYDVR0PBAQDAgGGMBAGCSsGAQQBgjcVAQQDAgEAMIGYBgNVHSMEgZAwgY2AFA6s
# gmBAVieX5SUT/CrhClOVWeSkoWOkYTBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHmCEHmtFqFKoKWtTHNY9AcTLmUwUAYDVR0f
# BEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEBBEgwRjBEBggr
# BgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNy
# b3NvZnRSb290Q2VydC5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcN
# AQEFBQADggIBABCXisNcA0Q23em0rXfbznlRTQGxLnRxW20ME6vOvnuPuC7UEqKM
# bWK4VwLLTiATUJndekDiV7uvWJoc4R0Bhqy7ePKL0Ow7Ae7ivo8KBciNSOLwUxXd
# T6uS5OeNatWAweaU8gYvhQPpkSokInD79vzkeJkuDfcH4nC8GE6djmsKcpW4oTmc
# Zy3FUQ7qYlw/FpiLID/iBxoy+cwxSnYxPStyC8jqcD3/hQoT38IKYY7w17gX606L
# f8U1K16jv+u8fQtCe9RTciHuMMq7eGVcWwEXChQO0toUmPU8uWZYsy0v5/mFhsxR
# VuidcJRsrDlM1PZ5v6oYemIp76KbKTQGdxpiyT0ebR+C8AvHLLvPQ7Pl+ex9teOk
# qHQ1uE7FcSMSJnYLPFKMcVpGQxS8s7OwTWfIn0L/gHkhgJ4VMGboQhJeGsieIiHQ
# Q+kr6bv0SMws1NgygEwmKkgkX1rqVu+m3pmdyjpvvYEndAYR7nYhv5uCwSdUtrFq
# PYmhdmG0bqETpr+qR/ASb/2KMmyy/t9RyIwjyWa9nR2HEmQCPS2vWY+45CHltbDK
# Y7R4VAXUQS5QrJSwpXirs6CWdRrZkocTdSIvMqgIbqBbjCW/oO+EyiHW6x5PyZru
# SeD3AWVviQt9yGnI5m7qp5fOMSn/DsVbXNhNG6HY+i+ePy5VFmvJE6P9MIIHejCC
# BWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcN
# MjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2
# WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSH
# fpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQ
# z7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHml
# SSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3o
# iU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6
# nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6ep
# ZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf
# 28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCn
# q47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx
# 7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O
# 9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQy
# MDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZC
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQy
# MDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCB
# gzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9k
# b2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABf
# AHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEB
# CwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LR
# bYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r
# 4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb
# 7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6v
# mSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/
# sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad2
# 5UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUf
# FL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWx
# m6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMj
# aHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7
# qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCBKYwggSi
# AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAm
# BgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAADDDpun
# 2LLc9ywAAAAAAMMwCQYFKw4DAhoFAKCBujAZBgkqhkiG9w0BCQMxDAYKKwYBBAGC
# NwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQx
# FgQUK6yv7d6LfrpmUIQzbAkCAk5lQnQwWgYKKwYBBAGCNwIBDDFMMEqgJIAiAE0A
# aQBjAHIAbwBzAG8AZgB0ACAAVwBpAG4AZABvAHcAc6EigCBodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vd2luZG93czANBgkqhkiG9w0BAQEFAASCAQC1wJJE0tTO+EW1
# dj6ckSBLDo65iAHgPtaebUsj34tm+iBJPft2f9252/p+yM6pRbL/BCmYDcZvIu06
# DUj5QKqbVPRM+v6hcvCNyIXVxF1SJp1If+2xflL0ETfnwIIW81NF4rJf1pPqQhHM
# qQRhyBzjbbJZGjeJgNYyN2szHlbhi6u8HkTJCoo7onb8Qwd96+FjchAoNsahw7RI
# boaPAW5ONF2uPBIWIxA9iWzos25JEXG7noZoDyJoaF4zCLDaUTGo3EcKghMZVLyK
# HdVMa6NwYMtZ96mMqIxkxsqnJspVrDPlrlXzMa7OwJwtAJ8BSKUioTmPeVK3xqAv
# jmZiuHOqoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQQITMwAAANjkdflFb0j3rgAAAAAA2DAJBgUrDgMCGgUA
# oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcx
# MjA0MjM1MzAzWjAjBgkqhkiG9w0BCQQxFgQUlBMyAG/EC3nH5tWQirkDLRsftAsw
# DQYJKoZIhvcNAQEFBQAEggEAOjE/6wyG2upysm9VRzP9+zJgjYl1MVJiKsyckTDP
# Aupk7fztWCb5IuRuOptyvh6XJAfE5ZmIE5q2dOi9eotq7oqCeKRpJRNR9/j7z8l4
# F8UF6++FVAwuy6AdvmFngdoUNSsGdwdooGwlhiFUu1TrgBvga9UQyxqcwugowuef
# /rgHp+QfTks7zxmvHfYsoZ/lRYdN+97PnwSfxeHcZi8lh9+4izZaZUF/yyw5THTi
# lT7hWzYiyuxcVcTpoWCTjfFkIC1rmwqzhtNXGOZNDL2LSeRJGmb0zypQ8DX6fmqi
# 6zi9Oa+n0uzTxBUzca7tQP3Kd2MaZt4QOOKGhtLcMiHYzQ==
# SIG # End signature block
