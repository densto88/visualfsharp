﻿#------------------------------------------------------------------------------  
#  
# Copyright © 2017 Microsoft Corporation.  All rights reserved.  
#  
# THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED “AS IS” WITHOUT  
# WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT 
# LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS  
# FOR A PARTICULAR PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR   
# RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.  
#  
#------------------------------------------------------------------------------  
#  
# PowerShell Source Code  
#  
# NAME:  
# PerfInsightsHelper.psm1
#  
# VERSION:  
#    check $script:ver
#  
#------------------------------------------------------------------------------  

# get detailed information from PhysicalDisks as detected by SPACEPORT driver, including SCSI address details

function Get-DetailedPhysicalDisks
{
	param([bool]$Refresh=$false)

	if($script:DetailedPhysicalDisks -ne $null -and $refresh -eq $false) {return $script:DetailedPhysicalDisks | sort PhysicalDiskName}

	# detect virtualDisk only if OS is complatible with Storage spaces
	$script:DetailedPhysicalDisks = @()
	if((Get-Module Storage) -eq $null) {
		Write-Debug "No <Storage> PowerShell module found"
	}
	else {
		$Physicaldisks = Get-PhysicalDisk | % {

			$SCSIDetails = Get-SCSIDetails $_.DeviceId

			$pdisk = New-Object psobject
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "PhysicalDiskName" -Value $SCSIDetails.DeviceName
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "DiskNumber" -Value $SCSIDetails.DiskNumber
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "SizeGB" -Value ([math]::Round($_.Size / 1GB)) 
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "HealthStatus" -Value $_.HealthStatus
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "OperationalStatus" -Value $_.OperationalStatus
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "SCSIPort" -Value $SCSIDetails.SCSIPort
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "SCSIBus" -Value $SCSIDetails.SCSIBus
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "SCSITargetId" -Value $SCSIDetails.SCSITargetId
			Add-Member -InputObject $pdisk -MemberType NoteProperty -Name "SCSILun" -Value $SCSIDetails.SCSILun

			$script:DetailedPhysicalDisks += $pdisk
		}
	}
	
    return $script:DetailedPhysicalDisks | sort PhysicalDiskName
}
# this function runs external SCSIInsights.EXE file to read SCSI properties for specified lisk of disks
# Param DeviceName should be formatted as:
#   PhysicalDrive<n> or PhysicalDisk<n>

function Get-SCSIDetails
{
	param([int]$Disknumber, [bool]$Refresh=$false)

	if($script:SCSIDetails -ne $null -and !$refresh -and $script:SCSIDetails[$disknumber] -ne $null) {
		return $script:SCSIDetails[$disknumber]
	}

	if($script:SCSIDetails -eq $null -and !$refresh) {
		Write-Debug "Get-SCSIDetails hashtable cache is null, creating new one"
		# create emty cache
		$script:SCSIDetails = @{}
	}

	Write-Debug "Get-SCSIDetails invoked with parameter $disknumber"
	#invoke external tool to get SCSI details
	$invocation = (Get-Variable MyInvocation -Scope script).Value 
	$scriptfolder = Split-Path $invocation.MyCommand.Path 
	$arg0 = "$scriptfolder\Tools\SCSIInsights.exe"
	$devicename = ("PhysicalDrive{0}" -f $diskNumber)
	$arg1 = "\\.\$devicename"
	$res = & $arg0 $arg1

	$SCSIPort = [int]::Parse( ($res.split(',')[0]).split(':')[1])
	$SCSIBus = [int]::Parse($res.split(',')[1].split(':')[1])
	$SCSITargetId = [int]::Parse($res.split(',')[2].split(':')[1])
	$SCSILun = [int]::Parse($res.split(',')[3].split(':')[1])
	
	$item = New-Object psobject
	Add-Member -InputObject $item -MemberType NoteProperty -Name "DeviceName" -Value $devicename
	Add-Member -InputObject $item -MemberType NoteProperty -Name "DiskNumber" -Value $Disknumber
	Add-Member -InputObject $item -MemberType NoteProperty -Name "SCSIPort" -Value $SCSIPort
	Add-Member -InputObject $item -MemberType NoteProperty -Name "SCSIBus" -Value $SCSIBus
	Add-Member -InputObject $item -MemberType NoteProperty -Name "SCSITargetId" -Value $SCSITargetId
	Add-Member -InputObject $item -MemberType NoteProperty -Name "SCSILun" -Value $SCSILun

	# add item to cache
	if(!$refresh){
		$script:SCSIDetails[$Disknumber]=$item
	}
	return $item
}

# this function collects information about storagePool from current storage subsystem
# it collects all info about physical disks and virtual disks
function Get-Pools 
{
    param([String]$PoolName)
    $ss = get-storagesubsystem
    $sp = if($PoolName -eq "") {$ss | Get-StoragePool -IsPrimordial $false -ea SilentlyContinue} else {Get-StoragePool -FriendlyName $PoolName -ea SilentlyContinue}
    $sp | % {
        $pool = $_
        $vd = $pool | Get-VirtualDisk 
        $pd = $pool | Get-PhysicalDisk
		
		$VirtualDiskCount_ = if($vd.Count -eq $null) {1}else {$vd.Count}
		$PhysicalDiskCount_ = if($pd.Count -eq $null) {1}else {$pd.Count}

		$poolitem = New-Object psobject
		Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "DeviceName" -Value $DeviceName        
		Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "StorageSubsystemID" -value $ss.UniqueId
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "PoolID" -value $pool.UniqueId
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "PoolName" -value $pool.FriendlyName
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "IsPrimordial" -value $pool.IsPrimordial
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "IsReadonly" -value $pool.IsReadOnly
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "OperationalStatus" -value $pool.OperationalStatus
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "HealthStatus" -value $pool.HealthStatus
    	Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "VirtualDisks" -value $vd
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "VirtualDiskCount" -value $VirtualDiskCount_
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "PhysicalDisks" -value $pd
        Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "PhysicalDiskCount" -value $PhysicalDiskCount_
		Add-Member -InputObject $poolitem -MemberType NoteProperty -Name "Pool" -value $pool

		$poolitem
    }
}

function Import-StorageModule
{
	param([bool]$Refresh=$false)
	
	# cache check
	if($script:IsStorageModulePresent -ne $null -and $refresh -eq $false) {return $script:IsStorageModulePresent}
	
	$script:IsStorageModulePresent = $true
	if((Get-Module Storage) -eq $null){
		write-debug "PS Module <Storage> not loaded. Trying to load"
		Import-Module Storage -ea 0
		if((Get-Module Storage) -eq $null){
			write-debug "PS Module <Storage> does not exist"
			$script:IsStorageModulePresent = $false
		}
	}	

	return $script:IsStorageModulePresent
}

# this function explores all volumes and mount points and collect related disk information
function Get-VolumeMap ()
{
	param([bool]$Refresh=$false, [switch]$HashTable=$false)

	# cache check
    
	if($script:volmap -eq $null -or $refresh -ne $false) {
    # cache miss

	# hashtable as return object
    $VolumeMap = @{}

    # iterate over all Volumes
    Get-WmiObject -Class Win32_Volume -ComputerName $env:COMPUTERNAME | % {
		$volume = $_
		
		# letter will be the identifier for the current volume
		$VolumeID = $volume.name
        if($VolumeID.EndsWith("\")){$VolumeID = $VolumeID.substring(0,$VolumeID.length -1)}

		# zero variables
		$isDynamic_ = $false
		$isPooled_= $false
		$isPartition = $false
		$isSimple = $false
		$isStriped = $false
		$isSpanned = $false
		$isMirrored = $false
		$isRAID5 = $false		
		$isSystemDisk_ = $false
		$isDataDisk_ = $false
		$IsMountPoint_ = $false
		$IsResiliencySimple_ = $false

		# get volume information from DISKPART
		$diskpartvol = Get-DiskpartVolumes | Where-Object {$_.Letter -eq $VolumeID}

		if($diskpartvol -ne $null){
			
			$type_ = $diskpartvol.type
			
			switch ($diskpartvol.type){
				"Simple"    { $isSimple = $true; $isDynamic_ = $true }
				"Partition" { $isPartition = $true }
				"Stripe"   { $isStriped = $true; $isDynamic_ = $true }
				"Spanned"   { $isSpanned = $true; $isDynamic_ = $true}
				"Mirror"   { $isMirrored = $true; $isDynamic_ = $true}
				"RAID-5"   { $isRaid5 = $true; $isDynamic_ = $true}
			}
			
			# assign dynamic disks
			$DynamicPhysicalDisks_ = if($isDynamic_){$diskpartvol.Disks}

			# get first disk under the diskpart volume
			$diskpartvol0 = if($diskpartvol.Disks -is [system.array]){$diskpartvol.Disks[0]}else{$diskpartvol.Disks}
			
			# define number of disks from dynamic disk settings		
			$NumOfDisks = $diskpartvol.NumberOfDisks

			# set as mountpoint if no default drive letter found
			$IsMountPoint_ = if($diskpartvol.MountPoints -ne $null){($diskpartvol.MountPoints[0] -eq $VolumeID)}else{$false}

			# set filesystem type
			$FileSystem_ = $diskpartvol.filesystem
		}

		#get the diskmap
		$diskmap = Get-DiskMap -Refresh $refresh | Where-Object {$_.Letter -eq $VolumeID}
		# get the first disk 
		$diskmap0 = if($diskmap -is [system.array]){$diskmap[0]}else{$diskmap}

		#mark as sysDisk volumes with no correspondency with diskpart and diskmap due to invalid Letter
		$isSystemDisk_ = ($diskmap -eq $null -and $diskpartvol -eq $null)

		#current volume is datadisk if it's a Stripe or a Partition and it is not a OSDIKS nor a TEMPDISK
		$isDataDisk_ = ($IsDynamic_ -or ($isPartition -and !($diskmap0).IsOsDisk -and !($diskmap0).IsTempDisk))

        # try to import Storage module (might be unloaded on some environments)
        Import-Module Storage -ea 0

		# detect virtualDisk only if OS is complatible with Storage Spaces
		# Storage module needs to be loaded
		if( (Import-StorageModule) ) {
			if(!$isSystemDisk_){
				# get partition associated to current volume letter
				$partition = get-partition | Where-Object {$_.DiskNumber -eq $diskpartvol0.DiskNumber}
				$partition0 = if($partition -is [system.array]){$partition[0]}else{$partition}

				if($partition -ne $null){
					$diskId = ($partition0).DiskId
                    $diskID_GUID = ""
                    try{
					    $diskid_GUID = $diskid.substring($DiskId.IndexOf('{'), 38)

						# get virtual disk associated to current partition
						$virtualDisk = Get-VirtualDisk | Where-Object {$_.ObjectId.toUpper() -like "*$diskID_GUID*"} 
						if($virtualDisk -ne $null){
							# update number of disk with the number of columns
							$NumOfDisks = $virtualDisk.NumberOfColumns
							$StoragePool = $virtualDisk | Get-StoragePool 
							$Physicaldisks = $virtualDisk | Get-PhysicalDisk | % {
								$pd = $_
								Get-DetailedPhysicalDisks -Refresh $Refresh | Where-Object{$_.DiskNumber -eq $pd.DeviceId} | % {
									$_
								}
							}
							$ispooled_ = $true
						}
					}catch{
                        write-debug ("StorageSpaces analysis, ignoring partitionNumber : {0}, DriveLetter : {1}, size : {2}, diskID : {3}" -f $partition0.PartitionNumber, $partition0.DriveLetter, $partition0.Size, $partition0.DiskId)
                    }
				}
			}
		}
        
		# Display the information in a table
		
		$DriveTypeName_ = switch($volume.driveType){0{"Unknown"}1{"NoRootDirectory"}2{"RemovableDisk"}3{"LocalDisk"}4{"NetworkDrive"}5{"CD-ROM"}6{"RamDisk"}}
		$SizeGB_ = if($volume.Capacity -eq $null){""}else{"{0:F3}" -f $($volume.Capacity / 1GB)}
		$FreeGB_ = if($volume.FreeSpace -eq $null){""}else{"{0:F3}" -f $($volume.FreeSpace / 1GB)}
		$FreePerc_ = if($volume.FreeSpace -eq $null){""}else{"{0:F2}" -f(($volume.FreeSpace/$volume.Capacity)*100)}
		$IsOSDisk_ = if($diskmap -ne $null){($diskmap0).IsOsDisk}else{$false}
		$IsTempDisk_ = if($diskmap -ne $null){($diskmap0).IsTempDisk}else{$false}
		$DiskMap_ = if($diskmap -ne $null){$diskmap}
		$VirtualDisk_ = if($IsPooled_){$virtualDisk}
		$StoragePool_ = if($IsPooled_){$StoragePool}
		$PooledPhysicalDisks_ = if($IsPooled_){$Physicaldisks}
		$IsResiliencySimple_ = if($IsPooled_){$virtualDisk.ResiliencySettingName -eq "Simple"}
		
		
		$ResiliencySettingName_ = $virtualDisk.ResiliencySettingName
		$ProvisioningType_ = $virtualDisk.ProvisioningType

		$disks_ = @()
		if($ispooled_)
		{
			$PooledPhysicalDisks_ | %{
				$diskitem_ = New-Object psobject

				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "PhysicalDiskName" -Value ("PhysicalDrive{0}" -f $_.DiskNumber)
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "DiskNumber" -Value $_.DiskNumber
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SizeGB" -Value $_.SizeGB
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "HealthStatus" -Value $_.HealthStatus
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIPort" -Value $_.SCSIPort
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIBus" -Value $_.SCSIBus
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSITargetId" -Value $_.SCSITargetId
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSILun" -Value $_.SCSILun

				$disks_ += $diskitem_
			}
		}
		elseif ($isdynamic_)
		{
			$DynamicPhysicalDisks_ | %{
				$diskitem_ = New-Object psobject

				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "PhysicalDiskName" -Value $_.PhysicalDiskName
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "DiskNumber" -Value $_.DiskNumber
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SizeGB" -Value $_.SizeGB
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "HealthStatus" -Value $_.HealthStatus
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIPort" -Value $_.SCSIPort
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIBus" -Value $_.SCSIBus
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSITargetId" -Value $_.SCSITargetId
				Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSILun" -Value $_.SCSILun

				$disks_ += $diskitem_
			}
		}
		elseif($diskpartvol0 -ne $null)
		{
			$diskitem_ = New-Object psobject
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "PhysicalDiskName" -Value $diskpartvol0.PhysicalDiskName
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "DiskNumber" -Value $diskpartvol0.DiskNumber
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SizeGB" -Value $diskpartvol0.SizeGB
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "HealthStatus" -Value $diskpartvol0.HealthStatus
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIPort" -Value $diskpartvol0.SCSIPort
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIBus" -Value $diskpartvol0.SCSIBus
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSITargetId" -Value $diskpartvol0.SCSITargetId
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSILun" -Value $diskpartvol0.SCSILun

			$disks_ += $diskitem_
		}elseif($diskmap0 -ne $null){
			$diskitem_ = New-Object psobject
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "PhysicalDiskName" -Value $diskmap0.PhysicalDiskName
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "DiskNumber" -Value $diskmap0.DiskNumber
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SizeGB" -Value $diskmap0.SizeGB
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "HealthStatus" -Value $null
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIPort" -Value $diskmap0.SCSIPort
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSIBus" -Value $diskmap0.SCSIBus
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSITargetId" -Value $diskmap0.SCSITargetId
			Add-Member -InputObject $diskitem_ -MemberType NoteProperty -Name "SCSILun" -Value $diskmap0.SCSILun

			$disks_ += $diskitem_
		}

		$volumeType_ = switch($volume.driveType){0{"Unknown"}1{"NoRootDirectory"}2{"RemovableDisk"}3{"LocalDisk"}4{"NetworkDrive"}5{"CD-ROM"}6{"RamDisk"}}

		$volumeitem = New-Object psobject
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "VolumeNumber" -Value $diskpartvol.VolumeNumber
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "VolumeID" -Value $VolumeID
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "Label" -Value $volume.Label
        Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "DriveType" -Value $volume.driveType
        Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "DriveTypeName" -Value $DriveTypeName_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "FileSystem" -Value $FileSystem_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "ClusterSize" -Value $volume.BlockSize;
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "AllocationUnitSize" -Value ("{0:n0} KB" -f ($volume.BlockSize / 1kb));
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "NumOfDisks" -Value $NumOfDisks;
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "SizeGB" -Value $SizeGB_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "FreeGB" -Value $FreeGB_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "FreePerc" -Value $FreePerc_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "Type" -Value $Type_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsOSDisk" -Value $IsOSDisk_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsTempDisk" -Value $IsTempDisk_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsDataDisk" -Value $IsDataDisk_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsSystemDisk" -Value $IsSystemDisk_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsDynamic" -Value $IsDynamic_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsSimple" -Value $IsSimple
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsStriped" -Value $IsStriped
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsSpanned" -Value $IsSpanned
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsMirrored" -Value $IsMirrored
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsRAID5" -Value $IsRAID5
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsPartition" -Value $IsPartition
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsPooled" -Value $IsPooled_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsResiliencySimple" -Value $IsResiliencySimple_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "VDisk_ResiliencySettingName" -Value $ResiliencySettingName_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "VDisk_ProvisioningType" -Value $ProvisioningType_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "IsMountPoint" -Value $IsMountPoint_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "DiskpartVolume" -Value $diskpartvol
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "DiskMap" -Value $DiskMap_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "VirtualDisk" -Value $VirtualDisk_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "StoragePool" -Value $StoragePool_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "PooledPhysicalDisks" -Value $PooledPhysicalDisks_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "DynamicPhysicalDisks" -Value $DynamicPhysicalDisks_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "Disks" -Value $Disks_
		Add-Member -InputObject $volumeitem -MemberType NoteProperty -Name "MountPoints" -Value $MountPoints

		$VolumeMap[$VolumeID] = $volumeitem
	}
	
    $script:volmap = $VolumeMap
    
    }

    if($HashTable){return $script:volmap}else{return $script:volmap.Values}
}

function Get-DiskpartVolumes()
{
	param([bool]$Refresh=$false)

	if($script:DiskpartVolumes -ne $null -and $refresh -eq $false) {return $script:DiskpartVolumes}

	[array]$script:DiskpartVolumes = @()
	[array]$Volumes = "list volume" | diskpart

	For ($i=0;$i -lt ($Volumes.Count);$i++)
	{

        [array]$mountpoints = $null
        $line = $Volumes[$i]
		If ($Line.StartsWith("  Volume" ))
		{
            $Line -Match "  Volume (?<volnum>...) +(?<drltr>...) +(?<lbl>...........) +(?<fs>.....) +(?<typ>..........) +(?<sz>.......) +(?<sts>.........) +(?<nfo>........)" | Out-Null
            if($Matches['volnum'].Trim() -eq "###") {continue}

            [int]$VolumeNumber = $Matches['volnum'].Trim();
            
			$Letter = $Matches['drltr'].Trim();
			$Label = $Matches['lbl'].Trim();
            $FileSystem = $Matches['fs'].Trim();
            $Type = $Matches['typ'].Trim();
            $Size = $Matches['sz'].Trim();
            $Status = $Matches['sts'].Trim();
            $Info  = $Matches['nfo'].Trim();
            
            # add the colon if single letter
            if ($Letter.length -eq 1){
                $Letter += ":"
            }

			# look ahead for mountpoint
            while($Volumes[$i+1].StartsWith("    ") -and $Volumes[$i+1].EndsWith("\")){
                #if not special disk
                if (!("Hidden,Boot,System,Pagefile"-contains $Info)){
                    
                    $mountpoint = $Volumes[$i+1].trim()
					
					#removes the "\" at the end of the path
                    if($mountpoint.EndsWith("\")){$mountpoint = $mountpoint.substring(0,$mountpoint.length -1)}
                    
					# assigns the first mountpoint found to drive letter, if not defined
					if($Letter.length -eq 0){
                        $Letter = $mountpoint
                    }
                    [array]$mountpoints += $mountpoint
                }
                $i = $i + 1
            }

            $vd = Get-DiskpartVolumeDetails -VolumeNumber $VolumeNumber
			$isDynamic = $vd.Disks[0].IsDynamic

            $diskPartVolItem = New-Object psobject
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "VolumeNumber" -Value $VolumeNumber;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Letter" -Value $Letter;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Label" -Value $Label;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "FileSystem" -Value $FileSystem;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Type" -Value $Type;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Size" -Value $Size;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Status" -Value $Status;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Info " -Value $Info;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "NumberOfDisks" -Value $vd.NumberOfDisks;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Disks" -Value $vd.Disks;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "MountPoints" -Value $mountpoints;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "IsDynamic" -Value $isDynamic;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "ReadOnly" -Value $vd.ReadOnly;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Hidden" -Value $vd.Hidden;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "NoDefaultDriveLetter" -Value $vd.NoDefaultDriveLetter;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "ShadowCopy" -Value $vd.ShadowCopy;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Offline" -Value $vd.Offline;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "BitLockerEncrypted" -Value $vd.BitLockerEncrypted;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "Installable" -Value $vd.Installable;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "VolumeCapacityGB" -Value $vd.VolumeCapacityGB;
			Add-Member -InputObject $diskPartVolItem -MemberType NoteProperty -Name "VolumeFreeSpaceGB" -Value $vd.VolumeFreeSpaceGB;

			$script:DiskpartVolumes += $diskPartVolItem
		}
	}

	return $script:DiskpartVolumes | sort VolumeNumber
}

function Get-DiskpartVolumeDetails
{
    param([int]$VolumeNumber)

    $query = @"
select volume $($VolumeNumber)
detail volume
"@
    [array]$volumedetails = $query | diskpart

    [array]$Disks = @()
    [int]$NumOfDisks = 0
    For ($i=0;$i -lt ($volumedetails.Count);$i++)
	{
        
        $line = $volumedetails[$i]
		if ($Line.StartsWith("Read-only"))
        {
            $ReadOnly = ($line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim() -eq "Yes")
        }
		elseif ($Line.StartsWith("Hidden"))
        {
            $Hidden = ($line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim() -eq "Yes")
        }
		elseif ($Line.StartsWith("No Default Drive Letter" ))
		{
            $NoDefaultDriveLetter = ($line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim() -eq "Yes")
        }
		elseif ($Line.StartsWith("Shadow Copy"))
        {
            $ShadowCopy = ($line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim() -eq "Yes")
        }
		elseif ($Line.StartsWith("Offline"))
        {
            $Offline = ($line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim() -eq "Yes")
        }
        elseif ($Line.StartsWith("BitLocker Encrypted"))
        {
            $BitLockerEncrypted = ($line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim() -eq "Yes")
        }
		elseif ($Line.StartsWith("Installable"))
        {
            $Installable = ($line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim() -eq "Yes")
        }
		elseif ($Line.StartsWith("Volume Capacity"))
        {
            $VolumeCapacityGB = $line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim().split(" ")[0]
        }
		elseif ($Line.StartsWith("Volume Free Space"))
        {
            $VolumeFreeSpaceGB = $line.split(':', [System.StringSplitOptions]::RemoveEmptyEntries)[1].trim().split(" ")[0]
        }
		elseif ($Line -Match "(?<star>.) Disk +(?<disknum>...) +(?<sts>.............) +(?<sz>.......) +(?<fr>.......) +(?<dyn>...) +(?<gpt>...)")
        {
            if($Matches['disknum'].Trim() -eq "###") {continue}
            $NumOfDisks += 1

			$disknumber = [int]::Parse($Matches['disknum'].Trim())
			$sizeGB = [int]::Parse($Matches['sz'].Trim().split(" ")[0])
			$freeGB = [int]::Parse($Matches['fr'].Trim().split(" ")[0])
			$SCSIDetails = Get-SCSIDetails $disknumber

            $diskitem =  New-Object PSObject 
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "PhysicalDiskName" -Value $SCSIDetails.DeviceName
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "DiskNumber" -Value $disknumber;
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "HealthStatus" -Value $Matches['sts'].Trim();
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "IsDynamic" -Value ($Matches['dyn'].Trim() -eq "*");
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "IsGpt" -Value ($Matches['gpt'].Trim() -eq "*");
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "SizeGB" -Value $sizeGB
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "FreeGB" -Value $freeGB
            Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "SCSIPort" -Value $SCSIDetails.SCSIPort
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "SCSIBus" -Value $SCSIDetails.SCSIBus
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "SCSITargetId" -Value $SCSIDetails.SCSITargetId
			Add-Member -InputObject $diskitem -MemberType NoteProperty -Name "SCSILun" -Value $SCSIDetails.SCSILun
			$Disks += $diskitem
        }
    }
	
	$vd =  New-Object PSObject 
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "VolumeNumber" -Value $VolumeNumber;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "NumberOfDisks" -Value $NumOfDisks;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "Disks" -Value $Disks | sort DiskNumber;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "ReadOnly" -Value $ReadOnly;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "Hidden" -Value $Hidden;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "NoDefaultDriveLetter" -Value $NoDefaultDriveLetter;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "ShadowCopy" -Value $ShadowCopy;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "Offline" -Value $Offline;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "BitLockerEncrypted" -Value $BitLockerEncrypted;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "Installable" -Value $Installable;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "VolumeCapacityGB" -Value $VolumeCapacityGB;
	Add-Member -InputObject $vd -MemberType NoteProperty -Name "VolumeFreeSpaceGB" -Value $VolumeFreeSpaceGB;

	return $vd
}	

function Get-DiskMap
{
	param([bool]$Refresh=$false, [switch]$GroupVolumes=$false)
	$dmap = Get-DiskMapInternal -Refresh $Refresh
	
	if($GroupVolumes){
		
		$hash =@{}
		foreach ($disk in $dmap){
			if(!$hash.ContainsKey($disk.DiskNumber)){
				
				$diskmapItem = New-Object PSObject

				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "Boot" -Value $disk.boot;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "DiskNumber" -Value $disk.DiskNumber;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSIBus" -Value $disk.SCSIBus;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSIPort" -Value $disk.SCSIPort;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSITargetId" -Value $disk.SCSITargetId;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSILun" -Value $disk.SCSILun;
				
				$letters = @() 
				$letter = New-Object PSObject
				Add-Member -InputObject $letter -MemberType NoteProperty -Name "Letter" -Value $disk.Letter;
				Add-Member -InputObject $letter -MemberType NoteProperty -Name "VolumeName" -Value $Disk.VolumeName;
				Add-Member -InputObject $letter -MemberType NoteProperty -Name "Partition" -Value $Disk.Partition;
				$letters += $Letter;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "Letters" -Value $letters

				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "DriveName" -Value $disk.DriveName;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "PhysicalDiskName" -Value $disk.PhysicalDiskName;
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "IsOSDisk" -Value $disk.IsOSDisk; 
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "IsTempDisk" -Value $disk.IsTempDisk; 
				Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SizeGB" -Value $disk.SizeGB;

				$hash[$disk.DiskNumber] = $diskmapItem

			}else{

				$letter = New-Object PSObject
				Add-Member -InputObject $letter -MemberType NoteProperty -Name "Letter" -Value $disk.Letter;
				Add-Member -InputObject $letter -MemberType NoteProperty -Name "VolumeName" -Value $Disk.VolumeName;
				Add-Member -InputObject $letter -MemberType NoteProperty -Name "Partition" -Value $Disk.Partition;
				$hash[$disk.DiskNumber].letters+= $Letter
			}
			
		}
		$dmap = $hash.values
	}
	return $dmap
}

function Get-DiskMapInternal
{
	param([bool]$Refresh=$false)

	if($script:diskmap -ne $null -and $refresh -eq $false) {return $script:diskmap}

	# List the Windows disks

	$DiskMap = Get-WmiObject -Class Win32_DiskDrive -ComputerName $env:COMPUTERNAME | % {
		$Drive = $_
		# Find the partitions for this drive
		Get-WmiObject -Class Win32_DiskDriveToDiskPartition -ComputerName $env:COMPUTERNAME |  Where-Object {$_.Antecedent -eq $Drive.Path.Path} | %{
			$D2P = $_
			# Get details about each partition
			$Partition = Get-WmiObject -Class Win32_DiskPartition -ComputerName $env:COMPUTERNAME |  Where-Object {$_.Path.Path -eq $D2P.Dependent}
			# Find the drive that this partition is linked to
			Get-WmiObject -Class Win32_LogicalDiskToPartition -ComputerName $env:COMPUTERNAME | Where-Object {$D2P.Dependent -contains $_.Antecedent} | %{ 
				$L2P = $_
				#Get the drive letter for this partition, if there is one
				Get-WmiObject -Class Win32_LogicalDisk -ComputerName $env:COMPUTERNAME | Where-Object {$L2P.Dependent -contains $_.Path.Path} | %{
					$Disk = $_
					$DiskNumber = [Int]::Parse($Partition.DeviceID.Split(",")[0].Replace("Disk #",""));
		            $diskPartition = [Int]::Parse($Partition.DeviceID.Split(",")[1].Replace(" Partition #",""))
		            $SCSITargetID  = $Drive.SCSITargetId
		            # Display the information in a table

					$diskmapItem = New-Object PSObject
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "Boot" -Value $Partition.BootPartition;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "DiskNumber" -Value $DiskNumber;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "Partition" -Value $diskPartition;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSIBus" -Value $Drive.SCSIBus;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSIPort" -Value $Drive.SCSIPort;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSITargetId" -Value $Drive.SCSITargetId;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SCSILun" -Value $Drive.SCSILogicalUnit;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "Letter" -Value $Disk.DeviceID;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "VolumeName" -Value $Disk.VolumeName;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "DriveName" -Value $Drive.Name;
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "PhysicalDiskName" -Value ("PhysicalDisk{0}" -f $DiskNumber);
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "IsOSDisk" -Value ($DiskNumber -eq "0" -and $SCSITargetID -eq "0" -and $Drive.Interfacetype -eq "IDE"); 
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "IsTempDisk" -Value ($DiskNumber -eq "1"  -and $SCSITargetID -eq "1"-and $Drive.Interfacetype -eq "IDE"); 
					Add-Member -InputObject $diskmapItem -MemberType NoteProperty -Name "SizeGB" -Value ([math]::Round($Drive.Size / 1GB)) 

					$diskmapItem
				}
			}
			
		}
	} | Sort-Object DiskNumber, Partition

	$script:diskmap = $DiskMap
	return $DiskMap
}

function Get-ReversedVolumeMap
{
	param(
		[bool]$Refresh=$false,
		[switch]$HashTable=$false
		)

	$vm = get-volumemap -Refresh $Refresh

	# cache check
	if($script:ReversedVolmap -eq $null -or $refresh -ne $false) {

	$h=@{}
	$ds = @()

	foreach ($v in $vm ) {

		foreach ($dd in $v.disks) {
		
			if(!$h.ContainsKey($dd.DiskNumber)){
            
				$volumes = @()

				$hitem = New-Object pscustomobject
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "PhysicalDiskName" -Value $dd.PhysicalDiskName
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "DiskNumber"       -Value $dd.DiskNumber      
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "HealthStatus"     -Value $dd.HealthStatus    
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "SizeGB"           -Value $dd.SizeGB          
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "SCSIPort"         -Value $dd.SCSIPort        
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "SCSIBus"          -Value $dd.SCSIBus         
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "SCSITargetId"     -Value $dd.SCSITargetId    
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "SCSILun"          -Value $dd.SCSILun         
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "IsOSDisk"         -Value $v.IsOSDisk
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "IsTempDisk"       -Value $v.IsTempDisk
				Add-Member -InputObject $hitem -MemberType NoteProperty -Name "Volumes"          -Value $volumes     

				$h[$dd.disknumber] = $hitem
			}
			$h[$dd.disknumber].volumes += ($v | select VolumeID, Label)
							#select VolumeID, `
							#Label, `
							#DriveType, `
							#DriveTypeName, `
							#FileSystem, `
							#ClusterSize, `
							#AllocationUnitSize, `
							#NumOfDisks , `
							#SizeGB, `
							#FreeGB, `
							#FreePerc, `
							#Type, `
							#IsOSDisk, `
							#IsTempDisk, `
							#IsDataDisk, `
							#IsSystemDisk, `
							#IsDynamic, `
							#IsSimple, `
							#IsStriped, `
							#IsSpanned, `
							#IsMirrored, `
							#IsRAID5, `
							#IsPartition, `
							#IsPooled, `
							#IsResiliencySimple, `
							#VDisk_ResiliencySettingName, `
							#VDisk_ProvisioningType, `
							#IsMountPoint )
		}
	
	}

    # update cache
    $script:ReversedVolmap = $h

    # return hashtable if requested
	if($HashTable){
		return $h
	}
    
    }
    if($HashTable){return $script:ReversedVolmap}else{return $script:ReversedVolmap.Values}
}

function Get-VolumeDisks
{
	param([bool]$Refresh=$false, [switch]$HashTable=$false)

	# cache check
	if($script:voldisk -eq $null -or $refresh -ne $false) {

    # init hash
    $voldisk_ = @{}
        
    $vm = Get-VolumeMap -Refresh $Refresh | Where-Object {$_.IsOsDisk -or $_.isdatadisk -or $_.istempdisk}
    $vm | % {
        $voldisk_[$_.volumeID] = $_ | select VolumeID, Disks, IsOsDisk, IsDataDisk, IsTempDisk
    }
    
    # set cache
    $script:voldisk = $voldisk_
    }

    if($HashTable){return $script:voldisk}else{return $script:voldisk.Values}
}

function ConvertTo-PS2JS {
param(
	[object] $inputObject,
	[string] $variableName = "outputObj",
	[string] $arrayname = "array"
)

	$json = ConvertTo-PS2Json -inputObject $inputObject -arrayname $arrayname
	$result = "var {0} = {1};" -f $variableName, $json
    return $result
}

function ConvertTo-PS2Json {
param(
	[object]$inputObject,
	[int] $level = 0,
	[string] $arrayname = "array"
)
	$tab = "    "
    $t =""
    for($y=0;$y -lt $level; $y++){$t += "$tab"}
    $tt = $t + "$tab"
    $result = "$t{`r`n"

    if($inputObject -is [system.array]){
        $array = ""
        $val = $inputObject
        for($j=0;$j -lt $val.Count; $j++){
            if($j -gt 0) {$array +=",`r`n"}
            $array += (ConvertTo-PS2Json $val[$j] ($level+2))
        }
        $result += "$tt`"{0}`" : [`r`n{1}`r`n$tt]" -f $arrayname, $array
        
    }else{

		$members = @()
        $members += ($inputObject | Get-Member -MemberType NoteProperty,Property)
    
        for($k = 0;$k -lt $members.Count;$k++)
        {
            $_ = $members[$k]
			
            if($k -gt 0) {$result +=",`r`n"}

            try {
				$name = $_.Name
				$val = ($inputObject | select -ExpandProperty $Name)
				
                switch($val.gettype().tostring()){
                    "System.Int32" {
                        $result += ("$tt`"{0}`" : {1}" -f $Name, $val)
                    }
                    "System.UInt64" {
                        $result += ("$tt`"{0}`" : {1}" -f $Name, $val)
                    }
                    "System.UInt32" {
                        $result += ("$tt`"{0}`" : {1}" -f $Name, $val)
                    }
                    "System.UInt16" {
                        $result += ("$tt`"{0}`" : {1}" -f $Name, $val)
                    }
                    "System.Double" {
                        $result += ("$tt`"{0}`" : {1}" -f $Name, $val)
                    }
                    "System.Boolean" {
                        $result += ("$tt`"{0}`" : {1}" -f $Name, $val.tostring().tolower())
                    }
                    "System.Object[]" {
                        $array = ""
                        for($j=0;$j -lt $val.Count; $j++){
                            if($j -gt 0) {$array +=",`r`n"}
                            $array += (ConvertTo-PS2Json $val[$j] ($level+2))
                        }
                        $result += "$tt`"{0}`" : [`r`n{1}`r`n$tt]" -f $Name, $array
                    }
                    "System.Management.Automation.PSCustomObject"{
                        if($members[$k].Definition.StartsWith("System.Object[]") -or $members[$k].Definition.StartsWith("Object[]")){
                            $val_ = (ConvertTo-PS2Json $val ($level+2))
                            $result += "$tt`"{0}`" : [`r`n{1}`r`n$tt]" -f $Name, $val_
                        }else{
                            $result += "$tt`"{0}`" : `r`n{1}" -f $Name, (ConvertTo-PS2Json $val ($level+1))
                        }
                        
                    }
                    "Microsoft.Management.Infrastructure.CimInstance"{
                        $result += "$tt`"{0}`" : `r`n{1}" -f $Name, (ConvertTo-PS2Json $val ($level+1))
                    }
                    "System.String" {
                        $val = $val.replace("\","\\")
                        $val = $val.replace("`"","\`"")
						$val = $val.replace("`r","")
                        $val = $val.replace("`n","")
                        $result += "$tt`"{0}`" : `"{1}`"" -f $Name, $val
                    }
                    default {
                        $result += "$tt`"{0}`" : `"{1}`"" -f $Name, $val
                    }
                }
            }catch{
				$result += ("$tt`"{0}`" : null" -f $Name, $val)
			}
        }
    
    }

    $result += "`r`n$t}"
    return $result
}

Filter ConvertTo-KMG 
                {
                     <#
                     .Synopsis
                      Converts byte counts to Byte\KB\MB\GB\TB\PB format
                     .DESCRIPTION
                      Accepts an [int64] byte count, and converts to Byte\KB\MB\GB\TB\PB format
                      with decimal precision of 2
                     .EXAMPLE
                     3000 | convertto-kmg
                     #>

                     $bytecount = $_
                        switch ([math]::truncate([math]::log($bytecount,1024))) 
                        {
                            0 {"$bytecount Bytes"}
                            1 {"{0:n2} KB" -f ($bytecount / 1kb)}
                            2 {"{0:n2} MB" -f ($bytecount / 1mb)}
                            3 {"{0:n2} GB" -f ($bytecount / 1gb)}
                            4 {"{0:n2} TB" -f ($bytecount / 1tb)}
                            Default {"{0:n2} PB" -f ($bytecount / 1pb)}
                        }
                }

function Unzip
{
	param(
		[string] $file,
		[string] $path
	)

    # now unzip
	Write-Debug "Extracting file $file in $path"
    $shell = New-Object -ComObject Shell.Application
    $zip = (new-object -com shell.application).NameSpace("$file")
	$shell.Namespace("$path").copyhere($zip.Items(),0x14 )
}

function Get-PremiumDiskTargetPerformance ([int]$size)
{

	if($size -le 32)  #P4
	{
		$maxiops = 120
		$maxthroughput =  25
	}
	elseif($size -le 64) #P6
	{
		$maxiops = 240
		$maxthroughput =  50
	} 
	elseif($size -le 128) #P10
	{
		$maxiops = 500
		$maxthroughput =  100
	} 
	elseif ($size -le 512) #P20
	{
		$maxiops = 2300
		$maxthroughput =  150
	} 
	elseif ($size -le 1024) #P30
	{
		$maxiops = 5000
		$maxthroughput =  200
	} 
	elseif ($size -le 2048) #P40
	{
		$maxiops = 7500
		$maxthroughput =  250
	}
	else #P50
	{
		$maxiops = 7500
		$maxthroughput =  250
	} 

	$o = New-Object PSObject
	Add-Member -InputObject $o -MemberType NoteProperty -Name "MaxIOPS" -Value $maxiops;
	Add-Member -InputObject $o -MemberType NoteProperty -Name "MaxThroughput" -Value $maxthroughput;
	return $o
}

function Get-StandardDiskTargetPerformance ([int]$size)
{
	$o = New-Object PSObject
	Add-Member -InputObject $o -MemberType NoteProperty -Name "MaxIOPS" -Value 500;
	Add-Member -InputObject $o -MemberType NoteProperty -Name "MaxThroughput" -Value 60;
	return $o
}

function Get-BasicDiskTargetPerformance ([int]$size)
{
	$o = New-Object PSObject
	Add-Member -InputObject $o -MemberType NoteProperty -Name "MaxIOPS" -Value 300;
	Add-Member -InputObject $o -MemberType NoteProperty -Name "MaxThroughput" -Value 60;
	return $o
}

function Test-FileVersion
{
	param(
		[System.Diagnostics.FileVersionInfo] $fileVersionInfo,
		[int] $major,
		[int] $minor,
		[int] $build,
		[int] $private
	)

	$ret = $false
	if($fileVersionInfo.FileMajorPart -ge $major){
		if($fileVersionInfo.FileMinorPart -ge $minor){
			if($fileVersionInfo.FileBuildPart -ge $build){
				if($fileVersionInfo.FilePrivatePart -ge $private){
					$ret = $true
				}
			}
		}
	}

	return $ret
}

function Test-OSVersion
{
	param(
		[int] $major,
		[int] $minor,
		[int] $build=-1 # by defult this is ignored
	)

	$osVersion = (Get-WmiObject -Class Win32_OperatingSystem).Version.split('.')
	$osMajorPart = $osVersion[0]
	$osMinorPart = $osVersion[1]
	$osBuildPart = $osVersion[2]

	$ret = $false
	if($osMajorPart -eq $major){
		if($osMinorPart -eq $minor){
			if($build -lt 0 -or $osBuildPart -eq $build){
				$ret = $true
			}
		}
	}

	return $ret
}

function Get-NfoTemplate {
    $result = ""
    $result +="<?xml version=`"1.0`"?>`r`n"
    $result +="<MsInfo>`r`n"
    $result +="<Metadata>`r`n"
    $result +="<Version>8.0</Version>`r`n"
    $result +=("<CreationUTC>{0}</CreationUTC>`r`n" -f ((Get-Date ).ToUniversalTime().ToString("MM/dd/yyyyTHH:mm:ssZ")))
    $result +="</Metadata>`r`n" 
    $result += "<Category name = `"{0}`">`r`n"
    $result +="{1}"
    $result +="</Category>`r`n"
    $result +="</MsInfo>`r`n"
    return $result
}

function Get-NfoCategoryTemplate {

    $result += "<Category name = `"{0}`">`r`n"
    $result +="{1}"
    $result +="</Category>`r`n"
    
    return $result
}

function Get-NfoDataTemplate {
    $result =""
    $result +="<Data>`r`n"
    $result +="<Item><![CDATA[{0}]]></Item>`r`n"
    $result +="<Value><![CDATA[{1}]]></Value>`r`n"
    $result +="</Data>`r`n"
    return $result
}

function Get-NfoCustomDataTemplate {
param(
    [string[]]$fields
)
    $result =""
    $result +="<Data>`r`n"
    for($i = 0; $i -lt $fields.Count; $i++){
        $result += ("<{0}>" -f $fields[$i])
        $result +="<![CDATA[{$i}]]>"
        $result +=("</{0}>`r`n" -f $fields[$i])
    }
    $result +="</Data>`r`n"
    return $result
}

function Get-NfoData{
param(
	[object]$inputObject
)
    $datatemplate = Get-NfoCustomDataTemplate ("property","value")
    $results = ""

    #get fields from reflection        
    $members = ($inputObject | Get-Member -MemberType NoteProperty,Property)

    for($k = 0;$k -lt $members.Count;$k++)
    {
        $_ = $members[$k]
   
        try {
			$name = $_.Name
			$val = ($inputObject | select -ExpandProperty $Name)
			
            switch($val.gettype().tostring()){
                "System.Boolean" {
                    $results += ($datatemplate -f $name, $val.tostring().tolower())
                }
                "System.String" {
                    if($val -ne ""){
                        $val = $val.replace("\","\\")
                        $val = $val.replace("`"","\`"")
					    $val = $val.replace("`r","")
                        $val = $val.replace("`n","")
                        $results += ($datatemplate -f $name, $val)
                    }
                }
                "System.Object[]" { }
                "System.Management.Automation.PSCustomObject" { }
                "Microsoft.Management.Infrastructure.CimInstance" { }
                default {
                    $results += ($datatemplate -f $name, $val)
                }
            }
        }catch{
            #$results += ($datatemplate -f $name, "")
		}
    }
    return $results
}

function Get-NfoList{
param(
    [string]$titlemembername,
	[object]$inputObject
)
    $results = ""
    $inputObject | % {
        $itembody = Get-NfoData $_
        #$titlemember = $_ | Get-Member -Name $titlemembername
        $title = $_ | select -ExpandProperty $titlemembername
        $results += ($categorytemplate -f $title, $itembody)
    }

    return $results
}

function Get-NfoVolumeMap {
    
	$volumemap = get-volumemap
    $maintemplate = Get-NfoTemplate
    $categorytemplate = Get-NfoCategoryTemplate
    $summarytemplate = Get-NfoCustomDataTemplate ("DeviceId", "isOS", "isTemp", "isData", "isDynamic", "isStriped", "isPooled", "isResiliencySimple")

    #init main body
    $mainbody = ""

	# summary section
    $volumemap | % {
        $_isOsDisk     = if($_.isOsDisk)                    {"■"}else{"□"}
        $_isTempDisk   = if($_.isTempDisk)                  {"■"}else{"□"}
        $_isDataDisk   = if($_.isDataDisk)                  {"■"}else{"□"}
        $_isDynamic    = if($_.isDynamic)                   {"■"}else{"□"}
        $_isStriped    = if($_.isStriped)                   {"■"}else{"□"}
        $_isPooled     = if($_.isPooled)                    {"■"}else{"□"}
		$_isResiliencySimple = if($_.IsResiliencySimple)    {"■"}else{"□"}
        $mainbody += ($summarytemplate -f $_.VolumeID, $_isOsDisk, $_isTempDisk, $_isDataDisk, $_isDynamic, $_isStriped, $_isPooled, $_isResiliencySimple)
    }

	# iterate over all volumes
    $volumemap | % {
        $vol = $_
		# get all volume fields
		$volumebody = Get-NfoData $vol
        if($vol.Disks -ne $null){ 
			#$volumebody += Get-NfoList "PhysicalDiskName" $_.Disks 
			
			#iterate over disks
			$vol.Disks | % {
				# set category title. if it's a data disks, add lun #
				$title = if($vol.isDatadisk) {("LUN {0} | {1}" -f $_.SCSILun, $_.PhysicalDiskName)}else{$_.PhysicalDiskName} 
				$volumebody += ($categorytemplate -f $title, (Get-NfoData $_))
			}
		}
        $mainbody += ($categorytemplate -f $_.VolumeID, $volumebody)
    }

    # wrap mainbody into main template
    $results = ($maintemplate -f "VolumeMap", $mainbody)
    
    return $results
}

function New-HierarchyTree
{
    param(
    [string] $ID,
    [psobject] $Payload = $null,
    [psobject] $Parent = $null
    )

    $node = New-Object psobject
    Add-Member -InputObject $node -MemberType NoteProperty -Name "ID" -Value $ID
    Add-Member -InputObject $node -MemberType NoteProperty -Name "Payload" -Value $Payload
    Add-Member -InputObject $node -MemberType NoteProperty -Name "Parent" -Value $Parent
    Add-Member -InputObject $node -MemberType NoteProperty -Name "Children" -Value @()
    Add-Member -InputObject $node -MemberType NoteProperty -Name "Level" -Value 0
    

    $node | Add-Member -MemberType ScriptMethod InsertNode -Value {
        [cmdletbinding()]

        param(
            [string] $ID,
            [psobject] $Payload = $null
        
        )
        process{
            $node = New-HierarchyTree -ID $ID -Payload $Payload
            $found = $false

            # iterate over root's children
            for ($i =0 ; (($i -lt $this.Children.Count) -and !$found); $i ++){
                $child = $this.Children[$i]
                $found = $child.InsertSubNode($node) 
            }

            # no subnodes compatible found, add node to root
            if(!$found){
                $node.Parent = $this
                $this.Children += $node
            }
        }
    }

    $node | Add-Member -MemberType ScriptMethod InsertSubNode -Value {
        [cmdletbinding()]

        param(
        [psobject] $node
        )

        process{
            $found = $false

            for ($i =0 ; (($i -lt $this.Children.Count) -and !$found); $i ++)
            {
                $child = $this.Children[$i]
                $found = $child.InsertSubNode($node)
            }

            if(!$found){
                # new node is son of parent
                if($node.ID.tolower().StartsWith($this.ID.tolower()))
                {    
                    $found = $true
                    # snap-in the node into parent
                    $node.parent = $this
                    $this.Children += $node
            
                }
                # the new node is an ancestor of parent
                elseif($this.ID.tolower().StartsWith($node.ID.tolower()))
                {
                    # backtracking to search for direct node's son
                    $nodeSon = $this
                    while($nodeSon.parent.id -ne "root" -and $nodeSon.parent.ID.tolower().StartsWith($node.ID.tolower()))
                    {
                        $nodeSon = $nodeSon.parent
                
                    }
                    # ancestor is the current grand-parent
                    $ancestor = $nodeSon.parent
                    $node.parent = $ancestor
            
                    # rebuild ancestor's children, without the node's son
                    $array = @()
                    foreach($item in $ancestor.children)
                    {
                        if($item.id -ne $nodeson.id)
                        {
                            $array += $item
                        }
                    }
                    # add node to ancestor's children
                    $array += $node
                    $ancestor.children = $array
            
                    # snap-in the parent into node
                    $node.children += $nodeson
                    $nodeson.parent = $node
            
                    $found = $true

                }
            }
            return $found
        }
    }

    $node | Add-Member -MemberType ScriptMethod Browse  -Value {
        $this.BrowseLevel(0)
    }

    $node | Add-Member -MemberType ScriptMethod BrowseLevel  -Value {

        param(
            [int] $level
        )
    
        process{
            if($this.children.count -gt 0){
                foreach($child in $this.children)
                {
                    $child.BrowseLevel($level +1)
                }
            }
            $this.Level = $level

            if($level -gt 0)
            {    
				$browseItem = New-Object pscustomobject
				$browseItem | Add-Member -MemberType NoteProperty -Name NodeId -Value $this.id
				$browseItem | Add-Member -MemberType NoteProperty -Name Payload -Value $this.Payload
				$browseItem | Add-Member -MemberType NoteProperty -Name Level -Value $this.level
				$browseItem			
            }   
        }
    }


    return $node
}

function Get-MountPointTable
{
	param([bool]$Refresh=$false)

	# cache check
	if($script:mptable -ne $null -and $refresh -eq $false) {return $script:mptable}

    $volumes = get-volumemap -Refresh $Refresh | where {$_.isdatadisk -or $_.isosdisk} 
	# generate a tree-shaped model to parse all the mount-points in the volume map
	# this will be used later to search in wich volume a sql file is placed
	$root = New-HierarchyTree -id "root"
	foreach($volume in $volumes)
	{
		$root.InsertNode($volume.VolumeID,$null);
	}
	# browse the tree and sort by descreasing depth level
	$table = $root.Browse() | sort -Descending Level

    $script:mptable = $table

    return $table
}

function Get-VolumeIDFromPath
{
    param(
        [bool]$Refresh=$false,
        [string]$Path
        )
    
    $mptable = Get-MountPointTable -Refresh $Refresh

    for ($j = 0 ; $j -lt $mptable.Count; $j++ ) 
	{
		$row = $mptable[$j]
	
		# if path starts with current mount point then it's a match
		if($Path.tolower().startswith($row.NodeID.ToLower())){
	
			$found = $row.NodeID
            break;
		}
	}
    
    return $found
}

# convert an single object into an array
# if input item is already an array, it will just be passed though
function ConvertTo-Array
{
  begin
  {
    $output = @(); 
  }
  process
  { 
    if($_ -is [system.array]){$output=$_}else{$output += $_}
  }
  end
  {
    return ,$output; 
  }
}

Export-ModuleMember ConvertTo-PS2Json, ConvertTo-PS2JS, ConvertTo-KMG,  Get-DiskMap, Get-Pools, `
    Get-VolumeMap, Get-SCSIDetails, Get-DetailedPhysicalDisks, Unzip, Get-PremiumDiskTargetPerformance, `
    Get-StandardDiskTargetPerformance, Get-BasicDiskTargetPerformance, Test-FileVersion, Test-OSVersion, `
    Get-NfoVolumeMap, New-HierarchyTree, Import-StorageModule, Get-ReversedVolumeMap, Get-VolumeDisks, `
    Get-MountPointTable, Get-VolumeIDFromPath, ConvertTo-Array

# SIG # Begin signature block
# MIIdjgYJKoZIhvcNAQcCoIIdfzCCHXsCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUU+hgR99JrvND5QGabu0i1sJx
# cFygghhSMIIEwTCCA6mgAwIBAgITMwAAANd4Xn6sPypBiwAAAAAA1zANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTcxMDAyMjI1NzU3
# WhcNMTkwMTAyMjI1NzU3WjCBsTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEMMAoGA1UECxMDQU9DMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo5
# NkZGLTRCQzUtQTdEQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK0R8WghBzWrkgfD
# oLwDByma12IHhlSPBbAGiWXRc2ixEiXWFkoH5IDW4fNnINAgbfCWThv3zAknQDa3
# H9IkZcvHSKEPgt7/MpC2LzuYiBGS7osE1YFJru5o3eQ15jRt+//Sk8j4fwis41Aj
# CNiePkK8wCHusRFyEOABoMC2KjUwrAEQbsMCCcm9AYq3QXc7tvvDncJfnmSfK8KY
# 1isAuPJcfIOsh7ugzUoklOUbkByfrwc51oWxyRhZTMGyJcvskauQzpqw8QIPJi4U
# pv/cW8ylaXvDD5rd+J7hJzkWpl/eg21LssBR2TdIVfJs48u99rvgf+ka05hE2lSL
# nnd67RUCAwEAAaOCAQkwggEFMB0GA1UdDgQWBBTYj8Ia8/dzgo7zIAVoJi/V/PwV
# PTAfBgNVHSMEGDAWgBQjNPjZUkZwCu1A+3b7syuwwzWzDzBUBgNVHR8ETTBLMEmg
# R6BFhkNodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNyb3NvZnRUaW1lU3RhbXBQQ0EuY3JsMFgGCCsGAQUFBwEBBEwwSjBIBggrBgEF
# BQcwAoY8aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3Nv
# ZnRUaW1lU3RhbXBQQ0EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3
# DQEBBQUAA4IBAQBtoYxTxcEg/Q/A+oGoitT3aME8OF7a1OAQqSPnV3OLGFLv3uPY
# X8nvdOTnhbKV6BIsW/DGukZflJjCo9I5D9+wz0s9hICPFEqvfpqZumy2T94K7veD
# 21BOZ59xfVauLrbWtBpISdd2kmGsaYacwd/Bf7ih4gmRKWdpGeLcYvN9d8fb68bt
# qwJLKb0B161HcM0SYJ9VxYkvDVqc8YtcH5CszKWLnR2lzBBXR8447n3RY/2ulRFW
# FD82SsbqpWVUo7JnVaphz9qR5Jn9iarO/SNmtmobYwDPwVpmq4ef2w6iypR3Nrn/
# PaDv6e7qm3mYnkYtM13zQXbBBQ6DgWferczAMIIGADCCA+igAwIBAgITMwAAAMMO
# m6fYstz3LAAAAAAAwzANBgkqhkiG9w0BAQsFADB+MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWdu
# aW5nIFBDQSAyMDExMB4XDTE3MDgxMTIwMjAyNFoXDTE4MDgxMTIwMjAyNFowdDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEeMBwGA1UEAxMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAu1fXONGxBn9JLalts2Oferq2OiFbtJiujdSkgaDFdcUs74JAKreBU3fzYwEK
# vM43hANAQ1eCS87tH7b9gG3JwpFdBcfcVlkA4QzrV9798biQJ791Svx1snJYtsVI
# mzNiBdGVlKW/OSKtjRJNRmLaMhnOqiJcVkixb0XJZ3ZiXTCIoy8oxR9QKtmG2xoR
# JYHC9PVnLud5HfXiHHX0TszH/Oe/C4BHKf/PzWmxDAtg62fmhBubTf1tRzrH2cFh
# YfKVEqENB65jIdj0mRz/eFWB7qV56CCCXwratVMZVAFXDYeRjcJ88VSGgOFi24Jz
# PiZe8EAS0jnVJgMNhYgxXwoLiwIDAQABo4IBfzCCAXswHwYDVR0lBBgwFgYKKwYB
# BAGCN0wIAQYIKwYBBQUHAwMwHQYDVR0OBBYEFKcTXR8hiVXoA+6eFzbq8lSINRmv
# MFEGA1UdEQRKMEikRjBEMQwwCgYDVQQLEwNBT0MxNDAyBgNVBAUTKzIzMDAxMitj
# ODA0YjVlYS00OWI0LTQyMzgtODM2Mi1kODUxZmEyMjU0ZmMwHwYDVR0jBBgwFoAU
# SG5k5VAF04KqFzc3IrVtqMp1ApUwVAYDVR0fBE0wSzBJoEegRYZDaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljQ29kU2lnUENBMjAxMV8yMDEx
# LTA3LTA4LmNybDBhBggrBgEFBQcBAQRVMFMwUQYIKwYBBQUHMAKGRWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljQ29kU2lnUENBMjAxMV8y
# MDExLTA3LTA4LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4ICAQBN
# l080fvFwk5zj1RpLnBF+aybEpST030TUJLqzagiJmZrLMedwm/8UHbAHOX/kMDsT
# It4OyJVnu25++HyVpJCCN5Omg9NJAsGsrVnvkbenZgAOokwl1NznXQcCyig0ZTs5
# g62VKo7KoOgIOhz+PntASZRNjlQlCuWxxwrucTfGm1429adCRPu8h7ANwDXZJodf
# /2fvKHT3ijAEEYpnzEs1YGoh58ONB4Nem6udcR8pJgkR1PWC09I2Bymu6JJtkH8A
# yahb7tAEZfuhDldTzPKYifOfFZPIBsRjUmECT1dIHPX7dRLKtfn0wmlfu6GdDWmD
# J+uDPh1rMcPuDvHEhEOH7jGcBgAyfLcgirkII+pWsBjUsr0V7DftZNNrFQIjxooz
# hzrRm7bAllksoAFThAFf8nvBerDs1NhS9l91gURZFjgnU7tQ815x3/fXUdwx1Rpj
# NSqXfp9mN1/PVTPvssq8LCOqRB7u+2dItOhCww+KUViiRgJhJloZv1yU6ahAcOdb
# MEx8gNRQZ6Kl7g7rPbXx5Xke4fVYGW+7iW144iBYJf/kSLPmr/GyQAQXRlDUDGyR
# FH3uyuL2Jt4bOwRnUS4PpBf3Qv8/kYkx+Ke8s+U6UtwqM39KZJFl2GURtttqt7Rs
# Uvy/i3EWxCzOc5qg6V0IwUVFpSmG7AExbV50xlYxCzCCBgcwggPvoAMCAQICCmEW
# aDQAAAAAABwwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZ
# MBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTA3MDQwMzEyNTMwOVoXDTIxMDQw
# MzEzMDMwOVowdzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEh
# MB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAn6Fssd/bSJIqfGsuGeG94uPFmVEjUK3O3RhOJA/u
# 0afRTK10MCAR6wfVVJUVSZQbQpKumFwwJtoAa+h7veyJBw/3DgSY8InMH8szJIed
# 8vRnHCz8e+eIHernTqOhwSNTyo36Rc8J0F6v0LBCBKL5pmyTZ9co3EZTsIbQ5ShG
# Lieshk9VUgzkAyz7apCQMG6H81kwnfp+1pez6CGXfvjSE/MIt1NtUrRFkJ9IAEpH
# ZhEnKWaol+TTBoFKovmEpxFHFAmCn4TtVXj+AZodUAiFABAwRu233iNGu8QtVJ+v
# HnhBMXfMm987g5OhYQK1HQ2x/PebsgHOIktU//kFw8IgCwIDAQABo4IBqzCCAacw
# DwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUIzT42VJGcArtQPt2+7MrsMM1sw8w
# CwYDVR0PBAQDAgGGMBAGCSsGAQQBgjcVAQQDAgEAMIGYBgNVHSMEgZAwgY2AFA6s
# gmBAVieX5SUT/CrhClOVWeSkoWOkYTBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHmCEHmtFqFKoKWtTHNY9AcTLmUwUAYDVR0f
# BEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEBBEgwRjBEBggr
# BgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNy
# b3NvZnRSb290Q2VydC5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcN
# AQEFBQADggIBABCXisNcA0Q23em0rXfbznlRTQGxLnRxW20ME6vOvnuPuC7UEqKM
# bWK4VwLLTiATUJndekDiV7uvWJoc4R0Bhqy7ePKL0Ow7Ae7ivo8KBciNSOLwUxXd
# T6uS5OeNatWAweaU8gYvhQPpkSokInD79vzkeJkuDfcH4nC8GE6djmsKcpW4oTmc
# Zy3FUQ7qYlw/FpiLID/iBxoy+cwxSnYxPStyC8jqcD3/hQoT38IKYY7w17gX606L
# f8U1K16jv+u8fQtCe9RTciHuMMq7eGVcWwEXChQO0toUmPU8uWZYsy0v5/mFhsxR
# VuidcJRsrDlM1PZ5v6oYemIp76KbKTQGdxpiyT0ebR+C8AvHLLvPQ7Pl+ex9teOk
# qHQ1uE7FcSMSJnYLPFKMcVpGQxS8s7OwTWfIn0L/gHkhgJ4VMGboQhJeGsieIiHQ
# Q+kr6bv0SMws1NgygEwmKkgkX1rqVu+m3pmdyjpvvYEndAYR7nYhv5uCwSdUtrFq
# PYmhdmG0bqETpr+qR/ASb/2KMmyy/t9RyIwjyWa9nR2HEmQCPS2vWY+45CHltbDK
# Y7R4VAXUQS5QrJSwpXirs6CWdRrZkocTdSIvMqgIbqBbjCW/oO+EyiHW6x5PyZru
# SeD3AWVviQt9yGnI5m7qp5fOMSn/DsVbXNhNG6HY+i+ePy5VFmvJE6P9MIIHejCC
# BWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcN
# MjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2
# WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSH
# fpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQ
# z7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHml
# SSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3o
# iU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6
# nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6ep
# ZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf
# 28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCn
# q47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx
# 7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O
# 9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQy
# MDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZC
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQy
# MDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCB
# gzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9k
# b2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABf
# AHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEB
# CwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LR
# bYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r
# 4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb
# 7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6v
# mSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/
# sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad2
# 5UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUf
# FL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWx
# m6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMj
# aHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7
# qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCBKYwggSi
# AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAm
# BgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAADDDpun
# 2LLc9ywAAAAAAMMwCQYFKw4DAhoFAKCBujAZBgkqhkiG9w0BCQMxDAYKKwYBBAGC
# NwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQx
# FgQUpwWiH7jdNhkGnyYoZzQ4k2RXF2kwWgYKKwYBBAGCNwIBDDFMMEqgJIAiAE0A
# aQBjAHIAbwBzAG8AZgB0ACAAVwBpAG4AZABvAHcAc6EigCBodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vd2luZG93czANBgkqhkiG9w0BAQEFAASCAQCY62xm/Gq17VkR
# /lnuQ+SRezSANwYjqIAAPOnmFhV+05rGexNreBixJReLrDDz4k+O0mtKQjSWvmVl
# qJaGnN7YYTg+E6T8HGINlcSIYxUXANFW8gtk24U/RiTVI0CmhTUHz+WLYNBxQAO2
# CMjKwjaHY02Se+8amYywFCeMvogVYpFrqqvmkwSPugMpRCSKcMMlTkiEtWwPqqWj
# mW/KROjKPJ/8wFYZrNGIeHQHJCNenAJPvFQ/rqwNIBEKw8cglLVi1Z8tnLCKnXrB
# GMA6o4Xnu52f59tTiJdfD0Jgr5X3Jy3TSq9uf//I4/R/6zuosvLyLiZq13krIv+q
# Q2ZZS8yZoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQQITMwAAANd4Xn6sPypBiwAAAAAA1zAJBgUrDgMCGgUA
# oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcx
# MjA0MjM1MzAzWjAjBgkqhkiG9w0BCQQxFgQUM1Jtt7IfdHUjZ4kJNNlbGW4lAqYw
# DQYJKoZIhvcNAQEFBQAEggEAmrHHIY7QfZWdwHwLsXRA4bMNFH+Z3fytAiiDP4cY
# eT9ItIo1NoihXGF7Bo17mAecHKCRgDN6c7IOpGGR2vq4+oshLbkfkLrq5oSsDHSY
# Ji5Y1ie7sssUFYsaqOVzV8yXgMY3GNGm9wRMB2VKRG0sab71HxBCn4GMqxrPd1nC
# O1oSi4mt/0UCesAiwuH8JwOOfnWoye6KwbXly315HY9WChkGTrHfvpOs9YePLgCe
# V0vpPKdcaP7UCaaRyEv4T0MyQDubOJD88u3dLHOuMdsCpoxunnf2qpFVo2O+DOas
# 2qdMdwVL8yYpCJeQQyHoMezwraDmag9xuZ1A31Wc6u55zQ==
# SIG # End signature block
